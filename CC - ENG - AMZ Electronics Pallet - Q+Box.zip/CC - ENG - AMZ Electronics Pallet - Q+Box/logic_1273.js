
// whether we have already passed the first three CoReg questions
// (only ported to flexfancy because it is referenced by build_radio_buttons())
var secondCoregStage = false;
// the total number of CoReg questions in the survey
var totalCoregCount = 0;
// the number of CoReg questions which have been answered by the user
var clickedCoregCount = 0;
// the total number of available CoReg questions
var coregCount = 0;
// keep track of whether the remaining coregs have already been uncovered
var coregsUncovered = false;
/* EDIT: coreg_slider */
// whether we are using the CoReg slider or not
var coregSlider = true;
// keep track of the currently visible CoReg parent element
var currentCoregParent = null;

// keep track of the last displayed percentage value
var lastPercentage = 0;
// keep track of the current percentage value as it is being updated
var currentPercentage = 0;
// the timer interval which updates the percentage value
var percentInterval = null;
/* EDIT: coreg_tile_answers */
// the first weightedCoregCount question will make up 50 percent of the progressbar
var weightedCoregCount = 3;
// the default progressbar progress
var initProgress = 43;
// the message which will be shown after the user completes the sweepstake prepage
var prepageProcessingMessage = "Bitte warten, Ihre Auswahl wird geprüft...";

/* EDIT: progressbar_neu20210305 */
// make the rlmset data globally available
var globalConfigData = null;
/* EDIT: progressbar_neu20210305 */

/**
 * Find out if this is the CoReg DOI page or the normal CoReg page
 * @return boolean Whether this is the CoReg DOI page
 */
function OnCoregDoiPage() {
    return ($("#coreg-doi").length ? true : false);
}

/**
 * Find out if this is the first registration page
 * @return boolean Whether this is the first registration page
 */
function OnFirstRegPage() {
    return ($('[name="adressData[vorname]"]').length ? true : false);
}

/**
 * Find out if this is the second registration page
 * @return boolean Whether this is the second registration page
 */
function OnSecondRegPage() {
    return ($('[name="adressData[plz]"]').length ? true : false);
}

/**
 * Find out if this is a CoReg page
 */
function OnCoregPage() {
    return ($("#mfw_fieldset_ownCoregData").length ? true : false);
}

/**
 * Find out if this is the first promo page
 */
function OnPromoPage1() {
    return ($("#page-name").length && $("#page-name").val() == "promoPage1");
}

/**
 * Find out if this is the 'thank you' page
 */
function OnThankYouPage() {
    return ($("#tellmann").length ? true : false);
}

/**
 * Set the promotion background image
 * @param imageFilename The image path and filename
 */
/*function SetPromotionImage(imageFilename) {
    // set the responsive <img> element filename
    $(".promo-img").attr("src", imageFilename);
    // set the fixed size <div> background image for desktop display
    // (here, the height can be fixed but the image maintains its proper aspect ratio)
    $(".desktop-promo-img").css("background-image", "url('" + imageFilename + "')");
}*/

/* EDIT: promo_video */
/**
 * Set the promotion background image
 * @param imageFilename The image path and filename
 * @param videoName The name of the video loop to be used (optional)
 */
function SetPromotionImage(imageFilename, videoName, mobileImageFilename) {
    // if 'videoName' is set and the video hasn't been added yet,
    // add it to the DOM
    if (typeof videoName != "undefined" && videoName !== null &&
        videoName != "none" && !$(".promo-video").length) {
        // available video loops
        var videoInfo = {
            "mms": "mms_really_short.mp4",
            "bonbons": "soft_bonbons.mp4"
        };
        // translate the symbolic video name into an actual filename
        if (videoName in videoInfo) {
            var videoFilename = videoInfo[videoName];
        } else {
            // the video could not be found
            var videoFilename = "";
        }
        // video element HTML code
        var videoHtmlStr = `<video class="promo-video" width="640" autoplay muted loop>
            <source src="https://rlmgws-data.s3.eu-central-1.amazonaws.com/flexfancy/videos/${videoFilename}" />
        </video>`;
        // create a <video> element for the desktop version
        var desktopVideoElement = $(videoHtmlStr);
        // mark this element as being the desktop version
        desktopVideoElement.addClass("desktop");
        // set a specific height for the desktop version (the mobile version will scale automatically)
        desktopVideoElement.attr("height", 352);
        // add the desktop video element to the DOM
        $(".desktop-promo-img").append(desktopVideoElement);
        // create a <video> element for the mobile version
        var mobileVideoElement = $(videoHtmlStr);
        // mark this element as being the mobile version
        mobileVideoElement.addClass("mobile");
        // add the mobile video element to the DOM
        $(mobileVideoElement).insertAfter(".promo-img");
    } else {
        // ...just set up a regular promotion image.
        // Set the responsive <img> element filename
        if (typeof mobileImageFilename != "undefined" &&
            mobileImageFilename !== null) {
            // set up a separate mobile promotion image if available
            $(".promo-img").attr("src", mobileImageFilename);
        } else if (imageFilename !== null) {
            // otherwise, just use the desktop image for the mobile version, too
            $(".promo-img").attr("src", imageFilename);
        }
        if (imageFilename !== null) {
            // set the fixed size <div> background image for desktop display
            // (here, the height can be fixed but the image maintains its proper aspect ratio)
            $(".desktop-promo-img").css("background-image", "url('" + imageFilename + "')");
        }
    }
}
/* EDIT: promo_video */

/**
 * Change the percentage value represented by the progressbar
 * @param progressbar The progressbar which will be updated
 * @param percent The percentage value
 */
function set_progress(progressbar, percent) {
    // adjust the width of the percentage indicator bar
    var progressWidth = percent / 100 * progressbar.width();
    progressbar.find(".progress").animate({width: progressWidth}, 500);
}

function apply_coreg_highlights() {
    //$(".mfw_coreg_38 .app_coreg_a div.radio-img + input.radio").each(function(key, value) {
    /* EDIT: tile_coregs_dynamic */
    //$(".app_coreg_a div.radio-img + input.radio").each(function(key, value) {
    $(".coregAnswer input.radio, .coregSubAnswer input.radio").each(function(key, value) {
    /* EDIT: tile_coregs_dynamic */
        // fetch the value which was assigned to the CoReg answer
        /* EDIT: tile_coregs_dynamic */
        //var coregAnswerValue = $(value).val();
        var coregAnswerValue = $(value).attr("data-type");
        /* EDIT: tile_coregs_dynamic */
        // only check valid answers
        if (coregAnswerValue.length) {
            /* EDIT: tile_coregs_dynamic */
            //if (coregAnswerValue[0] == "p") {
            if (coregAnswerValue == "positive") {
            /* EDIT: tile_coregs_dynamic */
                // if the answer is the positive one, style it a certain way...
                $(value).parent().addClass("positive-answer");
            /* EDIT: tile_coregs_dynamic */
            //} else if (coregAnswerValue[0] == "n") {
            } else if (coregAnswerValue == "negative") {
            /* EDIT: tile_coregs_dynamic */
                // ...if it is the negative one, style it differently
                $(value).parent().addClass("negative-answer");
            }
        }
    });
    // overwrite the sweepstake background color
    /* EDIT: coreg_tile_answers */
    /* ultraflex */
    //$("body").append('<style>body {background-color: #fff !important;}</style>');
    /* ultraflex */
    /* EDIT: coreg_tile_answers */
}

/**
 * Transform regular CoReg answers to tile answers
 */
function transform_tile_coregs() {
    // traverse all available CoRegs
    /* EDIT: tile_coregs_dynamic */
    //$(".app_coreg").each(function(index, coreg) {
    $(".coregContainer").each(function(index, coreg) {
        /* EDIT: tile_coregs_dynamic */
        // convert the CoReg to a jQuery object
        var coregObj = $(coreg);
        /* EDIT: coreg_tile_answers_more_coregs */
        // fetch the internal CoReg ID
        var coregId = coregObj.data("value");
        // only apply the tile CoReg modification to certain CoRegs
        //if (coregId == 116 || coregId == 38 ||
        //    coregId == 37 || coregId == 872) {
        // make sure that the 'tile style' is only applied to the first four CoReg questions
        //if (index < 4) {
        /* EDIT: coreg_tile_answers_more_coregs */
         // add the new 'tile style' to the existing CoReg answers
         coregObj.find(".positive-answer, .negative-answer").addClass("tile-style");
         // look up all tile-style answers
         var tileAnswers = coregObj.find(".tile-style");
         // display CoRegs with one tile-answer in a certain way...
         if (tileAnswers.length == 1) {
             tileAnswers.addClass("single-answer");
         }
         /* EDIT: fixed_tile_layout */
         /*else if (tileAnswers.length == 2) {
             // ...and CoRegs with two tile-answers in a different way
             tileAnswers.addClass("double-answer");
         }*/
         /* EDIT: fixed_tile_layout */
         /* EDIT: coreg_tile_answers_more_coregs */
         else {
             tileAnswers.addClass("multi-answer");
             // add some margin info, etc. to the parent element
             tileAnswers.parent().addClass("multi-coreg-parent");
         }
        //}
    });
    // apply content changes to CoReg 891 (dental insurance).
    // Try to find the <br> tag inside the string to use it as the central
    // point for chopping up the string
    /* EDIT: fix_empty_coregs */
    /* EDIT: tile_coregs_dynamic */
    if ($(".mfw_coreg_37").length) {
        // if ($(".mfw_coreg_891").length) {
        /* EDIT: tile_coregs_dynamic */
        /* EDIT: fix_empty_coregs */
        /* EDIT: tile_coregs_dynamic */
        var headlineText = $(".mfw_coreg_37 .coregHeadline").html();
        // var headlineText = $(".mfw_coreg_891 .coregHeadline").html();
        /* EDIT: tile_coregs_dynamic */
        var brSearchPos = headlineText.indexOf("<br>");
        // the <br> tag was found
        if (brSearchPos != -1) {
            // extract the secondary string section...
            var descriptionStr = headlineText.substr(brSearchPos + "<br>".length);
            // ...and insert it into the description tag
            /* EDIT: tile_coregs_dynamic */
            $(".mfw_coreg_37 .app_coreg_beschreibung").html(descriptionStr);
            // $(".mfw_coreg_891 .coregDescription").html(descriptionStr);
            /* EDIT: tile_coregs_dynamic */
            // remove the secondary string from the original headline string
            headlineText = headlineText.substr(0, brSearchPos);
            // copy the modified headline string back to its DOM location
            /* EDIT: tile_coregs_dynamic */
            $(".mfw_coreg_37 .app_coreg_headline_").html(headlineText);
            // $(".mfw_coreg_891 .coregHeadline").html(headlineText);
            /* EDIT: tile_coregs_dynamic */
        }
        /* EDIT: fix_empty_coregs */
    }
    /* EDIT: tile_coregs_dynamic */
    if ($(".mfw_coreg_42").length) {
        // if ($(".mfw_coreg_965").length) {
        /* EDIT: tile_coregs_dynamic */
        // apply changes to CoReg 42 (Dinner for Dogs).
        // Look up the answer label text which needs to be changed
        /* EDIT: tile_coregs_dynamic */
        var answerText = $(".mfw_coreg_42 .positive-answer .coregAnswerLabel").html();
        //var answerText = $(".mfw_coreg_965 .positive-answer .coregAnswerLabel").html();
        /* EDIT: tile_coregs_dynamic */
        var section2StartPos = answerText.indexOf("Dinner for");
        // only modify the text if a specific senetence was found
        if (section2StartPos != -1) {
            // wrap a special <span> tag around a section of the answer text
            var newAnswerText = answerText.substr(0, section2StartPos) + '<span class="tile-small-print">' +
                             answerText.substr(section2StartPos) + "</span>";
            // copy the modified answer string back to its original DOM location
            /* EDIT: tile_coregs_dynamic */
            $(".mfw_coreg_42 .positive-answer .coregAnswerLabel").html(newAnswerText);
            // $(".mfw_coreg_965 .positive-answer .coregAnswerLabel").html(newAnswerText);
            /* EDIT: tile_coregs_dynamic */
        }
        /* EDIT: fix_empty_coregs */
    }
    if ($(".mfw_coreg_705").length) {
        // apply changes to CoReg 705 (gas heating)
        // Look up the answer label text which needs to be changed
        var answerText = $(".mfw_coreg_705 .positive-answer .coregAnswerLabel").html();
        var section2StartPos = answerText.indexOf("bitte informieren");
        // only modify the text if a specific senetence was found
        if (section2StartPos != -1) {
            // wrap a special <span> tag around a section of the answer text
            /* EDIT: tile_small_print_fix */
            var newAnswerText = answerText.substr(0, section2StartPos) + '<span class="big-small-print">' +
                             answerText.substr(section2StartPos) + "</span>";
            /* EDIT: tile_small_print_fix */
            // copy the modified answer string back to its original DOM location
            $(".mfw_coreg_705 .positive-answer .coregAnswerLabel").html(newAnswerText);
        }
    /* EDIT: fix_empty_coregs */
    }
    /* EDIT: fix_empty_coregs */
    /* EDIT: coreg_tile_answers_more_coregs */
}

/**
 * Draw a progress indicator which represents the current user progress
 * @param totalStepCount The total number of steps to be taken by the user
 * @param currentStep The current step position of the user
 * @param configData The sweepstake customization config data
 */
function DrawProgressIndicator(totalStepCount, currentStep, configData) {
    // look up the progress indicator <canvas>
    var progressIndicator = $("#progress-indicator");
    if (progressIndicator.length) {
        // fetch the 2D graphics context for drawing
        var gfx = progressIndicator[0].getContext("2d");
        // get the canvas width
        var width = progressIndicator.width();
        // get the canvas height
        var height = progressIndicator.height();
        // clear the canvas before drawing
        gfx.clearRect(0, 0, width, height);
        // set the progress circle radius
        var circleRadius = 10;
        // calculate the actual width of the progress, without the margins
        var netWidth = width - circleRadius * 2;
        // calculate the length of the individual progress bar segments
        var xStep = netWidth / (totalStepCount - 1);
        // set the grey background color for the progress bar
        var bgColor = '#e6e6e6';
        // start drawing the progress bar at the center of the first circle marker
        var progressStartX = circleRadius;
        // treat step 0 differently (show no progress)
        if (currentStep == 0) {
            progressEndX = progressStartX;
        } else if (currentStep == 1) {
            // treat step 1 specially
            var progressEndX = progressStartX + xStep / 2;
        } else {
            // treat step 2 specially (show some extra progress)
            var progressEndX = progressStartX + xStep * (currentStep - 1) + xStep / 2;
        }
        // if the progress bar overshoots the progress area due to extra progress, clip it
        if (progressEndX > width - circleRadius) {
            // clip the progress bar
            progressEndX = width - circleRadius;
        }
        // set the progress bar line width
        var lineWidth = 6;
        // create the color gradient for highlighting the progress
        var progressColorGradient = gfx.createLinearGradient(0, 2, 0, 20);
        progressColorGradient.addColorStop(0, configData.content.highlightcolor);
        progressColorGradient.addColorStop(1, configData.content.basecolor);
        // if there is a progress bar to draw, draw it
        if (progressStartX < progressEndX) {
            // set the progress indicator color gradient
            gfx.fillStyle = progressColorGradient;
            // draw the progress indicator line
            gfx.fillRect(progressStartX, height / 2 - lineWidth / 2,
                         progressEndX - progressStartX, lineWidth);
            // if the progress indicator hasn't reached the end of the process,
            // also draw a section of grey background
            if (progressEndX < width - circleRadius) {
                // set the grey background color
                gfx.fillStyle = bgColor;
                // draw the grey background section
                gfx.fillRect(progressEndX, height / 2 - lineWidth / 2,
                             width - circleRadius - progressEndX, lineWidth);
            }
        } else {
            // ...there is no actual progress, so just draw the background progress line.
            // Set the grey background color
            gfx.fillStyle = bgColor;
            // draw the grey background line
            gfx.fillRect(circleRadius, height / 2 - lineWidth / 2,
                         width - circleRadius - circleRadius, lineWidth);
        }
        // draw the total number of progress indicator step circle markers
        for (i = 0; i < totalStepCount; i++) {
            // begin drawing the circle path
            gfx.beginPath();
            // draw the circle at the current position
            gfx.arc(circleRadius + i * xStep, height / 2, circleRadius, 0, 2 * Math.PI);
            // draw all circle markers up to the current step using the progress color gradient
            if (i < currentStep) {
                // set the progress indicator color gradient
                gfx.fillStyle = progressColorGradient;
            } else {
                // set the grey background color
                gfx.fillStyle = bgColor;
            }
            // draw the filled circle marker using the selected gradient
            gfx.fill();
        }
    }
}

/**
 * Decode a base64-encoded string properly to UTF-8
 * @param str The base64-encoded string
 * @return The decoded UTF-8 string
 */
function DecodeBase64(str) {
    // Going backwards: from bytestream, to percent-encoding, to original string.
    return decodeURIComponent(atob(str).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
}

function HexDigitToDec(hexDigit, hexPos) {
    if (!isNaN(hexDigit)) {
        return hexDigit * hexPos;
    } else if (/[a-f]/i.test(hexDigit)) {
        return (10 + hexDigit.toLowerCase().charCodeAt(0) - 'a'.charCodeAt(0)) * hexPos;
    } else {
        return 0;
    }
}

function SimpleHexToDec(hexNum) {
    var decNum = 0;
    if (hexNum.length == 2) {
        return HexDigitToDec(hexNum[0], 16) + HexDigitToDec(hexNum[1], 1);
    }
    return decNum;
}

function HexColorToRgb(hexColor) {
    var color = {red: 0, green: 0, blue: 0};
    if (hexColor.length == 7 && hexColor[0] == '#') {
        color.red = SimpleHexToDec(hexColor.substr(1, 2));
        color.green = SimpleHexToDec(hexColor.substr(3, 2));
        color.blue = SimpleHexToDec(hexColor.substr(5, 2));
    }
    return color;
}

/**
 * Determine if this is the English version of the sweepstake
 * @return boolean Whether this is an English sweepstake or not
 */
function IsEnglishVersion() {
    return ($("select[name='adressData[land]'] option").val() == "uk");
}

/**
 * Get the locale of the currently displayed sweepstake
 * @return the locale string or null, if no locale could be determined
 */
function GetLocale() {
    // fetch the hidden 'locale' input element
    var localeElement = $("#locale-info");
    // only look up locale information if the element could be found
    if (localeElement.length) {
        // list the number of supported locales
        var validLocales = ["de", "uk", "au"];
        // check if the value stored in the locale element matches one from the list
        // of supported locales
        for (var i in validLocales) {
            // if the strings match, return the element
            if (localeElement.val() == validLocales[i]) {
                return localeElement.val();
            }
        }
    }
    // if no supported locale info was found, just return null instead
    return null;
}

// the list of localized message strings which can be translated
var messageStrings = [
    {"de": "Bitte warten, Ihre Auswahl wird geprüft...",
     "en": "Please wait, your selection is being processed..."},
    {"de": "Meinten Sie ", "en": "Did you mean "},
    {"de": "? Bitte versuchen Sie es erneut.", "en": "? Please try again."},
    {"de": "Ungültige E-Mail-Adresse! Bitte versuchen Sie es erneut.",
     "en": "Invalid Email address! Please try again."},
    {"de": "Schritt ", "en": "Step "},
    {"de": " von ", "en": " of "},
    {"de": "Fast geschafft!", "en": "Almost Finished!"}
];

/**
 * Translate a message string from German to another language
 * @param messageStr The message string to be translated
 * @return The translated message string, or the original message string if it
           could not be translated
 */
function Translate(messageStr) {
    // only perform a translation if this is the English sweepstake version
    if (IsEnglishVersion()) {
        // traverse the list of localized message strings
        for (var i in messageStrings) {
            // if we found the German message string, check if an English message is
            // available, and return it
            if (messageStrings[i]["de"] == messageStr &&
                messageStrings[i]["en"] !== undefined) {
                // return the translated message string
                return messageStrings[i]["en"];
            }
        }
    }
    // if this isn't the English version, or we couldn't translate the message string,
    // just return the untranslated version instead
    return messageStr;
}

/**
 * Get the value of a HTTP cookie
 * (actually, this uses web storage instead of cookies)
 * @param name The name of the cookie
 * @return The value of the cookie, or false if it couldn't be found
 */
function GetCookie(name) {
    // if the given variable exists in storage...
    if (name in sessionStorage) {
        // ...return its value
        return sessionStorage[name];
    } else {
        // ...otherwise, return 'false'
        return null;
    }
}

/**
 * Set the value of a cookie to a specified value
 * (actually, this uses web storage instead of cookies)
 * @param name The name of the cookie
 * @param value The (new) value of the cookie
 */
function SetCookie(name, value) {
    // set the named variable to the given value
    sessionStorage[name] = value;
}

/**
 * Finish the prepage section of the registration process by moving on to
 * the first user registration page
 * @param totalStepCount The total number of progress steps (used by DrawProgressIndicator())
 * @param rlmsetData The sweepstake rlmset customization config data
 * @param modalMessage (optional) The text message shown by the 'processing' dialog
 */
function FinishPrepageSection(totalStepCount, rlmsetData, modalMessage) {
    // if a message for the modal processing dialog was given, make use of it
    if (modalMessage !== undefined) {
        // change the text message
        $(".processing-window .text").html(modalMessage);
    }
    // hide the 'headline2' section used by the prepage
    $(".controls-area .headline2").hide();
    // show the modal processing window
    $(".processing-window").show();
    // delay displaying the registration form
    setTimeout(function() {
        /* EDIT: custom_prepage */
        // show the promotion image, which was hidden during the prepage phase
        if (IsMobileBrowser()) {
            $(".promo-img").show();
        } else {
            $(".desktop-promo-img").show();
        }
        // clear custom prepage background style settings
        $(".deco-container .outer-container").attr("style", "");
        // restore headline content
        if (prepage_hideRlmsetHeadline) {
            $(".left-area").show();
            $(".hl3-free-pos").show();
            $(".right-area .prepage-headline").hide();
            if (!IsMobileBrowser()) {
                $(".headline3-dummy").show();
            }
        }
        /* EDIT: custom_prepage */
        // hide the modal processing window
        $(".processing-window").hide();
        // update the user progress state
        UpdateUserProgress(totalStepCount, 2, rlmsetData);
        // replace the prepage headline 1 text with the text used by the actual rlmset
        $(".headline1").html(rlmsetData.content.hl1.text);
        // replace the prepage headline 2 text with the text used by the actual rlmset
        $(".registration-page-1 .headline, .registration-page-2 .headline").html(rlmsetData.content.hl2.text);
        // show first registration page
        $(".registration-page-1").show();
        /* EDIT: fix_rlmset_storage */
        // mark the prepage section as being finished
        SetCookie("prepage-finished", 1);
        /* EDIT: fix_rlmset_storage */
    }, 2600);
}

/* EDIT: custom_prepage */
var prepage_hideRlmsetHeadline = false;
/* EDIT: custom_prepage */

/* EDIT: ultraflex_prepage_attributes */
function ApplyCustomStyle(prepageQuizHtml, prepageData) {
    /* EDIT: custom_prepage */
    if (prepageData.prepage.pp_core.background.type == "color") {
        // set up the 'style' attribute string, clear the background-image (if it exists)
        var styleAttributeStr = "background-image: none !important; ";
        styleAttributeStr += `background-color: ${prepageData.prepage.pp_core.background.color}`;
        $(".deco-container .outer-container").attr("style", styleAttributeStr);
        // don't show the promotion image yet
        $(".promo-img, .desktop-promo-img").hide();
    }
    if (prepageData.prepage.pp_core.background.hide_rlmset_headline == "on") {
        if (!IsMobileBrowser()) {
            $(".left-area").hide();
            $(".right-area").prepend('<h2 class="prepage-headline"></h2>');
            var headlineText = $("h2.headline1").text();
            $(".right-area .prepage-headline").prepend(headlineText);
        }
        $(".headline3").hide();
        $(".headline3-dummy").hide();
        $(".hl3-free-pos").attr("style", "display: none !important;");
        $(".right-area .prepage-headline").css("font-family", "sans-serif");
        $(".right-area .prepage-headline").css("font-size", prepageData.prepage.pp_core.hl1.size + "px");
        $(".right-area .prepage-headline").css("font-weight", prepageData.prepage.pp_core.hl1.weight);
        $(".right-area .prepage-headline").css("text-align", prepageData.prepage.pp_core.hl1.align);
        $(".right-area .prepage-headline").css("color", "#50addc");
        prepage_hideRlmsetHeadline = true;
    }
    /* EDIT: custom_prepage */
    if ("overwrite" in prepageData.prepage.pp_core.fragen &&
        prepageData.prepage.pp_core.fragen.overwrite == "on") {
        // "fragen" section
        if ("color" in prepageData.prepage.pp_core.fragen) {
            var color = prepageData.prepage.pp_core.fragen.color;
            $(".quiz-question .question").css("color", color);
        }
        if ("size" in prepageData.prepage.pp_core.fragen) {
            var size = prepageData.prepage.pp_core.fragen.size;
            $(".quiz-question .question").css("font-size", size + "px");
        }
        if ("weight" in prepageData.prepage.pp_core.fragen) {
            var weight = prepageData.prepage.pp_core.fragen.weight;
            $(".quiz-question .question").css("font-weight", weight);
        }
        if ("align" in prepageData.prepage.pp_core.fragen) {
            var align = prepageData.prepage.pp_core.fragen.align;
            $(".quiz-question .question").css("text-align", align);
        }
        // "button" section
        // use attr() instead of css() here, because we need "!important"
        var styleAttributeStr = "";
        if ("bgcolor" in prepageData.prepage.button) {
            var bgcolor = prepageData.prepage.button.bgcolor;
            styleAttributeStr += "background-color: " + bgcolor + "!important; ";
        }
        if ("schatten" in prepageData.prepage.button) {
            var shadow = prepageData.prepage.button.schatten;
            shadow = "2px 2px 5px " + shadow + "99";
            styleAttributeStr += "box-shadow: " + shadow + "; ";
        }
        if ("radius" in prepageData.prepage.button) {
            var radius = prepageData.prepage.button.radius;
            styleAttributeStr += "border-radius: " + radius + "px; ";
        }
        if ("textcolor" in prepageData.prepage.button) {
            var textcolor = prepageData.prepage.button.textcolor;
            styleAttributeStr += "color: " + textcolor + "; ";
        }
        if (styleAttributeStr.length > 0) {
            $(".quiz-question .answer").attr("style", styleAttributeStr);
        }
    }
    // headline #2 section
    if ("overwrite" in prepageData.prepage.pp_core.hl2 &&
        prepageData.prepage.pp_core.hl2.overwrite == "on") {
        var cssStyleStr = "";
        if ("size" in prepageData.prepage.pp_core.hl2) {
            var size = prepageData.prepage.pp_core.hl2.size;
            cssStyleStr += "@media only screen and (min-width: 768px) { .controls-area .headline2, .registration-page-2 .headline {";
            cssStyleStr += "font-size: " + size + "px !important;";
            cssStyleStr += "}}";
        }
        if ("size_mobile" in prepageData.prepage.pp_core.hl2) {
            var size = prepageData.prepage.pp_core.hl2.size_mobile;
            cssStyleStr += "@media only screen and (max-width: 767px) { .controls-area .headline2, .registration-page-2 .headline {";
            cssStyleStr += "font-size: " + size + "px !important;";
            cssStyleStr += "}}";
        }
        if (cssStyleStr.length > 0) {
            var customStyle = '<style type="text/css" id="dynamic-styles-prepage">' + cssStyleStr + "</style>";
            $("head").append(customStyle);
        }
        // use attr() instead of css() here, because we need "!important"
        var styleAttributeStr = "";
        if ("weight" in prepageData.prepage.pp_core.hl2) {
            styleAttributeStr += "font-weight: " + prepageData.prepage.pp_core.hl2.weight + " !important; ";
        }
        if ("align" in prepageData.prepage.pp_core.hl2) {
            styleAttributeStr += "text-align: " + prepageData.prepage.pp_core.hl2.align + " !important; ";
        }
        if (styleAttributeStr.length > 0) {
            let existingStyleStr = $(".controls-area .headline2, .registration-page-2 .headline").attr("style");
            $(".controls-area .headline2, .registration-page-2 .headline").attr("style", styleAttributeStr + existingStyleStr);
        }
    }
}
/* EDIT: ultraflex_prepage_attributes */

/**
 * Initialize the prepage quiz
 * @param totalStepCount The total number of progress steps (used by DrawProgressIndicator())
 * @param rlmsetData The sweepstake rlmset customization config data
 * @param prepageData The prepage config data
 */
function InitPrepageQuiz(totalStepCount, rlmsetData, prepageData) {
    // fetch the quiz container element
    var prepageQuizHtml = $(".prepage-quiz");
    // create a temporary image for caching quiz question images
    var tmpImage = new Image();
    // store the list of images used by the quiz questions
    var questionImages = [];
    // traverse the list of quiz questions
    var i = 0;
    // for some absurd reason, questions are not stored in an array, but as
    // object elements instead, so they are queried one by one
    while (("f" + i) in prepageData.prepage.pp_core.fragen.fragen) {
        // fetch the question data
        var question = prepageData.prepage.pp_core.fragen.fragen["f" + i];
        // build the exterior quiz question container
        var quizQuestionHtml = $('<div class="quiz-question"></div>');
        // build the question HTML code, and append it to the exterior quiz question container
        quizQuestionHtml.append('<div class="question" data-index="' + i + '">' + DecodeBase64(question.frage) + "</div>");
        // build the answers list HTML
        var answersHtml = $('<div class="answers"></div>');
        // traverse the list of quiz question answers
        for (var j in question.antworten) {
            // build the answer HTML
            answersHtml.append('<div class="answer">' + DecodeBase64(question.antworten[j]) + "</div>");
        }
        // append the answer list HTML code to the exterior quiz question container
        quizQuestionHtml.append(answersHtml);
        // append the outer container for this quiz question to the general quiz question container
        prepageQuizHtml.append(quizQuestionHtml);
        // set the image base path
        var baseImagePath = location.origin + "/ftp/flex_core/prepages/";
        // check if an image is assigned to this prepage quiz question
        if (question.bild !== undefined && question.bild.length) {
            // ...and cache the image for later use (avoids sudden image reloads during animation)
            tmpImage.src = baseImagePath + "big/" + question.bild + ".png";
            // record the full filename of the image in the image list
            questionImages.push(tmpImage.src);
        } else {
            // mark this image slot as being empty
            questionImages.push(null);
        }
        // hide all quiz questions past the first one, so they can be revealed one by one
        if (i > 0) {
            quizQuestionHtml.hide();
        }
        // move on to the next quiz question
        i++;
    }
    /* EDIT: ultraflex_prepage_attributes */
    ApplyCustomStyle(prepageQuizHtml, prepageData);
    /* EDIT: ultraflex_prepage_attributes */
    // set up the event handler for clicking on the quiz question answers
    $(".prepage-quiz .answer").click(function(event) {
        // look up the answer HTML element
        var answerElement = $(this);
        // fade out the entire quiz question area, to make room for the next one
        $(this).parent().parent().fadeOut(500, function() {
            // look up the next quiz question (if any exists), so we can show it
            var nextQuestion = answerElement.parent().parent().next();
            // if we have another quiz question...
            if (nextQuestion.length) {
                // ...fade it in
                nextQuestion.fadeIn();
            } else {
                // the quiz is finished, proceed to the actual registration stage
                FinishPrepageSection(totalStepCount, rlmsetData);
            }
        });
        // get the array index of the current quiz question, so we can look up the associated promo
        // image (if any is available)
        var questionIndex = $(this).parent().siblings(".question").data("index");
        // only fade out the current quiz question image only if an image is associated with the current
        // question
        if (questionImages[questionIndex] !== null) {
            // only perform the actual fade out if this is either the last question in the quiz, or if there
            // is another question coming up which has an image assigned
            if ((questionIndex + 1 < questionImages.length && questionImages[questionIndex + 1] !== null) ||
                questionIndex + 1 == questionImages.length) {
                // remove any pending animations from the animation queue to prevent fade animation 'pile up'
                $(".promo-img, .desktop-promo-img").stop(true);
                // fade out the currently shown selection image
                $(".promo-img, .desktop-promo-img").animate({"opacity": 0}, function() {
                    var replacementImageFile;
                    // if there is a quiz question image after this one, fade it in next
                    if (questionIndex + 1 < questionImages.length) {
                        replacementImageFile = questionImages[questionIndex + 1];
                    } else {
                        // ...otherwise just reset the image filename to the original promo image (from before
                        // the prepage quiz animation)
                        replacementImageFile = originalPromoImage;
                    }
                    // fade in the next image
                    //$(".promo-img").attr("src", replacementImageFile);
                    /* EDIT: promo_video */
                    SetPromotionImage(replacementImageFile, rlmsetData.content.promotion_video);
                    /* EDIT: promo_video */
                    // fade in the promotion <img> element
                    $(".promo-img, .desktop-promo-img").animate({"opacity": 1}, 300);
                });
            }
        }
    });
    // if an image if available for the first quiz question, show it
    if (questionImages.length && questionImages[0] !== null) {
        //$(".promo-img").attr("src", questionImages[0]);
        /* EDIT: promo_video */
        SetPromotionImage(questionImages[0], rlmsetData.content.promotion_video);
        /* EDIT: promo_video */
    }
    // show the quiz question area (completely hidden on start-up)
    prepageQuizHtml.show();
}

// keep track of the continue button label, which might change because of prepage settings, etc.
var originalContinueButtonLabel = "";
// store the original promo image filename, so it can be restored after temporary replacement
var originalPromoImage = "";
// do the same for the mobile promo image
var originalMobilePromoImage = "";


/**
 * Initialize the prepage image selector
 * @param totalStepCount The total number of progress steps (used by DrawProgressIndicator())
 * @param rlmsetData The sweepstake rlmset customization config data
 * @param prepageData The prepage config data
 */
function InitPrepageImageSelector(totalStepCount, rlmsetData, prepageData) {
    // only process the prepage data if it is available
    if (prepageData.prepage.pp_core) {
        // hide the regular counter (positioned on the left side of the screen)
        //$(".counter.prepage").addClass("visible");
        // show the prepage image selector counter instead (which will be shown
        // under the prepage image selector)
        //$(".counter.regular").addClass("hidden");
        // set the image base path
        var baseImagePath = location.origin + "/ftp/flex_core/prepages/";
        // assume that we do not have a previously set promo image
        var imagePath = null;
        // only check for a previously set promo image, if this is not the first
        // registration page
        if (!OnFirstRegPage()) {
            // attempt to fetch the name of the initially shown promo image from a cookie
            imagePath = GetCookie("promo-image");
        }
        // if the cookie doesn't exist...
        if (imagePath === null) {
            // try to fetch the image name from a hidden element passed between Coyote page sections
            if ($("#promo-image").length) {
                imagePath = $("#promo-image").val();
            } else {
                // ...build the full path of the first big image based on the first
                // available selection image
                imagePath = baseImagePath + "big/" + prepageData.prepage.pp_core.big[0] + ".png";
            }
        }
        // show the the first 'big' image because it is the default selection
        //$(".promo-img").attr("src", imagePath);
        /* EDIT: promo_video */
        SetPromotionImage(imagePath, rlmsetData.content.promotion_video);
        /* EDIT: promo_video */
        // hide the default background color
        $(".promo-img, .desktop-promo-img").css("background-color", "transparent");
        // fetch the filenames for the 'small' images
        var smallImages = prepageData.prepage.pp_core.small;
        // fetch the caption names of the 'small' images
        var tileNames = prepageData.prepage.pp_core.name;
        /*// decide whether to use a single-column or a double-column layout
        if (smallImages.length <= 3 || (smallImages.length % 2) != 0) {
            // we have less or equal three selection options or an uneven number
            // of selection options
            $(".prepage-image-selector .image-tiles").addClass("single-row");
        } else {
            // we have more than three selection options or an even number of
            // selection options
            $(".prepage-image-selector .image-tiles").addClass("double-rows");
        }*/
        // traverse the selection image array
        for (var i in smallImages) {
            // build the full thumbnail URL string
            var thumbImagePathUrl = "url('" + baseImagePath + "small/" + smallImages[i] + ".png')";
            // build the image tile HTML code
            var imageTile = $('<div class="prepage-image-selector-tile" data-image-id="' + i + '"></div>');
            // assemble the HTML code for the prepage image selector and its hover/selection overlay.
            // Mark the first image as 'selected' by default
            var selectedHtml = (i == 0) ? " selected" : "";
            // build the image thumbnail HTML code (includes an 'overlay' <div> for the selection marker)
            var thumbImageHtml = '<div class="prepage-image-selector-thumb" style="background-image: ' +
                                 thumbImagePathUrl + '"><div class="overlay' + selectedHtml + '"></div></div>';
            // append the thumbnail HTML code to the image tile container <div>
            imageTile.append(thumbImageHtml);
            // append the caption label to the image tile container
            imageTile.append("<label>" + tileNames[i] + "</label>");
            // append the current image tile container <div> to the prepage image selector section
            $(".prepage-image-selector .image-tiles").append(imageTile);
            // cache the big version of the image to make the fade out/fade in animation smoother
            var bigImage = new Image();
            bigImage.src = baseImagePath + "big/" + prepageData.prepage.pp_core.big[i] + ".png";
        }
        // attach a 'click' handler to the image tile for handling user selection
        $(".prepage-image-selector-tile .overlay").click(function(event) {
            // remove the 'selected' class from any previously selected image tiles
            $(".prepage-image-selector-tile .overlay").removeClass("selected");
            // mark the clicked on image tile as 'selected'
            $(event.target).addClass("selected");
            // fetch the image index/ID from the image tile container
            var imageId = $(event.target).parent().parent().data("image-id");
            // remove any pending animations from the animation queue to prevent fade animation 'pile up'
            $(".promo-img, .desktop-promo-img").stop(true);
            // fade out the currently shown selection image
            $(".promo-img, .desktop-promo-img").animate({"opacity": 0}, function() {
                // once the fade out has finished, build the full image path URL for the new selection image
                var imagePath = baseImagePath + "big/" + prepageData.prepage.pp_core.big[imageId] + ".png";
                // update the promotion image to show the new selection image
                //$(".promo-img").attr("src", imagePath);
                /* EDIT: promo_video */
                SetPromotionImage(imagePath, rlmsetData.content.promotion_video);
                /* EDIT: promo_video */
                // store the image filename in an infofeld, so it can be restored later when loading the CoReg page,
                // which simulates a seamless page transition
                $(".mfw_adressData_infofeld19 input").val(imagePath);
                // also set a cookie to make sure that the image path is transferred even after page reloads
                // (will not work if cookies are disabled, of course)
                //document.cookie = "promo-image=" + imagePath;
                SetCookie("promo-image", imagePath);
                /* EDIT: gws_bugfix20231006 */
                SetCookie("promo-mobile-image", imagePath);
                /* EDIT: gws_bugfix20231006 */
                // after changing the image, reset the faded out opacity back to full opacity
                $(".promo-img, .desktop-promo-img").animate({"opacity": 1});
            });
        });
        // build custom CSS styles for the selection overlay images.
        // Build the full image URLs for the selection and hover overlay images
        var overlayImagePathUrl = "url('" + baseImagePath + "small/" + prepageData.prepage.pp_core.pp_select + ".png')";
        var hoverImagePathUrl = "url('" + baseImagePath + "small/" + prepageData.prepage.pp_core.pp_hover + ".png')";
        // set up the 'selection' overlay style
        var overlayStyleHtml = '<style type="text/css">.prepage-image-selector-tile .overlay.selected {background-image: ' + overlayImagePathUrl + "}";
        // set up the 'hover' overlay style
        overlayStyleHtml += " .prepage-image-selector-tile .overlay:not(.selected):hover {background-image: " + hoverImagePathUrl + "}";
        // append the new style section to the <head> element of the HTML document
        $("head").append(overlayStyleHtml + "</style>");
    }
    // check if the prepage continue button label should overwrite the original 'Continue' button text
    if (prepageData.prepage.pp_core.button !== undefined && prepageData.prepage.pp_core.button.length) {
        // store the original 'Continue' button label
        originalContinueButtonLabel = $(".continue-button .button-label .label").html();
        // set the 'Continue' button label to the text found in the prepage config data
        $(".continue-button .button-label").html(DecodeBase64(prepageData.prepage.pp_core.button));
    }
    // set up the 'Continue' button click event handler
    $(".prepage-image-selector .continue-button").click(function(event) {
        // hide the image selector area
        $(".prepage-image-selector").hide();
        // check if the 'Continue' button text was overwritten by a prepage config setting
        if (originalContinueButtonLabel.length) {
            // restore the original button label
            $(".continue-button .button-label").html(originalContinueButtonLabel);
        }
        // finish up the prepage section and proceed to the first user registration page
        FinishPrepageSection(totalStepCount, rlmsetData, Translate(prepageProcessingMessage));
    });
    // after completing the image selector view setup, show the image selector
    $(".prepage-image-selector").show();
}

/**
 * Pad a number value with leading characters
 * @param number The number to be padded
 * @param padChar The character (or sting) to be used for padding
 * @param padCount The length of the final number sequence (will be padded if necessary)
 */
function PadNumber(number, padChar, padCount) {
    // convert the number to a string, so we can measure its length
    var numStr = number.toString();
    // check if the number string is so short that it needs to be padded
    if (numStr.length < padCount) {
        // build the padded string
        var paddedStr = "";
        // add the beginning, add the padding characters
        for (var i = 0; i < padCount - numStr.length; i++) {
            paddedStr += padChar;
        }
        // add the number to the padded string
        paddedStr += numStr;
        // return the padded string
        return paddedStr;
    } else {
        // no padding necessary, return the original number instead
        return number;
    }
}

/**
 * Format a clock time (pad it with leading zeros)
 * @param minutes The number of minutes
 * @param seconds The number of seconds
 * @param milliseconds The number of milliseconds
 * @return The formatted time string
 */
function FormatClockTime(minutes, seconds, milliseconds) {
    // initialize the time string
    var timeStr = "";
    // pad minutes with leading zeros if necessary
    if (minutes < 10) {
        timeStr += "0" + minutes;
    } else {
        timeStr += minutes;
    }
    // add the separator
    timeStr += ":";
    // pad seconds with zeros if necessary
    if (seconds < 10) {
        timeStr += "0" + seconds;
    } else {
        timeStr += seconds;
    }
    // add the separator
    timeStr += ":";
    // pad milliseconds with zeros if necessary
    timeStr += PadNumber(milliseconds, "0", 2);
    // return the formatted time string
    return timeStr;
}

/**
 * Initialize and run the countdown clock
 * @param clockConfigData The configuration data for the clock
 */
function RunCountdownClock(clockConfigData) {
    if (clockConfigData.type == "clock") {
        // initialize the clock by setting it to the start time.
        // (make sure that we don't have any leading zeros, etc. as part of the numbers)
        var minutes = parseInt(clockConfigData.starttime.split(":")[0]);
        var seconds = parseInt(clockConfigData.starttime.split(":")[1]);
        // clip minutes to a maximum value
        if (minutes > 99) {
            minutes = 99;
        }
        // limit minutes to a minimum value
        if (minutes < 0) {
            minutes = 0;
        }
        // clip seconds to a maximum value
        if (seconds > 60) {
            seconds = 60;
        }
        // limit seconds to a minimum value
        if (seconds < 0) {
            seconds = 0;
        }
        // set the initial clock time
        $(".counter .clock").text(FormatClockTime(minutes, seconds, 0));
        // record the current time (in milliseconds) to use for comparison
        var startTime = Date.now();
        // convert the user-configured time to milliseconds
        var totalTimeMilliseconds = minutes * 60 * 1000 + seconds * 1000;
        // set up the clock update interval function
        var clockUpdateTimer = setInterval(function() {
            // calculate how much time has passed (in milliseconds)
            var deltaTime = Date.now() - startTime;
            // calculate how much is left (the actual countdown)
            var convertedTime = totalTimeMilliseconds - deltaTime;
            // if there is time left to count down...
            if (convertedTime >= 0) {
                // calculate the number of minutes left (and convert them to milliseconds)
                var minutesAsMilliseconds = parseInt(convertedTime / (60 * 1000)) * 60 * 1000;
                // calculate the number of seconds left (and convert them to milliseconds)
                var secondsAsMilliseconds = parseInt((convertedTime - minutesAsMilliseconds) / 1000) * 1000;
                // calculate the extracted number of minutes
                var minutes = minutesAsMilliseconds / (1000 * 60);
                // calculate the extracted number of seconds
                var seconds = secondsAsMilliseconds / 1000;
                // calculate the number of milliseconds (left after subtracting minutes and seconds from the total time)
                var milliseconds = convertedTime - minutesAsMilliseconds - secondsAsMilliseconds;
                // round the milliseconds to two digits and then scale them to make an integer value
                var millisecondsAsSeconds = milliseconds / 1000;
                milliseconds = millisecondsAsSeconds.toFixed(2) * 1000 / 10;
                // show the value 100 (3 digits) to as 0 instead (padded to two digits)
                if (milliseconds == 100) {
                    milliseconds = 0;
                }
                // update the clock display
                $(".counter .clock").text(FormatClockTime(minutes, seconds, milliseconds));
            } else {
                // set the clock display to its final value
                $(".counter .clock").text(FormatClockTime(0, 0, 0));
                // stop the clock updates from happening
                clearInterval(clockUpdateTimer);
                // hide the original pre-clock text
                $(".counter .pre-clock").hide();
                //$(".counter .post-clock").show();
                // only show the 'post clock' text, when an actual 'post clock' information text was set
                if ($("label.post-clock").text().trim().length) {
                    // hide the clock element (which would show '00:00.00' now)
                    $(".counter .clock").hide();
                    // show the 'post clock' information text
                    $(".counter .post-clock-container").show();
                    // show the 'down here' arrow hint animation
                    $(".counter .arrow-image-anim").addClass("visible");
                } else {
                    // when no 'post clock' text was set, hide the whole clock element instead
                    $("div.counter").fadeOut(150);
                }
            }
        }, 10);
    } else if (clockConfigData.type == "days") {
        // split the German date format into its individual elements
        var endDateElements = clockConfigData.enddate.split(".");
        // only proceed if we have what looks like a valid date
        if (endDateElements.length == 3) {
            // re-assemble the date in US format for further processing
            var formattedEndDate = endDateElements[2] + "-" + endDateElements[1] + "-" + endDateElements[0];
            // query the remaining number of days from the 'days_left' service
            $.get(location.origin + "/ftp/flexfancy/services/days_left.php?enddate=" + formattedEndDate,
                  function(data) {
                      // take the plural/singular into account when labeling the days
                      if (Math.abs(data.days_left) == 1) {
                          var dayStr = " Tag";
                      } else {
                          var dayStr = " Tage";
                      }
                      // set the clock text to the number of days left
                      $(".counter .clock").text(data.days_left + dayStr);
                  });
        }
    }
}

/**
 * Update the visual representation of the current user progress
 * @param totalStepCount The total number of steps to be taken by the user
 * @param currentStep The current step position of the user
 * @param configData The sweepstake customization config data
 * @param showTopIndicator Whether to show the progress indicator at the top of the screen
 */
function UpdateUserProgress(totalStepCount, currentStep, configData, showTopIndicator) {
    /*// allow the value of -1 as a placeholder for the last step in the process
    if (currentStep == -1) {
        currentStep = totalStepCount;
    }
    // decide whether to show the progress indicator at the top of the screen
    if (showTopIndicator !== false) {
        // draw a progress indicator at the top of the screen
        DrawProgressIndicator(totalStepCount, currentStep, configData);
    }
    // update the user progress text string
    $(".progress-area .progress-text").text(Translate("Schritt ") + currentStep + Translate(" von ") + totalStepCount);
    // if the total step count is only 2 (because there is no prepage), shorten the number of steps
    // displayed in the bottom bar
    if (totalStepCount == 2) {
        // hide the third step
        $(".step-count.step-3").parent().hide();
        // turn the second step into the 'new' last step
        $(".step-count.step-2 + label").text(Translate("Fast geschafft!"));
        // assign the progress images used by a two-step progress bar
        $(".step-count.step-1 .progress-image").addClass("input");
        $(".step-count.step-2 .progress-image").addClass("gift");
    } else if (totalStepCount == 3) {
        // assign the progress images used by a three-step progress bar
        $(".step-count.step-1 .progress-image").addClass("question");
        $(".step-count.step-2 .progress-image").addClass("input");
        $(".step-count.step-2 .progress-image").addClass("gift");
    }
    // update the progress indicators in the sweepstake footer
    $(".bottom-bar-content .progress-step").removeClass("active");
    // traverse all bottom-bar progress markers
    $(".bottom-bar-content .progress-step").each(function(index, element) {
        // mark all progress markers before the current one as completed, and make sure that
        // none of them is active anymore
        if (index + 1 < currentStep) {
            $(element).removeClass("active");
            $(element).addClass("completed");
        } else {
            // mark the current progress marker as active
            $(element).addClass("active");
            // abort loop traversal after the current progress indicator
            return false;
        }
    });*/
}

/**
 * Initialize all text switch controls (essentially fancy comboboxes)
 */
function InitTextSwitchControls() {
    // attach 'click' handlers to the button <divs> inside the switch controls
    $(".text-switch div").click(function(event) {
        // fetch the target element
        var targetElement = $(event.target);
        // if this text switch option isn't selected yet...
        if (!targetElement.hasClass("selected")) {
            // mark it as selected
            targetElement.addClass("selected");
            // if we clicked on the left text switch option, deselect the right one
            if (targetElement.hasClass("left")) {
                // remove the 'selected' class from the right sibling <div>
                targetElement.parent().find(".right").removeClass("selected");
            } else if (targetElement.hasClass("right")) {
                // remove the 'selected' class from the left sibling <div>
                targetElement.parent().find(".left").removeClass("selected");
            }
            // if the text switch control elements have values associated with them, pass them on
            // to the hidden 'appellation' select element
            if (targetElement.data("value")) {
                // assign the 'appellation' value
                $(".mfw_adressData_anrede select").val(targetElement.data("value"));
            }
        }
    });
}

/* EDIT: frank_coregs */
/**
 * Show an info popup dialog
 * @param infoTitle string The dialog title text
 * @param contentType string The content type of the dialog ("agb", "impressum", etc.)
 * @param contentTarget string The content target of the dialog ("hoerzu", "tvdigital", etc.)
 */
function show_info_popup(infoTitle, contentType, contentTarget) {
    // use a GET request to read the content text for this info popup
    $.get("/ftp/flexblocks/extra_html/coregs/" + contentTarget + "/" + contentType + ".html", function(data) {
        // set the dialog title text
        $(".info-popup .header-text").text(infoTitle);
        // clear the existing content
        $(".info-popup .content").empty();
        // add the content text to the dialog
        $(".info-popup .content").append(data);
        // show the dialog
        $(".info-popup").show();
        // scroll to the top of the dialog, so the user can see the text
        //$(document).scrollTop($(".info-popup").offset().top - 5);
    });
}

/* EDIT: brandbüro_fix20190730 */
/**
 * Button 'click' handler for Brandbüro CoRegs
 * @param event The event object
 * @param buyButtonObj The 'buy' button of a particular Brandbüro CoReg
 */
function BrandbueroBuyButtonCallback(event, buyButtonObj) {
    // if buyButtonObj is not defined, this is called as a regular event handler
    if (typeof (buyButtonObj) == "undefined") {
        // the event version of "this"
        var buyButton = $(this);
    } else {
        // this function is not called as a regular event handler, so fetch the
        // the buy button object from the parameter list
        var buyButton = buyButtonObj;
    }
    // traverse all radiobuttons which are attached to this CoReg
    buyButton.parent().parent().parent().find(".radio-button").each(function(index) {
        // find the "checked" radiobutton
        if ($(this).hasClass("checked")) {
            // find the (hidden) tile answers which belong to this radiobutton
            var coregAnswers = buyButton.parent().parent().find(".coregAnswer");
            // only proceed if one or more tile answers could be found
            if (coregAnswers.length > index) {
                // traverse all found tile answers
                for (var i = 0; i < coregAnswers.length; i++) {
                    // if the index of the current tile answer matches the index
                    // of the checked radiobutton, simulate a mouse click
                    if (i == index) {
                        var answerInput = $(coregAnswers[i]).find("input.radio");
                        /* EDIT: rlm_stat_analytics */
                        var coregId = GetCoregIdFromElement(buyButton.parent().parent());
                        if (typeof RlmStat !== "undefined") {
                            RlmStat.CoregEnd(coregId, answerInput.val(), $(coregAnswers[i]).hasClass("positive-answer") ? 1 : 0);
                        }
                        /* EDIT: rlm_stat_analytics */
                        answerInput.first().prop("checked", true).trigger("click");
                    }
                }
            }
        }
    });
    // proceed to the next CoReg or exit page
    hide_coreg_and_show_next(true);
}
/* EDIT: brandbüro_fix20190730 */

/**
 * Apply custom design and behaviour code to Brandbüro CoRegs (radiobuttons instead of tile buttons, etc.)
 */
function apply_frank_coreg_changes() {
    // create the basic info-popup structure
    //$("#mfw_fieldset_ownCoregData").css("position", "relative");
    var infoPopupHtml = '<div class="info-popup"><div class="header"><div class="header-text">Header Text</div><div class="close-button"></div></div><div class="content"></div><div class="close-text-button">Schließen</div></div>';
    // append the new popup to the page DOM
    $(infoPopupHtml).appendTo("#mfw_fieldset_ownCoregData");
    //(infoPopupHtml).appendTo(".right-area");
    // attach a close event handler to the "close" buttons (titlebar and bottom of popup dialog)
    $(".info-popup .close-button, .info-popup .close-text-button").click(function(event) {
        // hide the info popup window
        $(".info-popup").hide();
    });
    // the IDs of the CoRegs which will styled differently (radio buttons, etc.)
    /* EDIT: myself_coreg */
    /* EDIT: spiegel_coreg20200205 */
    /* EDIT: donna_coreg */
    /* EDIT: geo_coreg */
    var coregIds = [1000, 1001, 1002, 1075, 1086, 1104, 1115];
    /* EDIT: geo_coreg */
    /* EDIT: donna_coreg */
    /* EDIT: spiegel_coreg20200205 */
    /* EDIT: myself_coreg */
    // traverse all listed coregs
    for (var i in coregIds) {
        // build the correct CoReg class
        var coregClass = ".mfw_coreg_" + coregIds[i];
        // fetch the CoReg container element
        var coregContainer = $(coregClass);
        // assign a class which can be used for easily identifying these CoRegs
        coregContainer.addClass("shop-coreg");
        // move the CoReg image element to a new position
        coregContainer.find(".coreg-image-wrapper").insertBefore(coregContainer.find(".coregHeadline"));
        coregContainer.find(".coreg-image-wrapper").css("margin-top", 0);
        coregContainer.find(".coreg-image-wrapper").css("margin-bottom", "15px");
        // make the whole radio button areas (including the labels) clickable
        $(coregClass + " .click-wrapper").click(function(event) {
            // the info text area
            var infoText = $(this).parent().parent().parent().parent().parent().find(".coregAdvice");
            // the buy button element
            var buyButton = $(this).parent().parent().parent().parent().parent().find(".buy-button-container");
            // positive answer options will fade in info text and 'buy' button
            if (!$(this).find(".radio-button").hasClass("negative")) {
                // fade in additional info text
                infoText.fadeIn(400);
                // fade in the "buy" button (which should be the only configured CoReg answer)
                buyButton.fadeIn(400);
            } else if (infoText.is(":visible") && buyButton.is(":visible")) {
                // negative answer options will simply hide info text and 'buy' button
                infoText.hide();
                buyButton.hide();
            }
        });
        // set up the "buy" button HTML
        var buyButtonHtml = '<div class="buy-button-container"><div class="buy-button">';
        // check if the user-created "radio-box" element exists and has some button label
        // text attached to it
        if ($(coregClass + " .radio-box").length &&
            typeof $(coregClass + " .radio-box").data("button-label") != "undefined") {
            // use the user-provided label text for the "buy" button
            var buttonLabelText = $(coregClass + " .radio-box").data("button-label");
        } else {
            // when no user-text was provided, use a default text string
            var buttonLabelText = "Jetzt bestellen";
        }
        // append the label text to the "buy" button
        buyButtonHtml += buttonLabelText + '</div></div>';
        // add the new "buy" button at the end of the CoReg
        $(buyButtonHtml).insertAfter(coregClass + " .coregAnswers");
        // attach a 'click' handler to the "buy" button
        /* EDIT: brandbüro_fix20190730 */
        $(coregClass + " .buy-button").click(BrandbueroBuyButtonCallback);
        /* EDIT: brandbüro_fix20190730 */
        // }
        // attach a 'click' handler to the radio button areas
        $(coregClass + " .click-wrapper").click(function(event) {
            // remove the 'checked' class from the currently selected radiobutton
            $(this).parent().parent().find("div.radio-button").removeClass("checked");
            // add the 'checked' class to the recently clicked on radiobutton
            $(this).find("div.radio-button").addClass("checked");
            /* EDIT: brandbüro_fix20190730 */
            // if this is a negative answer option, move on to the next CoReg automatically
            if ($(this).find("div.radio-button.negative").length) {
                // proceed to the next CoReg or exit page
                //hide_coreg_and_show_next(true);
                // the buy button element
                var buyButton = $(this).parent().parent().parent().parent().parent().find(".buy-button");
                // send the negative answer to the server
                BrandbueroBuyButtonCallback(null, buyButton);
            }
            /* EDIT: brandbüro_fix20190730 */
        });
        // attach a 'click' handler to the links which are supposed to open
        // info popup windows
        $(coregClass + " .info-popup-link").click(function(event) {
            // set the default content type (usually "agb", "impressum", etc.)
            var contentType = "none";
            // set the default title of the info popup
            var infoTitle = "Infofenster";
            // set up some info based on the user-selected info content type class
            if ($(this).hasClass("agb")) {
                contentType = "agb";
                infoTitle = "AGB";
            } else if ($(this).hasClass("impressum")) {
                contentType = "impressum";
                infoTitle = "Impressum";
            } else if ($(this).hasClass("lieferbedingungen")) {
                contentType = "lieferbedingungen";
                infoTitle = "Lieferbedingungen";
            }
            /* EDIT: geo_coreg */
            else if ($(this).hasClass("datenschutz")) {
                contentType = "datenschutz";
                infoTitle = "Datenschutz";
            } else if ($(this).hasClass("widerruf")) {
                contentType = "widerruf";
                infoTitle = "Widerruf";
            }
            /* EDIT: geo_coreg */
            else {
                // the user did not choose a valid info content type
                console.log("error: info-popup-link: no content type specified!");
            }
            // set the user-selected CoReg target (hoerzu, tvdigital, etc.)
            var contentTarget = $(this).data("target");
            // only show the the info popup if a valid content type was provided
            if (contentType != "none" && typeof contentTarget !== "undefined") {
                show_info_popup(infoTitle, contentType, contentTarget);
            } else {
                // the user did not choose a valid info content type
                console.log("error: info-popup-link: no content target specified!");
            }
            // prevent the default link action from being triggered
            event.preventDefault();
        });
    }
}
/* EDIT: frank_coregs */

/* EDIT: fisherprice_coreg */
/**
 * Determine whether a value falls within a specified range
 * @param value The value to be tested
 * @param minVal The allowed minimum value
 * @param maxVal The allowed maximum value
 * @return boolean Whether the value falls within range
 */
function InRange(value, minVal, maxVal) {
    return (value >= minVal && value <= maxVal);
}

/**
 * Check if a date falls within a certain year span
 * @param day The day of the date
 * @param month The month of the date
 * @param year The year of the date
 * @param yearSpan The year span (e.g. "2" for checking the last two years)
 * @return boolean Whether the date falls in the range or not
 */
function CheckMaxAge(day, month, year, yearSpan) {
    // fetch the day/month/year elements of the current date
    var currentDate = new Date();
    var currentYear = currentDate.getFullYear();
    var currentMonth = currentDate.getMonth() + 1;
    var currentDay = currentDate.getDate();
    // if the given year is in the future, don't evaluate the age range
    if (year > currentYear) {
        return false;
    } else if (year == currentYear) {
        // the user has entered the current year, so check if month or day
        // are in the future
        if (month > currentMonth) {
            return false;
        } else if (month == currentMonth) {
            // the user has entered the current year and month, so check if
            // the day of the date is in the future
            if (day > currentDay) {
                return false;
            }
        }
    }
    // if the given year falls within the last two years,
    // the age is okay
    if (year > currentYear - yearSpan) {
        return true;
    } else if (year < currentYear - yearSpan) {
        // the year is older than the given age
        return false;
    } else {
        // ...the year is exactly the current year minus
        // the time span
        if (month > currentMonth) {
            // the given month is greater than the current month,
            // so the age is younger than the max. time span
            return true;
        } else if (month < currentMonth) {
            // the given month is smaller than the current month,
            // so the age is older than the max. time span
            return false;
        } else {
            // the given date is current date - time span old,
            // and the months are identical. So we just need to
            // compare the days of the dates
            if (day >= currentDay) {
                // the given day is greater than the current day,
                // which means that the given date is younger than
                // the max. time span
                return true;
            } else {
                // ...otherwise, the given date is older than the
                // time span
                return false;
            }
        }
    }
}

/**
 * Show a message box for the Fisher-Price CoReg
 * @param message The message to be shown
 */
function FP_ShowMessage(message) {
    // only show or update the message box if is not yet visible
    if (!FP_MessageBoxIsVisible()) {
        // set the message box text
        $(".mfw_coreg_1054 .fisherprice-message-box .fisherprice-message").html(message);
        // show the message box
        $(".mfw_coreg_1054 .fisherprice-message-box").slideDown(90);
        // set up a timeout which will close the message box
        setTimeout(function() {
            $(".mfw_coreg_1054 .fisherprice-message-box").slideUp(200);
        }, 4000);
    }
}

/**
 * Checks if the Fisher-Price message box is visible
 * @return boolean Whether the message is already visible
 */
function FP_MessageBoxIsVisible() {
    return $(".mfw_coreg_1054 .fisherprice-message-box").is(":visible");
}

/**
 * Apply some modifications to the Fisher-Price CoReg
 */
function apply_fisherprice_coreg_changes() {
    // only modify the Fisher-Price CoReg if it is available
    if ($(".mfw_coreg_1054").length) {
        // build the custom CoReg contents (including 'buy' button, etc.)
        var htmlStr = `<div class="fisherprice-coreg">
            <div class="info-label">
                Bitte Geburtstag des Kindes eingeben:
            </div>
            <div class="fisherprice-inputs">
                <input class="birthdate-day" />
                <input class="birthdate-month" />
                <input class="birthdate-year" />
                <span class="birthdate-label">TT/MM/JJJJ</span>
            </div>
            <div class="fisherprice-buy-button">
                Absenden
            </div>
            <div class="fisherprice-skip-button">
                Nein, danke
            </div>
        </div>`;
        // append the cutom CoReg elements to the DOM
        $(".mfw_coreg_1054 .coregHeader").append(htmlStr);
        // assign a 'click' handler to the 'buy' button
        $(".fisherprice-buy-button").click(function(event) {
            // fetch input values and remove whitespace characters
            var birthDateDay = parseInt($(".fisherprice-coreg input.birthdate-day").val().trim());
            var birthDateMonth = parseInt($(".fisherprice-coreg input.birthdate-month").val().trim());
            var birthDateYear = parseInt($(".fisherprice-coreg input.birthdate-year").val().trim());
            // make sure that empty input fields don't end up as NaN values
            // (which will confuse some checks down the road)
            if (isNaN(birthDateDay)) {
                birthDateDay = 0;
            }
            if (isNaN(birthDateMonth)) {
                birthDateMonth = 0;
            }
            if (isNaN(birthDateYear)) {
                birthDateYear = 0;
            }
            // if any input field value is invalid, don't transfer the birthdate value
            var isError = false;
            // validate the birthday date
            if (!birthDateDay || !InRange(birthDateDay, 1, 31)) {
                isError = true;
                $(".mfw_coreg_1054 input.birthdate-day").addClass("input-error");
            }
            // validate the birthdate month
            if (!birthDateMonth || !InRange(birthDateMonth, 1, 12)) {
                isError = true;
                $(".mfw_coreg_1054 input.birthdate-month").addClass("input-error");
            }
            // validate the birthdate year
            if (!birthDateYear) {
                isError = true;
                $(".mfw_coreg_1054 input.birthdate-year").addClass("input-error");
            }
            if (isError) {
                FP_ShowMessage("Bitte geben Sie gültige Datumswerte ein.");
            }
            // the maximum allowed age to be entered
            var maxYearSpan = 2;
            // check if the given date is <= 2 years old
            if (!isError &&
                !CheckMaxAge(birthDateDay, birthDateMonth, birthDateYear, maxYearSpan)) {
                isError = true;
                // highlight all input fields, because the entire date is out
                // of range
                $(".mfw_coreg_1054 input.birthdate-day").addClass("input-error");
                $(".mfw_coreg_1054 input.birthdate-month").addClass("input-error");
                $(".mfw_coreg_1054 input.birthdate-year").addClass("input-error");
            }
            // only submit the birthdate if all information was given
            if (!isError) {
                // add a leading 0 to day and month, if necessary
                birthDateDay = (birthDateDay.toString().length < 2) ? '0' + birthDateDay : birthDateDay;
                birthDateMonth = (birthDateMonth.toString().length < 2) ? '0' + birthDateMonth : birthDateMonth;
                // update the date input fields with their final values
                $(".mfw_coreg_1054 input.birthdate-day").val(birthDateDay);
                $(".mfw_coreg_1054 input.birthdate-month").val(birthDateMonth);
                // assemble the full birthdate
                var fullBirthDate = `${birthDateDay}.${birthDateMonth}.${birthDateYear}`;
                // transfer the birthdate value to the server
                $("#coreg1054_answer1").val(fullBirthDate);
                // remove all custom input elements from the DOM, to avoid that their
                // values get sent to the server
                $(".fisherprice-inputs").empty();
                // trigger the "send" button of this CoReg
                $(".coregsend1054.button").trigger("click");
                /* EDIT: rlm_stat_analytics */
                // track the CoReg click event for statistics purposes
                if (typeof RlmStat !== "undefined") {
                    RlmStat.CoregEnd(1054, fullBirthDate, 1);
                }
                /* EDIT: rlm_stat_analytics */
                // move on to the next CoReg question
                hide_coreg_and_show_next(true);
            } else {
                FP_ShowMessage("Das Kind darf maximal zwei Jahre alt sein.");
            }
        });
        // assign a 'click' handler to the 'skip' button
        $(".fisherprice-skip-button").click(function(event) {
            // hide the CoReg and move on to the next one
            hide_coreg_and_show_next(true);
            /* EDIT: rlm_stat_analytics */
            // track the CoReg as 'completed'
            if (typeof RlmStat !== "undefined") {
                RlmStat.CoregEnd(1054, "", 0);
            }
            /* EDIT: rlm_stat_analytics */
        });
        // make sure that the input elements clear their error states on input
        $(".mfw_coreg_1054 input").on("input", function(event) {
            $(".mfw_coreg_1054 input").removeClass("input-error");
            // hide the (error) message box
            $(".mfw_coreg_1054 .fisherprice-message-box").hide();
        });
        // add HTML code for displaying info messages
        var messageBoxHtmlStr = `<div class="fisherprice-message-box">
            <div class="fisherprice-message"></div>
        </div>`;
        $(".mfw_coreg_1054 .coregHeader").append(messageBoxHtmlStr);
    }
}
/* EDIT: fisherprice_coreg */

/* EDIT: o2_coreg */
/**
 * Apply some modifications to the O2 CoReg
 */
function apply_o2_coreg_changes() {
    // only apply these modifications if we are on the CoReg page and
    // if the CoReg is assigned to this campaign
    /*if (OnCoregPage() && $(".mfw_coreg_1070").length) {
        var basePageUrl = "https://ilead.itrack.it/clients/ext.aspx?openpopup=0&targetpage=popup&cid=20244&sid=135007&wid=14629";
        var prefillParmStr = "&swid=platzhalter";
        prefillParmStr += "&salutation=" + encodeURIComponent($("#o2-prefill-salutation").val());
        prefillParmStr += "&firstname=" + encodeURIComponent($("#o2-prefill-firstname").val());
        prefillParmStr += "&lastname=" + encodeURIComponent($("#o2-prefill-lastname").val());
        prefillParmStr += "&email=" + encodeURIComponent($("#o2-prefill-email").val());
        prefillParmStr += "&street=" + encodeURIComponent($("#o2-prefill-street").val());
        prefillParmStr += "&streetnumber=" + encodeURIComponent($("#o2-prefill-streetnumber").val());
        prefillParmStr += "&postcode=" + encodeURIComponent($("#o2-prefill-postcode").val());
        prefillParmStr += "&city=" + encodeURIComponent($("#o2-prefill-city").val());
        prefillParmStr += "&telephone_areacode=" + encodeURIComponent($("").val());
        prefillParmStr += "&telephone=" + encodeURIComponent($("#o2-prefill-telephone").val());
        prefillParmStr += "&birthday=" + encodeURIComponent($("#o2-prefill-birthday").val());
        var o2InputElement = $(".mfw_coreg_1070 .coregAnswer.positive-answer input");
        o2InputElement.attr("onclick", "window.open('" + basePageUrl + prefillParmStr + "')");
    }*/
    // append info text HTML code
    if (OnCoregPage() && $(".mfw_coreg_1070").length) {
        var htmlStr = `<div class="o2-info-text">
                           <p>Bitte lesen Sie auch die Bestimmungen zum <a href="https://static.itrack.it/clients/DEo2_2015/c20244/widerruf.html" target="_blank">Widerrufsrecht</a>
                           und unsere <a href="https://www.o2.de/goto/loop/agb" target="_blank">AGBs</a>.</p>
                       </div>`;
        $(".mfw_coreg_1070 .coregContainer").append(htmlStr);
    }
}
/* EDIT: o2_coreg */

/* EDIT: tile_coregs_dynamic */
/**
 * Assign incrementing ID values (indices) to all CoReg questions for easy iterative traversal
 */
function assign_coreg_indices() {
    // traverse all CoReg questions
    $(".coregContainer").each(function(index, value) {
        // create ID (index) data info
        $(value).data("id", index + 1);
    });
}
/* EDIT: tile_coregs_dynamic */

function show_first_coreg() {
    // select all CoReg question/answer blocks, so that we can hide some of them
    /* EDIT: tile_coregs_dynamic */
    //var coregWrappers = $(".app_coreg.new_style");
    var coregWrappers = $(".coregContainer");
    /* EDIT: tile_coregs_dynamic */
    // traverse all available CoRegs
    for (var i = 0; i < coregWrappers.length; i++) {
        var coregWrapper = $(coregWrappers[i]);
        // only show the first CoReg question, and hide the rest
        if (coregWrapper.data("id") > 1) {
            coregWrapper.parent().hide();
            /* EDIT: rlm_stat_analytics */
        } else {
            // record the parent element of the first shown CoReg
            currentCoregParent = coregWrapper.parent();
            // fetch the ID of the first visible CoReg
            var coregId = GetCoregIdFromElement(coregWrapper);
            // record a 'show' event for this CoReg
            if (typeof RlmStat !== "undefined") {
                RlmStat.CoregStart(coregId);
            }
        }
        /* EDIT: rlm_stat_analytics */
        /* EDIT: coreg_slider */
    }
    /* EDIT: coreg_of_the_day */
    // check if any CoReg has been selected as a 'CoReg of the day'
    /*var highlightContainer = get_highlight_coreg();
    if (highlightContainer &&
        $(coregWrappers[0]).data("value") == highlightContainer.data("value")) {
        // show the 'CoReg of the day' animation
        show_message_star();
    }*/
    /* EDIT: coreg_of_the_day */
}

/**
 * Look up a CoReg container by its index number
 * @param index The assigned index value of the CoReg container
 * @return The looked up CoReg container or null if the look-up failed
 */
function get_coreg_container_by_index(index) {
    var coregContainers = $(".coregContainer");
    for (var i in coregContainers) {
        if ($(coregContainers[i]).data("id") == index) {
            return $(coregContainers[i]);
        }
    }
    return null;
}

/**
 * Display the next CoReg question
 *
 * @param showNextCoreg Whether to show the next CoReg question after updating the progressbar
 */
function show_next_coreg(showNextCoreg) {
    // calculate the current CoReg question progress percentage
    /* EDIT: coreg_tile_answers */
    // apply a weighted balance to the CoReg completion percentage calculation
    /*if (totalCoregCount > weightedCoregCount) {
        if (clickedCoregCount <= weightedCoregCount) {
            var percent = Math.round(.5 / weightedCoregCount * clickedCoregCount * 100);
        } else {
            var percent = Math.round((.5 + clickedCoregCount / totalCoregCount * .5) * 100);
        }
    } else {
        var percent = Math.round(clickedCoregCount / totalCoregCount * 100);
    }*/
    var percent = Math.round(initProgress + ((100 - initProgress) / totalCoregCount * clickedCoregCount));
    /* EDIT: coreg_tile_answers */
    // update the progressbar percentage value to reflect the survey progress
    set_progress($(".progressbar"), percent);
    // start counting up to the current percentage value from the last recorded percentage value
    currentPercentage = lastPercentage;
    // calculate the total difference between the current and the last percentage values
    var percentDelta = percent - lastPercentage;
    // set up an interval function for incrementing the percentage value one by one
    percentInterval = setInterval(function() {
        // if we have reached the targeted percentage value, clear the interval
        /* EDIT: coreg_slider */
        /* EDIT: coreg_tile_answers */
        if (currentPercentage + 1 > percent) {
        /* EDIT: coreg_tile_answers */
        /* EDIT: coreg_slider */
            clearInterval(percentInterval);
            /* EDIT: coreg_tile_answers */
            // once the last survey question has been answered, show the second CoReg stage
            /*if (percent == Math.round(coregCount / totalCoregCount * 100)) {
                show_secondary_coregs();
            }*/
            /* EDIT: coreg_tile_answers */
        } else {
            // ...we are still counting up to the target percentage value
            currentPercentage++;
            // update the progressbar text
            $(".progressbar span").text(currentPercentage + " %");
        }
    }, 500 / percentDelta);
    // remember the current percentage as the number to start counting from when we move to the next CoReg
    lastPercentage = percent;
    // only move to the next CoReg question if we are allowed to, and if we haven't reached the end of the
    // CoReg list yet
    /* EDIT: coreg_slider */
    if (showNextCoreg && (coregSlider || clickedCoregCount < coregCount)) {
        // look up the next available CoReg question...
        /* EDIT: tile_coregs_dynamic */
        //var nextCoregParent = $(".app_coreg.new_style[data-id=" + (clickedCoregCount + 1) + "]").parent();
        var nextCoregParent = get_coreg_container_by_index(clickedCoregCount + 1);
        if (nextCoregParent !== null) {
            nextCoregParent = nextCoregParent.parent();
            /* EDIT: tile_coregs_dynamic */
            // update currentCoregParent so that it points to the new CoReg
            currentCoregParent = nextCoregParent;
            // ...and show the CoReg
            /* EDIT: coreg_of_the_day */
            // check if a highlight CoReg ('CoReg of the day') exists
            /*var highlightContainer = get_highlight_coreg();
            // look up the .coregContainer element of the next CoReg
            var nextCoregContainer = nextCoregParent.find(".coregContainer");
            // if the upcoming CoReg is the highlight CoReg, show a special animation
            if (highlightContainer &&
                highlightContainer.data("value") == nextCoregContainer.data("value")) {
                // show the 'CoReg of the day' animation
                show_message_star();
            }*/
            // show the hidden .coregContainer element, so it will be visible when the
            // parent element fades in
            nextCoregParent.find(".coregContainer").show();
            // fade in the actual .coregContainer element
            nextCoregParent.fadeIn(250);
            /* EDIT: rlm_stat_analytics */
            // fetch the ID of the upcoming CoReg
            var coregId = GetCoregIdFromElement(nextCoregParent);
            // track the CoReg 'show' event
            if (typeof RlmStat !== "undefined") {
                RlmStat.CoregStart(coregId);
            }
            /* EDIT: rlm_stat_analytics */
            /* EDIT: coreg_of_the_day */
        /* EDIT: tile_coregs_dynamic */
        }
        /* EDIT: tile_coregs_dynamic */
    }
    /* EDIT: coreg_slider */
}

/**
 * Hide the current CoReg and show the next one
 * @param increaseClickedCoregs Whether to increase the count of clicked CoRegs
 */
function hide_coreg_and_show_next(increaseClickedCoregs) {
    if (currentCoregParent) {
        // allow this function to increment the clicked CoReg count itself
        if (increaseClickedCoregs) {
            clickedCoregCount++;
            /* EDIT: progressbar_neu20210305 */
            // update the CoReg progressbar
            UpdateCoregProgress();
            /* EDIT: progressbar_neu20210305 */
        }
        // once the last CoReg has been clicked, auto-submit the form data
        if (clickedCoregCount == totalCoregCount) {
            // trigger the actual form submission process
            //$("form").submit();
            $("input[type=submit]").trigger("click");
        }
        /* EDIT: coreg_of_the_day */
        // check if a 'CoReg of the day' is used on this page
        /*var highlightContainer = get_highlight_coreg();
        // if the currently displayed CoReg is the highlight CoReg...
        if (highlightContainer &&
            highlightContainer.data("value") == currentCoregParent.find(".coregContainer").data("value")) {
            // ...hide the graphic animation, so it isn't display on top of the next CoReg
            hide_message_star();
        }*/
        /* EDIT: coreg_of_the_day */
        /* EDIT: new_doi_progress_icons */
        // fade out the DOI info graphics after the first CoReg question
        /* EDIT: ultraflex_coreg_progressbar_neu */
        /*if (clickedCoregCount == 1) {
            $("div.hybrid-area").fadeOut(250);
        }*/
        /* EDIT: ultraflex_coreg_progressbar_neu */
        /* EDIT: new_doi_progress_icons */
        // fade out the currently shown CoReg
        currentCoregParent.fadeOut(250, function() {
        /* EDIT: coreg_slider */
            // only perform CoReg fade-ins if this is not the CoReg DOI page, which shows a full list
            // of CoRegs, anyway
            /* EDIT: coreg_slider */
            /*// once the last CoReg has been clicked, auto-submit the form data
            if (clickedCoregCount == totalCoregCount) {
                $("form").submit();
            } else */if (!OnCoregDoiPage()) {
                // after displaying the first CoReg, hide the info text at the top to make some room
                if (clickedCoregCount == 1) {
                    // $("#hinweis").slideUp(750);
                    $(".coregInfoText").slideUp(750);
                }
            /* EDIT: coreg_slider */
                /* EDIT: coreg_banner_text */
                //if ($("#submicrosite-id").val() == "1055") {
                    // fetch the coreg ID of the current CoReg element
                    var coregId = GetCoregIdFromElement(currentCoregParent);
                    // display the CoReg banner text only after a certain CoReg has been shown
                    //var curabluCoregId = 687;
                    //if (coregId == curabluCoregId) {
                    var insertAfterCoregCount = 3;
                    if (clickedCoregCount == insertAfterCoregCount) {
                        // show the new (banner-style) DOI info mail text
                        $(".coreg-banner-text").show();
                    }
                //}
                /* EDIT: coreg_banner_text */
                if (!coregSlider && clickedCoregCount == coregCount) {
                    // keep track of the current CoReg survey stage
                    secondCoregStage = true;
                    // display the progressbar animation, but move on to the full CoReg list afterwards
                    show_next_coreg(false);
                } else {
                    // display the progressbar animation, and move on to the next single CoReg
                    show_next_coreg(true);
                }
            }
        });
    }
}

/* EDIT: coreg_multiple_choice */
function transform_checkbox_coregs() {
    $("input[type=checkbox]").each(function() {
        let answersContainer = $(this).parent().parent();
        if (!answersContainer.hasClass("multiple-choice")) {
            answersContainer.addClass("multiple-choice");
            let buttomHtmlStr = `
            <div class="button-container">
                <div class="button">Beantworten</div>
            </div>
            `;
            $(buttomHtmlStr).insertAfter(answersContainer);
        }
    });
    $(".coregAnswers.multiple-choice input[type=checkbox], .coregSubAnswers.multiple-choice input[type=checkbox]").hide();
    $(".coregAnswers.multiple-choice .coregAnswer, .coregSubAnswers.multiple-choice .coregSubAnswer").addClass("positive-answer");
    $(".coregAnswers.multiple-choice .coregAnswer, .coregSubAnswers.multiple-choice .coregSubAnswer").data("trigger-click", "no");
    $(".coregAnswers.multiple-choice .coregAnswer, .coregSubAnswers.multiple-choice .coregSubAnswer").click(function() {
        $(this).toggleClass("checked");
        $(this).find("input[type=checkbox]").trigger("click");
    });
    $(".coregAnswers.multiple-choice + .button-container .button, .coregSubAnswers.multiple-choice + .button-container .button").click(function() {
        hide_coreg_and_show_next(true);
    });
}
/* EDIT: coreg_multiple_choice */

/**
 * Perform additonal GUI initialization
 */
function InitGui() {
    // only add the hybrid area if this isn't the CoReg DOI page
    /* EDIT: coreg_tile_answers */
    if (OnCoregPage() && !OnCoregDoiPage()) {
        /* EDIT: tile_coregs_dynamic */
        assign_coreg_indices();
        // show only the first CoReg
        show_first_coreg();
        // apply different colors to positive and negative CoReg answers
        apply_coreg_highlights();
        /* EDIT: coreg_multiple_choice */
        // update DOM content of CoRegs which have multiple-choice answers
        transform_checkbox_coregs();
        /* EDIT: coreg_multiple_choice */
        // turn CoRegs from regular CoRegs into CoRegs with tile answers
        transform_tile_coregs();
        // insert images into certain CoReg headers
        add_coreg_images();
        // assign 'click' events to the tiled CoReg answer buttons
        build_radio_buttons();
        /* EDIT: tile_coregs_dynamic */
    /* EDIT: coreg_tile_answers */
        //add_hybrid_area();
    }
    $(".message-window .ok-button").click(function(event) {
        $(".message-window").hide();
    });
}

/**
 * Show an info message in the 'controls' area
 * @param messageStr The text message to be shown
 */
function ShowMessage(messageStr) {
    // set the message text
    $(".message-window .message").html(messageStr);
    // show the message window
    $(".message-window").fadeIn(130);
}

/* EDIT: promo_consent_dialog */
/**
 * Show a message box which asks the user if he wants to give his promotion consent or not
 */
function ShowPromoConsentMessage() {
    // show the promotion consent dialog
    $(".promo-consent-window").fadeIn(130);
}
/* EDIT: promo_consent_dialog */

/**
 * Provide an input validator for checking input fields
 */
function InputValidator() {

}

// the string must not be empty
InputValidator.FILTER_NOT_EMPTY = 1;
// the string must have a minimum length (specified using the "minLength" field)
InputValidator.FILTER_MIN_LENGTH = 2;
// the string must have a maximum length (specified using the "maxLength" field)
InputValidator.FILTER_MAX_LENGTH = 4;
// the string length must match the country's zip code length (5 for Germany, 4 for Austria)
InputValidator.FILTER_ZIP = 16;

/**
 * Validate an input element
 * @param inputElement the jQuery input element
 * @param validationInfo the validation info object (e.g. {"checks": InputValidator.FILTER_NOT_EMPTY})
 * @return boolean Return whether the validation was successful or not
 */
InputValidator.validate = function(inputElement, validationInfo) {
    // only perform the validation if all necessary information was given
    if (inputElement.length && validationInfo !== undefined &&
        validationInfo.checks !== undefined) {
        // trim the incoming input text value
        var value = inputElement.val().trim();
        // make sure that the input string value is not empty
        if (validationInfo.checks & InputValidator.FILTER_NOT_EMPTY) {
            // determine the actual HTML tag name of the input element
            var inputTagName = inputElement[0].tagName.toLowerCase();
            // check <select> elements for the 'empty' value '--', and regular
            // text inputs for being empty
            if ((inputTagName == "select" && value == "--") || !value.length) {
                return false;
            }
        }
        // make sure that the input string has a minimum length
        if (validationInfo.checks & InputValidator.FILTER_MIN_LENGTH) {
            if (value.length < validationInfo.minLength) {
                return false;
            }
        }
        // make sure that the input string doesn't exceed a maximum length
        if (validationInfo.checks & InputValidator.FILTER_MAX_LENGTH) {
            if (value.length > validationInfo.maxLength) {
                return false;
            }
        }
        // if the input string is a zip code, it has to match a specific length
        if (validationInfo.checks & InputValidator.FILTER_ZIP) {
            // Austrian zip codes are 4 characters in length...
            if ($("#country").val() == "at") {
                if (value.length != 4) {
                    return false;
                }
            } else if (value.length != 5) {
                // ...for now, all other zip codes (like German ones) are 5 characters in length
                return false;
            }
            /* EDIT: input_validation_update */
            // check if the ZIP code only contains numbers
            if (!(/^\d+$/.test(value))) {
                return false;
            }
            /* EDIT: input_validation_update */
        }
        // if all checks which were specified by the validationInfo object were passed, return true
        return true;
    } else {
        // checking the method input parameters failed, so return false
        return false;
    }
};

/**
 * Highlight an input element as being an error (show an error icon, etc.)
 * @param inputElement The jQuery input element which will be marked as an error
 * @param showError Whether to show the error or to hide it
 */
InputValidator.showError = function(inputElement, showError) {
    // the 'phone' input field uses a different nesting structure,
    // so look up the 'error image' div element differently
    if (inputElement.attr("name") == "phone") {
        var errorImageDiv = inputElement.parent().parent().find("div.error-img");
    } else {
        var errorImageDiv = inputElement.next("div.error-img");
    }
    // if 'showError' is 'true' or not given at all, show the error
    if (showError || showError === undefined) {
        // add the 'input-error' class, which adds a red frame
        inputElement.addClass("input-error");
        // show the (usually hidden) error icon image
        errorImageDiv.show();
    } else {
        // ...otherwise, remove the 'input-error' class, which adds a red outline, etc.
        inputElement.removeClass("input-error");
        // hide the warning icon image
        errorImageDiv.hide();
    }
};

// a list of custom validation checks for input fields (by default, input fields just aren't allowed
// to be empty). They can be combined by using a bitwise OR (the | operator)
var inputValidators = {
    "input[name=zip_code]": {
        "checks": InputValidator.FILTER_ZIP
    }
};

/**
 * Check a list of input fields and mark them as errors if they fail validation
 * @param inputFields An array of CSS selector strings which specifies the form elements to be checked
 * @return boolean Whether all of the fields could be validated successfully or not
 */
function VerifyInputFields(inputFields) {
    // track whether all inputs have been verified
    var inputsVerified = true;
    // traverse the given list of input fields
    for (var i in inputFields) {
        // fetch the DOM element which was specified by the current array element (which is a string)
        var inputElement = $(inputFields[i]);
        // only verify the form element if it could be found
        if (inputElement.length) {
            // check if the name of the input field can be found in the list of input validators
            if (inputFields[i] in inputValidators) {
                // use the validation info from the list
                var validationInfo = inputValidators[inputFields[i]];
            } else {
                // ...or use a simple filter to check for empty strings
                var validationInfo = {"checks": InputValidator.FILTER_NOT_EMPTY};
            }
            // run the validator and if it fails, highlight the current input element as having an error
            if (!InputValidator.validate(inputElement, validationInfo)) {
                // only change the 'inputsVerified' variable if it hasn't been altered already
                if (inputsVerified) {
                    inputsVerified = false;
                }
                // show the error icon near this input element, etc.
                InputValidator.showError(inputElement, true);
            }
        }
    }
    // return whether all inputs could be verified or not
    return inputsVerified;
}

/* EDIT: promo_consent_dialog */
/**
 * Hide the first registration page, and show the second one
 */
// function ShowSecondRegPage() {
//     // hide the first registration page...
//     $(".controls-area .registration-page-1").hide();
//     // ...and show the second registration page instead
//     $(".controls-area .registration-page-2").show();
//     // fetch the HTML text specified by the user for the AGB2 button
//     var agb2Html = $(".mfw_adressData_agb2 span").html();
//     // copy the AGB2 HTML text to the visible 'Continue' button
//     /* EDIT: promo_consent_dialog */
//     $(".controls-area .registration-page-2 .disclaimer-text").html('<div class="arrow-hint-container"></div><div class="optin-checkbox agb2-accepted"></div>' + agb2Html);
//     /* EDIT: promo_consent_info_window */
//     // attach the promo info window handler to the links in the new disclaimer text (set 'onlyAttachLinks' to 'true' in this case)
//     SetupPromoConsentInfoWindow(true);
//     /* EDIT: promo_consent_info_window */
//     /* EDIT: promo_consent_dialog */
//     // attach a 'click' event handler to the AGB2 checkbox
//     $(".agb2-accepted").click(function(event) {
//         /* EDIT: promo_consent_info_window */
//         // remove the 'error' state when the user interacts with this checkbox
//         $(this).removeClass("error");
//         /* EDIT: promo_consent_info_window */
//         // turn the checkmark on or off, depending on the checkbox state
//         $(this).toggleClass("checked");
//         /* EDIT: promo_consent_dialog */
//         $("p.mfw_adressData_agb2 input.checkbox").prop("checked", $(this).hasClass("checked"));
//         /* EDIT: promo_consent_dialog */
//     });
//     // attach "show sponsors" event handlers after moving the HTML text which contains
//     // the links
//     AttachShowSponsorsHandlers();
//     // hide the email sponsors information text
//     //$(".emailSponsorText").hide();
//     // update the sponsors info text to point out that it doesn't apply to email sponsors anymore
//     var emailInfoText = "Bei Abgabe einer Einwilligungserklärung werden die nachfolgend benannten Unternehmen (Sponsoren) " +
//                         "berechtigt sein, mir in ihrem Geschäftsbereich Werbung per Telefon oder Post zukommen zu lassen. " +
//                         'Wenn ich keine Werbung per Post oder Telefon bekommen will, muss ich nur das Häkchen "Ich möchte ' +
//                         'keine Anrufe erhalten" aktivieren. Red Lemon ist berechtigt, die Daten an die Sponsoren weiterzugeben, ' +
//                         "damit diese mir Werbung per Telefon oder Post zukommen lassen können. Allerdings wird Red Lemon die " +
//                         "Daten an maximal 14 Sponsoren weitergeben. Ich kann meine Einwilligung jederzeit mit Wirkung für die " +
//                         "Zukunft widerrufen. Der Widerruf wirkt nur für die Zukunft, sodass dann die davor erfolgten Datennutzungen " +
//                         "rechtmäßig bleiben.";
//     $(".sponsorInfoText.emailSponsorText").html(emailInfoText);
// }

function ShowSecondRegPage() {
    // send the contents of the first registration form to the server
    $("input[type=submit]").trigger("click");
}

/* EDIT: promo_consent_dialog */

// keep track of the current registration "page" (sweepstakes usually use the AGB number for
// registration page ID)
var agbNum = 1;
/* EDIT: kickbox_unknowns_check */
// count the number of 'unknown' kickbox responses triggered by user input
var unknownAttemptCount = 0;
// the allowed maximum number of 'unknown' kickbox responses
var maxUnknownAttemptCount = 2;
// keep track of the email error balloon visibility state
var emailErrorShown = false;
// keep track of the original text input field background color
var textInputColor = 'white';
// whether the 'Continue' button on the first registration page will skip to the logout page
var skipSecondRegPage = false;

/**
 * Show a kickbox error message
 * @param errorMessage The message to be displayed
 */
function ShowKickboxError(errorMessage) {
    // look up the balloon <span>
    var emailWrapper = $('.email-col span');
    // translate the error message
    errorMessage = Translate(errorMessage);
    // make room for the error message balloon
    $(".email-col").animate({"margin-top": "+=34px"}, 400,
        function() {
            // show the balloon hint near the email address input
            emailWrapper.attr('data-balloon', errorMessage);
            emailWrapper.attr('data-balloon-visible', 'data-balloon-visible');
        });
    // save the original input field background color
    textInputColor = $('input[name=email]').css('background-color');
    // highlight the email input field
    $('input[name=email]').css('background-color', '#ffc6c6');
    // mark the email error balloon hint as being shown
    emailErrorShown = true;
}

/**
 * Hide the currently visible kickbox error message
 */
function HideKickboxErrorMessage() {
    // in case the email error balloon is already visible, hide it
    if (emailErrorShown) {
        // reduce the space taken up by the error message balloon
        $(".email-col").animate({"margin-top": "-=34px"}, 300);
        // hide the balloon
        var emailWrapper = $('.email-col span');
        emailWrapper.removeAttr('data-balloon-visible');
        emailWrapper.removeAttr('data-balloon');
        // reset the email input field background color
        $('input[name=email]').css('background-color', textInputColor);
        // update the email error balloon visibility state
        emailErrorShown = false;
    }
}
/* EDIT: kickbox_unknowns_check */

/* EDIT: kickbox_tonline_check */
/**
 * Check if a string has valid email address syntax and ends with '@t-online.de'
 * @param emailAddress The email address string to be checked
 * @return boolean Whether emailAddress is a valid T-Online email address
 */
function IsValidTonlineAddress(emailAddress) {
    // create a regular expression object which will validate email address syntax
    var emailRegExp = /(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])/;
    // if the email address ends with '@t-online.de' and has valid email address syntax,
    // return true
    if (emailAddress.match(/@t-online.de$/) !== null &&
        emailAddress.match(emailRegExp) !== null) {
        return true;
    } else {
        return false;
    }
}
/* EDIT: kickbox_tonline_check */

/**
 * Set up the 'Continue' button
 */
function SetupContinueButton() {
    /* EDIT: kickbox_unknowns_check */
    // keep track of the email error balloon visibility state
    //var emailErrorShown = false;
    // keep track of the original text input field background color
    //var textInputColor = $("input[name=email]").css("background-color");
    /* EDIT: kickbox_unknowns_check */
    // set up the 'Continue' button event handler
    $(".registration-page-1 .continue-button:not(.prepage), .registration-page-2 .continue-button").click(function(event) {
        // check if the 'Continue' button was clicked on the first registration page...
        if (agbNum == 1) {
            /* EDIT: promo_consent_dialog */
            var inputFields = ["input[name=firstname]", "input[name=lastname]",
                               "input[name=email]"];
            if (VerifyInputFields(inputFields)) {
                // fetch and clean up email address
                //var email = $("input[name=email]").val().trim();
                /* EDIT: improved_input_filters */
                // trim the email address and remove whitespaces (if any exist)
                var email = $("input[name=email]").val().trim().replace(/ /g, "");
                /* EDIT: improved_input_filters */
                /* EDIT: kickbox_tonline_check */
                // only call kickbox for non-T-Online email addresses
                if (IsValidTonlineAddress(email)) {
                    // show the second registration page
                    ShowSecondRegPage();
                    // EDIT: promo_consent_dialog
                    // point the registration page tracker to the second page
                    agbNum = 2;
                } else {
                    /* EDIT: kickbox_tonline_check */
                    // send the Ajax request which triggers the kickbox.io service
                    /* EDIT: move_kickbox_service */
                    //$.ajax({url: location.origin + '/ftp/services/verifyemail.php',
                    $.ajax({url: "https://www.rltools.de/verify_email/verifyemail.php",
                    /* EDIT: move_kickbox_service */
                            type: 'post',
                            data: {'email': email, 'key_domain': 'responsive_DE',
                                   'campaign_id': $("#campaign_id").val(), 'partner_id': $("#partner_id").val()},
                            success: function(data) {
                                // if the email address seems to be shady, show a hint to the user
                                /* EDIT: kickbox_unknowns_check */
                                if (data.result == 'unknown') {
                                    // allow several attempts at checking the email address
                                    if (unknownAttemptCount < maxUnknownAttemptCount) {
                                        // show an error message to hint at the 'unknown' email address
                                        ShowKickboxError("Diese E-Mail-Adresse scheint nicht zu existieren.");
                                        // increase the number of mail check attempts
                                        unknownAttemptCount++;
                                    } else {
                                        // skip all following Coyote sites and go directly to logout page
                                        $("input[name=aktion]").val("frontendMicrositePromosite");
                                        // also skip the second registration page
                                        skipSecondRegPage = true;
                                        // skip the user input process and trigger the actual form
                                        // submission process
                                        $("input[type=submit]").trigger("click");
                                    }
                                } else if (data.result != 'deliverable') {
                                    /* EDIT: kickbox_unknowns_check */
                                    // for non-deliverable email addresses which are not 'unknown', show an error message
                                    var balloonMessage = '';
                                    // check if kickbox.io has given us a correction suggestion
                                    if (data.did_you_mean !== null) {
                                        balloonMessage = "Meinten Sie " + data.did_you_mean + "? Bitte versuchen Sie es erneut.";
                                    } else {
                                        balloonMessage = "Ungültige E-Mail-Adresse! Bitte versuchen Sie es erneut.";
                                    }
                                    // show the kickbox error message
                                    /* EDIT: kickbox_unknowns_check */
                                    ShowKickboxError(balloonMessage);
                                    /* EDIT: kickbox_unknowns_check */
                                } else {
                                    // EDIT: promo_consent_dialog
                                    // the email address seems to be okay, but only proceed to the
                                    // second registration page if the AGB1 checkbox has been ticked
                                    /* EDIT: promo_consent_info_window */
                                    /* EDIT: agb_dialog */
                                    //if ($(".agb1-accepted").hasClass("checked")) {
                                    /* EDIT: agb_dialog */
                                        // set the hidden AGB1 checkbox to 'checked'
                                        /* EDIT: agb_dialog */
                                        //$("p.mfw_adressData_agb1 input.checkbox").prop("checked", true);
                                        /* EDIT: agb_dialog */
                                        /* EDIT: kickbox_unknowns_check */
                                        if (!skipSecondRegPage) {
                                            // show the second registration page
                                            ShowSecondRegPage();
                                            // EDIT: promo_consent_dialog
                                            // point the registration page tracker to the second page
                                            agbNum = 2;
                                        } else {
                                            // skip the user input process and trigger the actual form
                                            // submission process
                                            $("input[type=submit]").trigger("click");
                                        }
                                        /* EDIT: kickbox_unknowns_check */
                                    /* EDIT: agb_dialog */
                                    /*} else {
                                        // highlight the 'AGB1' checkbox as being unchecked
                                        $(".agb1-accepted").addClass("error");
                                    }*/
                                    /* EDIT: agb_dialog */
                                    /* EDIT: promo_consent_info_window */
                                }
                            }
                    });
                /* EDIT: kickbox_tonline_check */
                }
                /* EDIT: kickbox_tonline_check */
            }
        } else if (agbNum == 2) {
            // ...or if it was clicked on the second registration page
            var inputFields = ["input[name=zip_code]", "input[name=city]",
                               "#street", "input[name=street_no]",
                               "select[name=bday_day]", "select[name=bday_month]",
                               "select[name=bday_year]", /*"input[name=phone_prefix]",*/
                               "input[name=phone]"];
            if (VerifyInputFields(inputFields)) {
                /* EDIT: promo_consent_info_window */
                /* EDIT: agb_dialog */
                //if ($(".agb2-accepted").hasClass("checked")) {
                /* EDIT: agb_dialog */
                    // set the hidden AGB2 checkbox to 'checked'
                    /* EDIT: agb_dialog */
                    //$("p.mfw_adressData_agb2 input.checkbox").prop("checked", true);
                    /* EDIT: agb_dialog */
                    /* EDIT: fancy_message_before_coregs */
                    // hide the registration page contents
                    $(".controls-area .registration-page-2").hide();
                    // hide the countdown timer
                    $(".counter").hide();
                    /* EDIT: coreg_info_city */
                    // copy the value of the 'city' input to the CoReg info box
                    $(".coreg-info-container .info-city").text($("#city").val());
                    /* EDIT: coreg_info_city */
                    // hide undesired bgframe style customizations
                    UndoBgFrameStyling();
                    // show the info window before the CoReg page
                    $(".coreg-info-container").show();
                    // scroll to make sure that the data processing dialog is within view
                    // on mobile devices
                    //$(window).scrollTop($("html").offset().top);
                    if (IsMobileBrowser()) {
                        $(window).scrollTop($(".coreg-info-container").offset().top - 55);
                    }
                    /* EDIT: whatsapp_validation */
                    // prepare the POST parameters
                    var postParms = {
                        "idAmKindKampagne": $("#submicrosite-id").val(),
                        "dst": $("#dataset-token").val(),
                        "tel": $("[name=phone]").val()
                    };
                    // the URL of the WhatsApp validation service
                    var serviceUrl = "https://rlcontrol.de/customerScripts/customerRedLemonMedia/waDubCheckAjaxServer.php?ajaxRequestName=checkDataset";
                    // the maximum time used for data validation
                    var maxTime = 5200;
                    // record the start time for measuring the total validation time (in milliseconds)
                    var startTime = +new Date();
                    // send the information to the validation service
                    $.ajax({
                        "url": serviceUrl,
                        "method": "POST",
                        "data": postParms,
                        "timeout": 10000,
                        "success": function(resultData) {
                            // convert the returned JSON text to an actual object
                            var result = JSON.parse(resultData);
                            // whether the given user information has an associated WhatsApp account
                            var accountIsUsable = 0;
                            // check that no error information was returned, and figure out if the
                            // user data has WhatsApp
                            if (!("error" in result) && "dublette" in result && "whatsApp" in result) {
                                if ("account" in result["whatsApp"]) {
                                    // check if the user data is no duplicate and has WhatsApp
                                    if (result["dublette"] == 0 && result["whatsApp"]["account"] == 1) {
                                        accountIsUsable = 1;
                                    }
                                }
                            }
                            // store the new account info in 'infofeld 12'
                            $("input[name='adressData[infofeld12]']").val(accountIsUsable);
                            // calculate the total time taken by the validation process
                            var totalTime = (+new Date()) - startTime;
                            // if there is time left, trigger form submission in the future
                            if (totalTime < maxTime) {
                                // trigger a timeout which will complete the registration process
                                setTimeout(function() {
                                    // submit the final registration page (2) data
                                    $("input[type=submit]").trigger("click");
                                }, maxTime - totalTime);
                            } else {
                                // if the validation took too long, submit the form data immediately
                                // submit the final registration page (2) data
                                $("input[type=submit]").trigger("click");
                            }
                        },
                        "complete": function(xhr, status) {
                            // only run this code if the "success" handler failed for some reason
                            // (failed to reach server, timeout, etc.)
                            if (status != "success") {
                                // set the value of "infofeld 12" to a code which indicates "error"
                                $("input[name='adressData[infofeld12]']").val(2);
                                // submit the final registration page (2) data
                                $("input[type=submit]").trigger("click");
                            }
                        }
                    });
                    /*// trigger a timeout which will complete the registration process
                    setTimeout(function() {
                        // submit the final registration page (2) data
                        $("input[type=submit]").trigger("click");
                    }, 5200);*/
                    /* EDIT: whatsapp_validation */
                    /* EDIT: fancy_message_before_coregs */
                /* EDIT: agb_dialog */
                    /*} else {
                    // highlight the 'AGB2' checkbox as being unchecked
                    $(".agb2-accepted").addClass("error");
                }*/
                /* EDIT: agb_dialog */
                /* EDIT: promo_consent_info_window */
            }
        }
        /* EDIT: promo_consent_dialog */
    });
    // check if we should hide the email error balloon hint
    $('input[name=email]').keydown(function(event) {
        /* EDIT: kickbox_unknowns_check */
        HideKickboxErrorMessage();
        /* EDIT: kickbox_unknowns_check */
    });
    // fetch the HTML text specified by the user for the AGB1 button
    var agb1Html = $(".mfw_adressData_agb1 span").html();
    // copy the AGB1 HTML text to the visible 'Continue' button
    /* EDIT: promo_consent_dialog */
    /* EDIT: agb_checkbox_indent */
    // place the flexfancy checkbox element before the disclaimer text (registration page 1)
    $('<div class="arrow-hint-container"></div><div class="optin-checkbox agb1-accepted"></div>').insertBefore(".controls-area .registration-page-1 .disclaimer-text");
    // update the disclaimer text contents (registration page 1)
    $(".controls-area .registration-page-1 .disclaimer-text").html(agb1Html);
    /* EDIT: agb_checkbox_indent */
    // fetch the HTML text specified by the user for the AGB2 button
    var agb2Html = $(".mfw_adressData_agb2 span").html();
    // copy the AGB2 HTML text to the visible 'Continue' button
    /* EDIT: promo_consent_dialog */
    /* EDIT: agb_checkbox_indent */
    // place the flexfancy checkbox element before the disclaimer text (registration page 2)
    $('<div class="arrow-hint-container"></div><div class="optin-checkbox agb2-accepted"></div>').insertBefore(".controls-area .registration-page-2 .disclaimer-text");
    // update the disclaimer text contents (registration page 2)
    $(".controls-area .registration-page-2 .disclaimer-text").html(agb2Html);
    /* EDIT: agb_checkbox_indent */
    /* EDIT: promo_consent_dialog */
    // attach a 'click' event handler to the AGB1 checkbox
    $(".agb1-accepted, .agb2-accepted").click(function(event) {
        /* EDIT: promo_consent_info_window */
        // remove the 'error' state when the user interacts with this checkbox
        $(this).removeClass("error");
        /* EDIT: promo_consent_info_window */
        // turn the checkmark on or off, depending on the checkbox state
        $(this).toggleClass("checked");
        /* EDIT: promo_consent_dialog */
        /* EDIT: agb_dialog */
        /*$("p.mfw_adressData_agb1 input.checkbox").prop("checked", $(this).hasClass("checked"));
        $("p.mfw_adressData_agb2 input.checkbox").prop("checked", $(this).hasClass("checked"));*/
        /* EDIT: agb_dialog */
        /* EDIT: promo_consent_dialog */
    });
}

/* EDIT: promo_consent_info_window */
/**
 * Set up the promo consent info window and its related event handlers
 * @param onlyAttachLinks attach the info window links, but not the close button handler
 */
function SetupPromoConsentInfoWindow(onlyAttachLinks) {
    // attach a 'click' event handler to the 'show promo consent info window' links
    $("a.no-optin-info").click(function(event) {
        // show the promo consent info window
        $(".promo-info-window").show();
        // prevent regular link behaviour
        event.preventDefault();
    });

    // only attach the close button handler if 'onlyAttachLinks' is false
    if (!onlyAttachLinks) {
        // attach a 'click' event handler to the 'hide promo consent info window' button
        $(".promo-info-window .close-button").click(function(event) {
            // hide the promo consent info window
            $(".promo-info-window").hide();
        });
    }
}
/* EDIT: promo_consent_info_window */

/**
 * Assign values from visible input fields to the hidden Coyote input elements
 */
function AssignInputProxies() {
    // first registration page
    $("input[name=firstname]").on("input", function(event) {
        /* EDIT: improved_input_filters */
        // remove whitespace characters from the firstname field
        var filteredStr = $("input[name=firstname]").val().replace(/ /g, "");
        // copy the firstname value to the internal input field
        $(".mfw_adressData_vorname input").val(filteredStr);
        /* EDIT: improved_input_filters */
        //$(".mfw_adressData_vorname input").val($("input[name=firstname]").val());
    });
    $("input[name=lastname]").on("input", function(event) {
        /* EDIT: improved_input_filters */
        // remove whitespace characters from the lastname field
        var filteredStr = $("input[name=lastname]").val().replace(/ /g, "");
        // copy the lastname value to the internal input field
        $(".mfw_adressData_name input").val(filteredStr);
        /* EDIT: improved_input_filters */
        //$(".mfw_adressData_name input").val($("input[name=lastname]").val());
    });
    $("input[name=email]").on("input", function(event) {
        /* EDIT: improved_input_filters */
        // remove whitespace characters from the email field
        var filteredStr = $("input[name=email]").val().replace(/ /g, "");
        // copy the email value to the internal input field
        $(".mfw_adressData_email input").val(filteredStr);
        /* EDIT: improved_input_filters */
        //$(".mfw_adressData_email input").val($("input[name=email]").val());
    });
    // second registration page
    $("input[name=zip_code]").on("input", function(event) {
        $(".mfw_adressData_plz input").val($("input[name=zip_code]").val());
    });
    $("input[name=city]").on("input", function(event) {
        $(".mfw_adressData_ort input").val($("input[name=city]").val());
    });
    $("input[name=street]").on("input", function(event) {
        $(".mfw_adressData_strasse input").val($("input[name=street]").val());
    });
    $("input[name=street_no]").on("input", function(event) {
        $(".mfw_adressData_hausnr input").val($("input[name=street_no]").val());
    });
    $("select[name=country]").on("input", function(event) {
        $(".mfw_adressData_land select").val($("select[name=country]").val());
    });
    /* EDIT: fix_internet_explorer */
    function CopyBirthdayDayValue(event) {
        $("select.mfw_daySelect").val($("select[name=bday_day]").val());
    }
    $("select[name=bday_day]").on("input", CopyBirthdayDayValue);
    $("select[name=bday_day]").on("change", CopyBirthdayDayValue);
    function CopyBirthdayMonthValue(event) {
        $("select.mfw_monthSelect").val($("select[name=bday_month]").val());
    }
    $("select[name=bday_month]").on("input", CopyBirthdayMonthValue);
    $("select[name=bday_month]").on("change", CopyBirthdayMonthValue);
    function CopyBirthdayYearValue(event) {
        $("select.mfw_yearSelect").val($("select[name=bday_year]").val());
    }
    $("select[name=bday_year]").on("input", CopyBirthdayYearValue);
    $("select[name=bday_year]").on("change", CopyBirthdayYearValue);
    /* EDIT: fix_internet_explorer */
    $("input[name=phone]").on("input", function(event) {
        /* EDIT: improved_input_filters */
        // remove whitespace characters from the phone number
        var filteredStr = $("input[name=phone]").val().replace(/ /g, "");
        // copy the phone number to the internal input field
        $(".mfw_adressData_telefon1 input").val(filteredStr);
        /* EDIT: improved_input_filters */
        //$(".mfw_adressData_telefon1 input").val($("input[name=phone]").val());
    });
    /*$("input[name=phone]").on("input", function(event) {
        $(".mfw_adressData_telefon2 input").val($("input[name=phone]").val());
    });*/
}

/**
 * Attach the event handler code which displays the sponsors list window.
 * Registration pages 1 and 2 will display different sponsors.
 */
function AttachShowSponsorsHandlers() {
    $('.showSponsor').click(function(event) {
        event.stopPropagation();
        // show the hidden sponsor checkboxes and text labels
        $('.telSponsors input.checkbox, .emailSponsors input.checkbox, .emailPostSponsors input.checkbox').show();
        $('.telSponsors small, .emailSponsors small, .emailPostSponsors small').show();
		$('.mfw_sponsorAssignment_').show();
        // only show email sponsors on registration page 1
        if (agbNum == 1) {
            /* EDIT: agb_dialog */
            /*$(".emailPostSponsors").hide();
            $(".emailPostSponsors + .clearfix").hide();
            $(".telSponsors").hide();
            $(".telSponsors + .clearfix").hide();
            $("#tab1, #tab2").hide();
            $('#tab3').click();*/
            $("#tab1").click();
            /* EDIT: agb_dialog */
        } else if (agbNum == 2) {
            // ...and show the remaining sponsors on page 2
            $(".emailPostSponsors").show();
            $(".telSponsors").show();
            $(".emailSponsors").hide();
            $(".emailSponsors + .clearfix").hide();
            $("#tab3").hide();
            if ($(".emailPostSponsors").length) {
                $("#tab1").show();
                $("#tab1").click();
            } else {
                // hide the email/post sponsors list
                $("#tab1").hide();
                // show the phone sponsors list
                $("#tab2").show();
                $('#tab2').click();
            }
        }
	});
    // make sure that regular links inside the 'Continue' button don't accidentally trigger the
    // button area beneath, thanks to the magic of event bubbling
    $(".continue-button a").click(function(event) {
        event.stopPropagation();
    });
}

/**
 * Set up the sponsors list dialog contents - attach the close button handler,
 * tab click handlers, etc.
 */
function SetupSponsorsList() {
    // add an extra wrapper <div> around the sponsors list, so we can style it using CSS
    $("div.sponsorListe").wrap('<div class="outerSponsorListe"></div>');
    // remove the 'X' character from the sponsors list close button (added automatically by Coyote)
    $("div.closeButton").text("");
    // add "show sponsors" event handlers
    AttachShowSponsorsHandlers();
    $('.closeButton').click(function() {
        $('.mfw_sponsorAssignment_').hide();
    });
    $('.mfw_show').click(function() {
        $('.mfw_ownbox').show();
    });
    $('.closeButton_ownbox').click(function() {
        $('.mfw_ownbox').hide();
    });
    $("#tab1").click(function() {
        $("#tab1").addClass("active")
        $("#tab2").removeClass("active");
        $("#tab3").removeClass("active");
        $(".emailPostSponsors").show();
        $(".emailPostSponsors + .clearfix").show();
        $(".telSponsors").hide();
        $(".telSponsors + .clearfix").hide();
        $(".emailSponsors").hide();
        $(".emailSponsors + .clearfix").hide();
    });
    $("#tab2").click(function(){
        $("#tab2").addClass("active");
        $("#tab1").removeClass("active");
        $("#tab3").removeClass("active");
        $(".emailPostSponsors").hide();
        $(".emailPostSponsors + .clearfix").hide();
        $(".telSponsors").show();
        $(".telSponsors + .clearfix").show();
        $(".emailSponsors").hide();
        $(".emailSponsors + .clearfix").hide();
    });
    $("#tab3").click(function(){
        $("#tab3").addClass("active");
        $("#tab2").removeClass("active");
        $("#tab1").removeClass("active");
        $(".emailPostSponsors").hide();
        $(".emailPostSponsors + .clearfix").hide();
        $(".telSponsors").hide();
        $(".telSponsors + .clearfix").hide();
        $(".emailSponsors").show();
        $(".emailSponsors + .clearfix").show();
    });
    /* EDIT: sponsoren_hinweis_anpassbar */
    if (OnFirstRegPage()) {
        // add the email sponsors info text after the sponsors header
        // (copy the info text from a hidden AGB field, so it can be edited easily)
        var emailInfoText = $("#mfw_fieldset_agbs .mfw_adressData_agb3 span").text();
    } else {
        // update the sponsors info text to point out that it doesn't apply to email sponsors anymore
        // (copy the info text from a hidden AGB field, so it can be edited easily)
        var emailInfoText = $("#mfw_fieldset_agbs .mfw_adressData_agb4 span").text();
    }
    /* EDIT: sponsoren_hinweis_anpassbar */
    // create a new text element for displaying generic email sponsors information
    var infoTextElement = $('<div class="sponsorInfoText emailSponsorText">' + emailInfoText + '</div>');
    // insert the information text after the sponsors list header
    infoTextElement.insertAfter(".mfw_sponsorAssignment_ .sponsorHeader");
}

/**
 * Assign code to a form element which will clear an error marker on input
 * @param event The input event which caused clearing the error
 */
function AssignInputValidator(event) {
    // fetch the target element
    var targetElement = $(event.target);
    // hide the error icon next to the form element
    InputValidator.showError(targetElement, false);
}

/**
 * Assign code to the form input fields which will clear the error markers when
 * the user starts typing text
 */
function AssignInputValidators() {
    $("input, select").on("input", AssignInputValidator);
}

function CreateDefaultConfig() {
    var defaultConfig = {
        "tech" : {
    		"note" : "Standardnotiz",
    		"location" : "de"
    	},
    	"prepage" : {
    		"display" : "false",
    		"file" : ""
    	},
    	"content" : {
    		"pagetitle" : "Gewinnen Sie!",
            "basecolor" : "#50addc",
    		"shadowcolor" : "#2d5e77",
    		"highlightcolor" : "#60c0f1",
    		"hl1" : {
    			"color" : "#1c1b1b",
    			"size" : "25",
    			"weight" : "700",
    			"text" : "Header #1"
    		},
    		"hl2" : {
    			"color" : "#ff942b",
    			"size" : "35",
    			"weight" : "700",
    			"text" : "Header #2"
    		},
    		"promotion" : "",
    		"counter" : {
    			"text" : "ZÄHLER-TEXT",
    			"bgcolor" : "#ffff1f",
    			"position" : {
    				"x" : "0",
    				"y" : "0"
    			},
    			"starttime" : "2:40"
    		},
    		"button" : {
    			"usekeycolor" : "true",
    			"color" : "#ff942b",
    			"bordercolor" : "#d17c29",
    			"shadow" : "#6f5a45",
    			"radius" : "12",
    			"text" : {
    				"color" : "#fff",
    				"text" : "Weiter",
    				"symbol" : {
    					"fontcolor" : "#ffffff",
    					"left" : "<i class=\"fa fa-hand-o-right\"><\/i>&nbsp;",
    					"right" : "&nbsp;<i class=\"fa fa-hand-o-left\"><\/i>",
    					"animation" : {
    						"type" : "crash",
    						"speed1" : "850",
    						"speed2" : "850"
    					}
    				}
    			}
    		}
    	}
    };
    return defaultConfig;
}

function ConfigureContinueButton(configData) {
    var buttonConfig = configData.content.button;
    var customStyle = "";
    // colorize the 'Continue' button border and background color
    var buttonBackgroundColor;
    var buttonBorderColor;
    if (buttonConfig.usekeycolor == "true") {
        buttonBackgroundColor = configData.content.basecolor;
        buttonBorderColor = configData.content.shadowcolor;
    } else {
        buttonBackgroundColor = buttonConfig.color;
        buttonBorderColor = buttonConfig.bordercolor;
    }
    customStyle += ".controls-area .continue-button {background-color: " +
                   buttonBackgroundColor + " !important;" +
                   "border: 2px solid " + buttonBorderColor + " !important;" +
                   "border-radius: " + buttonConfig.radius + "px;" +
                   "color: " + buttonConfig.text.color +  ";}";
    $(".continue-button .button-label .label").html(buttonConfig.text.text);
    $(".continue-button .label-marker-left, .continue-button .label-marker-right").css("color", buttonConfig.text.symbol.fontcolor);
    // only update the 'Continue' button symbol on the left if its content is available
    if (buttonConfig.text.symbol.left && buttonConfig.text.symbol.left.length) {
        $(".continue-button .label-marker-left").html(buttonConfig.text.symbol.left);
        // only animate the left symbol if content is available (avoids glitchy animation display)
        $(".continue-button .label-marker-left, .continue-button .label-marker-right").addClass("animated");
    }
    // only update the 'Continue' button symbol on the right if its content is available
    if (buttonConfig.text.symbol.right && buttonConfig.text.symbol.right.length) {
        $(".continue-button .label-marker-right").html(buttonConfig.text.symbol.right);
        // only animate the right symbol if content is available (avoids glitchy animation display)
        $(".continue-button .label-marker-left, .continue-button .label-marker-right").addClass("animated");
    }
    if (buttonConfig.text.symbol && buttonConfig.text.symbol.animation &&
        buttonConfig.text.symbol.animation.speed1) {
            $(".continue-button .label-marker-left, .continue-button .label-marker-right").css("animation-duration", buttonConfig.text.symbol.animation.speed1 + "ms");
    }
    return customStyle;
}

/**
 * Draw a CoReg progress bar shape (rounded corners, etc.)
 * @param gfx The canvas 2D graphics context
 * @param x Shape x coordinate
 * @param y Shape y coordinate
 * @param width Shape width
 * @param height Shape height
 * @param drawStroke Whether to draw an outline instead of a filled shape
 * @param colorStyle The drawing style used for rendering the shape
 * @param progressText The (optional) text used to label the current progress
 */
function DrawCoregProgressShape(gfx, x, y, width, height, drawStroke,
                                colorStyle, progressText) {
    // only draw the progress indicator if it has a certain width, in order to prevent
    // drawing problems with the rounded endings
    if (width > 10) {
        // prepare for drawing an outline...
        if (drawStroke) {
            gfx.lineWidth = 1;
            gfx.strokeStyle = colorStyle;
        } else {
            // ...or a filled shape
            gfx.fillStyle = colorStyle;
        }
        // begin drawing the shape path
        gfx.beginPath();
        // draw the half-circle on the left
        gfx.arc(x + height / 2, y + height / 2, height / 2 - 1, .5 * Math.PI, 1.5 * Math.PI);
        // draw the upper horizontal line
        gfx.lineTo(x + width - height / 2, y + 1);
        // draw the half-circle on the right
        gfx.arc(x + width - height / 2, y + height / 2, height / 2 - 1, 1.5 * Math.PI, .5 * Math.PI);
        gfx.closePath();
        if (drawStroke) {
            // draw the stroke...
            gfx.stroke();
        } else {
            // ...or render a filled shape
            gfx.fill();
        }
        // if a progress indicator label text was given, draw it
        if (progressText != undefined && progressText.length &&
            width > 25) {
            // set the text style...
            gfx.fillStyle = "#fff";
            gfx.font = "bold 14px sans-serif";
            // and draw it in the middle of the highlighted progress indicator
            gfx.fillText(progressText, x + width / 2 - gfx.measureText(progressText).width / 2, 14);
        }
    }
}

/* EDIT: progressbar_neu20210305 */
// base completion percentage
var basePercent = 17;
// total completion percentage
var totalPercent = 100 - basePercent;
// keep track of the last reached progress stage, so we can animate the progress increase
var currentProgressStage = basePercent;
/* EDIT: progressbar_neu20210305 */
// set a progress indicator target value to be reached via animation
var targetProgressWidth = 0;
// the interval function used for CoReg progress animation
var coregProgressInterval = null;

/* EDIT: progressbar_neu20210305 */
/*function DrawCoregProgressBar(gfx, x, y, width, height, configData) {
    // draw the filled progress bar background shape
    DrawCoregProgressShape(gfx, 0, 0, width, height, false, "#f2f2f2");
    // assemble the progress info text
    var progressText = Math.round(currentProgressStage / width * 100) + " %";
    // draw the highlighted progress bar
    DrawCoregProgressShape(gfx, 0, 0, currentProgressStage, height, false,
                           configData.content.basecolor, progressText);
    // draw the progress bar outline
    DrawCoregProgressShape(gfx, 0, 0, width, height, true, "#666");
}*/
/* EDIT: progressbar_neu20210305 */

// keep track of the user's CoReg progress
var currentCoregStep = 0;

/**
 * Update the CoReg progress bar to show a specific progress value
 * @param configData The sweepstake configuration (contains color information, etc.)
 */
function UpdateCoregProgress(configData) {
    /* EDIT: progressbar_neu20210305 */
    // fetch the total CoReg question count
    totalCoregCount = $(".coregContainer").length;
    // increase the user's CoReg progress
    currentCoregStep++;
    // calculate the relative width of the highlighted progress bar
    var progressWidth = basePercent + currentCoregStep / totalCoregCount * totalPercent;
    // the progress update animation duration (milliseconds)
    var progressDelay = 400;
    // animate the progressbar to watch it "grow"
    $(".coreg-progressbar .progress").animate({
        "width": progressWidth + "%"
    }, progressDelay);
    // fade in the progressbar
    //$(".coreg-progressbar").fadeIn(300);
    // only animate the progress indicator if its width has actually increased
    if (progressWidth > currentProgressStage) {
        // set a new target progress value to be reached
        targetProgressWidth = progressWidth;
        // calculate the progress difference between current and next progress levels
        var progressDiff = progressWidth - currentProgressStage;
        // calculate how much time should pass inbetween progress updates.
        // (Only used for text animation)
        var progressStep = progressDelay / progressDiff;
        // create the animation interval/updater function
        coregProgressInterval = setInterval(function() {
           // increase the progress counter
           currentProgressStage++;
           // update the progress indicator text
           $(".coreg-progress-text").html(Math.round(currentProgressStage) + "&nbsp;%");
           // check if we have reached the target progress width, so we can stop the text animation
           if (currentProgressStage >= targetProgressWidth) {
               // cap the progress stage value
               currentProgressStage = targetProgressWidth;
               // remove the animation interval function
               clearInterval(coregProgressInterval);
           }
        }, progressStep);
    }
    /* EDIT: progressbar_neu20210305 */
}

/**
 * Fetch the total CoReg count
 * @return The total number of CoRegs
 */
function GetCoregCount() {
    return $(".coregContainer").length;
}

/**
 * Get the next CoReg after the current one (if there is any)
 * @param appCoreg The .coregContainer CoReg container
 * @return The numeric ID of the next CoReg, or false, if there is no next CoReg
 */
function GetNextCoregId(appCoreg) {
    // create an array which stores all attached CoReg IDs
    var coregs = [];
    // keep track of the index of the currently visible CoReg question
    var currentCoregIndex = -1;
    // add the Coyote CoReg IDs to the coreg array
    $(".coregContainer").each(function(index, value) {
        // add the CoReg ID
        coregs.push($(value).data("value"));
        // if the current CoReg ID matches the ID of the visible CoReg,
        // store the index so that we will know later where the visible
        // CoReg fits into the CoReg list
        if ($(value).data("value") == appCoreg.data("value")) {
            // store the CoReg index for later use
            currentCoregIndex = index;
        }
    });
    // check if there is at least one CoReg after this one...
    if (currentCoregIndex < coregs.length - 1) {
        // ...and return its ID value
        return coregs[currentCoregIndex + 1];
    } else {
        // this seems to be the last CoReg in the list, return a boolean value instead
        return false;
    }
}

/**
 * Perform any post-CoReg-click actions (fade outs, fade ins, etc.)
 * @param parentAppCoreg The .coregContainer which wraps around this CoReg answer
 * @param configData The sweepstake configuration (contains color information, etc.)
 * @param isSubQuestion Whether this is a sub-question or a normal question (relevant for FAZ CoReg)
 * @param forceFinalize Whether to force finalizing the CoReg, even though it is a 'special' CoReg (e.g. for FAZ)
 */
function FinalizeCoreg(parentAppCoreg, configData, isSubQuestion, forceFinalize) {
    // the FAZ CoReg ID
    var isFazSubQuestion = (parentAppCoreg.data("value") == "823") && isSubQuestion;
    /* EDIT: blitz_coreg_changes */
    // figure out if this is the Blitz CoReg
    var isBlitzCoreg = (parentAppCoreg.data("value") == "837");
    /* EDIT: blitz_coreg_changes */
    // decide which function to call after answering (and fading out) the current CoReg question
    var postFadeInFunc;
    // attempt to fetch the ID value of the CoReg after this one
    var nextCoregId = GetNextCoregId(parentAppCoreg);
    // if there is still at least one CoReg question left after the current one...
    // (and this isn't an FAZ sub-question, which will simply work like a radiobutton)
    /* EDIT: blitz_coreg_changes */
    // if forceFinalize is set to 'true', also finalize special CoRegs
    if (forceFinalize || (!isFazSubQuestion && !isBlitzCoreg)) {
    /* EDIT: blitz_coreg_changes */
        if (nextCoregId !== false) {
            postFadeInFunc = function() {
                // fade in the next question
                $(".mfw_coreg_" + nextCoregId + " .coregContainer").fadeIn(500);
                // fade in the 'skip CoReg' button
                $(".skip-coreg-button").fadeIn(500);
            };
        } else {
            // ...if there is no CoReg question left...
            postFadeInFunc = function() {
                // ...submit the form
                $("input[type=submit]").trigger("click");
            };
        }
        // fade out the visible CoReg, and perform the post-fade function
        parentAppCoreg.fadeOut(500, postFadeInFunc);
        // fade out the 'skip CoReg' button
        $(".skip-coreg-button").fadeOut(500);
        // update the user's CoReg progress
        UpdateCoregProgress(configData);
    }
}

/* EDIT: suedstern_coregs */
var suedsternCoregs = [1398, 1399, 1400, 1401];

function IsSuedsternCoreg(coregId) {
    return suedsternCoregs.includes(coregId);
}

function ShowSuedsternWindow() {
    $(".suedstern-window-modal-bg").show();
}

function HideSuedsternWindow() {
    $(".suedstern-window-modal-bg").hide();
}

function ProcessSuedsternCoreg(coregId) {
    if (IsSuedsternCoreg(coregId)) {
        $(".suedstern-window-modal-bg iframe").hide();
        $("#suedstern-" + coregId).show();
        ShowSuedsternWindow();
    }
}

function apply_suedstern_changes() {
    $(".window .close-button").click(function() {
        HideSuedsternWindow();
    });
}
/* EDIT: suedstern_coregs */

// keep track of the last selected radio button (if any button was selected)
// (only ported to flexfancy because it is referenced by build_radio_buttons())
var lastSelectedRadio = null;
/* EDIT: blitz_coreg_changes */
// keep track of whether the Blitz CoReg has already been clicked
var blitzCoregClicked = false;
/* EDIT: blitz_coreg_changes */

/**
 * Set up the (nested) tile CoReg answers
 */
function build_radio_buttons() {
    /* EDIT: fix_live_coregs */
    /* EDIT: tile_coregs_dynamic */
    //$(".app_coreg_answer, .sub-question-answer").click(function(event) {
    $(".coregAnswer, .coregSubAnswer").click(function(event) {
    /* EDIT: exitpop_red_lemon */
    UpdateExitPopTimeout();
    /* EDIT: exitpop_red_lemon */
    /* EDIT: tile_coregs_dynamic */
        /* EDIT: fix_tile_coreg_double_click */
        /* EDIT: coreg_multiple_choice */
        if (!event.isTrigger && $(this).data("trigger-click") != "no") {
        /* EDIT: coreg_multiple_choice */
        /* EDIT: fix_tile_coreg_double_click */
    /* EDIT: fix_live_coregs */
            /* EDIT: faz_coreg_20181015 */
            /* EDIT: tile_coregs_dynamic */
            if ($(this).parent().parent().data("value") == "937" &&
            // if ($(this).parent().parent().data("value") == "973" &&
            /* EDIT: tile_coregs_dynamic */
                $(event.currentTarget).hasClass("positive-answer")) {
                window.open("https://cloud.nl.faz.net/fas-13-wochen-testen/?utm_source=redlemon&utm_medium=affiliate&utm_campaign=FAS_PAY_AFF_CO-REG_MIN_salesforce_PRT_So_IP19014&utm_term=co-registrierung", "_blank");
                /* EDIT: faz_coreg_20181015 */
            /* EDIT: maxda_weblink */
            } else if ($(this).parent().parent().data("value") == "1024" &&
                       $(event.currentTarget).hasClass("positive-answer")) {
                window.open("https://www.maxda.de/?a_aid=7928", "_blank");
            }
            /* EDIT: maxda_weblink */
            /* EDIT: suedstern_coregs */
            else if ($(event.currentTarget).hasClass("positive-answer") &&
                     IsSuedsternCoreg($(this).parent().parent().data("value"))) {
                ProcessSuedsternCoreg($(this).parent().parent().data("value"));
            }
            /* EDIT: suedstern_coregs */
            // attempt to look up the FAZ CoReg parent, which is stored in a different hierarchy
            var coregParent = $(this).parent().parent().parent();
            /* EDIT: blitz_coreg_changes */
            // this might be the 'Blitz' CoReg, so use a different hirarchy for it
            if (coregParent.data("value") == undefined) {
                coregParent = $(this).parent().parent();
            }
            /* EDIT: blitz_coreg_changes */
            var isFazCoreg2 = false;
            var isFazCoreg2Stage2 = false;
            /* EDIT: blitz_coreg_changes */
            var isBlitzCoreg = false;
            /* EDIT: blitz_coreg_changes */
            // check if the CoReg ID matches the one of the FAZ CoReg
            if (coregParent.data("value") == "823") {
                isFazCoreg2 = true;
            /* EDIT: blitz_coreg_changes */
        } else if (coregParent.data("value") == "837" && $(this).find("input.radio").val()[0] == "p") {
            isBlitzCoreg = true;
            /* EDIT: blitz_coreg_changes */
        } else {
                // try to find the parent .app_coreg element relative to an FAZ CoReg question element
                coregParent = $(this).parent().parent().parent().parent();
                if (coregParent.data("value") == "823") {
                    isFazCoreg2Stage2 = true;
                } else {
                    /* EDIT: tile_coregs_dynamic */
                    // sub-answers are positioned deeper in the DOM tree
                    if ($(this).hasClass("coregSubAnswer")) {
                        //coregParent = $(this).parent().parent().parent().parent().parent().parent();
                        /* EDIT: rlm_stat_analytics */
                        coregParent = $(this).parent().parent().parent().parent().parent()/*.parent()*/;
                        /* EDIT: rlm_stat_analytics */
                    } else {
                        /* EDIT: tile_coregs_dynamic */
                        // ...if this isn't the FAZ CoReg, look up the CoReg parent in the hierarchy structure
                        coregParent = $(this).parent().parent().parent();
                    /* EDIT: tile_coregs_dynamic */
                    }
                    /* EDIT: tile_coregs_dynamic */
                }
            }
            // check if this CoReg is the FAZ CoReg, which is treated differently
            //var isFazCoreg = coregParent.hasClass("mfw_coreg_715");
            var isFazCoreg = false;
            //var isFazCoreg = false;
            // check if this CoReg is the Audibene CoReg, which is treated differently
            var isFirstAudibeneCoreg = coregParent.hasClass("mfw_coreg_723");
            // track whether this is an Audibene question or not
            var isAudibeneCoreg = false;
            // treat the Audibene question after the first one differently
            if (!isFirstAudibeneCoreg) {
                // for each Audibene follow-up question, record its ID, and a bool flag which marks the
                // currently clicked-on Audibene question
                var audibeneCoregs = [[731, false], [725, false], [726, false], [727, false]];
                // compare the current CoReg question with all the Audibene follow-up questions, in order
                // to find the currently selected Audibene CoReg
                for (var i = 0; i < audibeneCoregs.length; i++) {
                    // check the current CoReg ID against the Audibene ID array
                    if (coregParent.hasClass("mfw_coreg_" + audibeneCoregs[i][0])) {
                        // flag the detected Audibene CoReg as 'selected'
                        audibeneCoregs[i][1] = true;
                        // track that this radio button belongs to an Audibene CoReg
                        isAudibeneCoreg = true;
                        break;
                    }
                }
            }
            // set the 'actual' hidden radio button to 'checked'
            var radioInput = $(this).find("input[type=radio]");
            // make sure that clicking on a CoReg label will also tick the associated radio button,
            // if this is not the FAZ CoReg, that is...
            /* EDIT: blitz_coreg_changes */
            if (!isFazCoreg && (!isFazCoreg2 || isFazCoreg2Stage2) && !isBlitzCoreg) {
            /* EDIT: blitz_coreg_changes */
                /* EDIT: fix_live_coregs */
                //radioInput.prop("checked", true);
                /* EDIT: pflege_coreg_fix */
                /* EDIT: rlm_stat_analytics */
                var coregId = GetCoregIdFromElement(coregParent);
                if (typeof RlmStat !== "undefined") {
                    RlmStat.CoregEnd(coregId, radioInput.first().val(), $(this).hasClass("positive-answer") ? 1 : 0);
                }
                /* EDIT: rlm_stat_analytics */
                radioInput.first().prop("checked", true).trigger("click");
                // radioInput.first().trigger("click");
                /* EDIT: pflege_coreg_fix */
                /* EDIT: fix_live_coregs */
            /* EDIT: blitz_coreg_changes */
            } else if (!isBlitzCoreg) {
            /* EDIT: blitz_coreg_changes */
                // reveal the FAZ 'buy' button
                $("div.faz-buy-button").fadeIn(700);
            }
            // transfer the radio button state from the first group of radiobuttons in the FAZ CoReg to the
            // internal radio buttons, when a button in the second radiobutton group gets selected
            if (isFazCoreg2Stage2) {
                /* EDIT: fix_live_coregs */
                //$(".mfw_coreg_823 .sub-question-answers .radio-img.checked + input.radio").prop("checked", true);
                /* EDIT: pflege_coreg_fix */
                $(".mfw_coreg_823 .sub-question-answers .radio-img.checked + input.radio").first().prop("checked", true).trigger("click");
                /* EDIT: pflege_coreg_fix */
                /* EDIT: fix_live_coregs */
            }
            // check if this is the first Audibene CoReg question
            if (isFirstAudibeneCoreg) {
                if (radioInput.val() == "p_1") {
                    $(".mfw_coreg_731").fadeIn();
                } else {
                    $(".mfw_coreg_725").fadeIn();
                }
            } else if (isAudibeneCoreg) {
                for (var i = 0; i < audibeneCoregs.length - 1; i++) {
                    if (audibeneCoregs[i][1]) {
                        $(".mfw_coreg_" + audibeneCoregs[i + 1][0]).fadeIn();
                    }
                }
            }
            // look up the sub-questions <div> only if this isn't the FAZ CoReg (which deals with sub-questions
            // differently)
            var subQuestions = null;
            if (!isFazCoreg2 && !isFazCoreg2Stage2) {
                /* EDIT: tile_coregs_dynamic */
                //subQuestions = $(this).find(".sub-questions");
                if ($(this).hasClass("coregAnswer")) {
                    var answerId = $(this).find("input.radio").first().data("id");
                    var subQuestions = $(this).parent().find(".sub.coregSub.parent" + answerId);
                    /*if (coregSubQuestions.length) {
                        coregSubQuestions.show();
                    }*/
                }
                /* EDIT: tile_coregs_dynamic */
            }
            // check if this CoReg answer should trigger the display of any sub-questions
            /* EDIT: tile_coregs_dynamic */
            //if (subQuestions && subQuestions.children().length) {
            if (subQuestions !== null && subQuestions.length) {
            /* EDIT: tile_coregs_dynamic */
                // make sure that we don't trigger click events on the parent CoReg answer again
                // (this would cause sub-question answer click events to run this event handler function twice)
                /* EDIT: tile_coregs_dynamic */
                //coregParent.find(".app_coreg_answer").off();
                coregParent.find(".coregAnswer").off();
                coregParent.find(".coregAnswer").hide();
                coregParent.find(".coregAnswer .coregAnswerLabel").attr("display: none !important;");
                /* EDIT: tile_coregs_dynamic */
                /* EDIT: coreg_slider */
                // make sure that the parent question is not marked green anymore
                /* EDIT: tile_coregs_dynamic */
                //var parentCoregAnswer = coregParent.find(".app_coreg_answer");
                var parentCoregAnswer = coregParent.find(".coregAnswer");
                /* EDIT: tile_coregs_dynamic */
                if (parentCoregAnswer.hasClass("positive-answer")) {
                    // remove the CSS class which provides the answer coloring
                    parentCoregAnswer.removeClass("positive-answer");
                }
                /* EDIT: coreg_slider */
                // hide all unrelated CoReg elements
                /* EDIT: tile_coregs_dynamic */
                /*coregParent.find(".app_coreg_headline").hide();
                coregParent.find(".app_coreg_hinweistext").hide();
                coregParent.find(".app_coreg_agb").hide();*/
                coregParent.find(".coregContainer .coregHeader").hide();
                /* EDIT: tile_coregs_dynamic */
                /* EDIT: pflege_coreg_fix */
                //$(this).find("> .radio-img, > .coregAnswerLabel").hide();
                //$(this).find("> .radio-img, > .coregAnswerLabel").remove();
                /* EDIT: tile_coregs_dynamic */
                //$(this).find("> .radio-img, > .coregAnswerLabel").attr("style", "display: none !important;");
                /* EDIT: tile_coregs_dynamic */
                /*$(this).css("width", "94%");
                $(this).css("box-shadow", "none");*/
                /* EDIT: tile_coregs_dynamic */
                //var cssStr = "width: 98%; box-shadow: none; float: none; margin-left: auto; margin-right: auto !important;";
                //$(this).attr("style", cssStr);
                /* EDIT: tile_coregs_dynamic */
                /* EDIT: tile_coregs_dynamic */
                $(this).parent().parent().find(".coreg-header, .coregHeader").hide();
                //$(this).find(".sub-question").css("width", "96%");
                //$(this).find(".sub-question").css("margin", "2%");
                /* EDIT: tile_coregs_dynamic */
                /* EDIT: pflege_coreg_fix */
                // hide the original sibling answers
                /* EDIT: tile_coregs_dynamic */
                /* EDIT: fix_new_layout_subquestions */
                coregParent.find(".coregAnswers.multi-coreg-parent").css("display", "block");
                /* EDIT: fix_new_layout_subquestions */
                //$(this).siblings().hide();
                /* EDIT: tile_coregs_dynamic */
                // show the sub-questions
                subQuestions.fadeIn(600);
            } else {
                // increase the clicked CoReg counter
                clickedCoregCount++;
                /* EDIT: progressbar_neu20210305 */
                // update the CoReg progressbar
                UpdateCoregProgress();
                /* EDIT: progressbar_neu20210305 */
                // if we have entered the second CoReg stage (i.e. the 'list'), keep a separate count of the clicked
                // CoReg answers
                if (secondCoregStage) {
                    // increase the 'list' CoReg answer count
                    clickedListCoregCount++;
                }
                // look up the radio button image <div>
                var radioButton = $(this).find(".radio-img");
                // mark the radio button visually as 'checked'
                radioButton.addClass("checked");
                // only remove the 'checked' class if we already have a radio button selection, and if we aren't
                // trying to deselect a selected radio button (they are not checkboxes, after all)
                if (lastSelectedRadio !== null &&
                    lastSelectedRadio.parent().find("input[type=radio]").attr("id") != radioInput.attr("id")) {
                    lastSelectedRadio.removeClass("checked");
                }
                // update the radio button selection reference
                lastSelectedRadio = radioButton;
                // handle the first n CoRegs and the ones which follow differently
                /* EDIT: coreg_slider */
                if (!coregSlider && (clickedCoregCount > coregCount)) {
                /* EDIT: coreg_slider */
                    /* EDIT: blitz_coreg_changes */
                    // only perform progressbar updates the first time when the 'Blitz' CoReg is clicked
                    if (!isBlitzCoreg || !blitzCoregClicked) {
                        // calculate the basic CoReg percentage which will be used as "base completion"
                        var basePercent = coregCount / (coregCount + 1);
                        // calculate the remaining CoReg progress after finishing the initial hybrid questions
                        var offsetPercent = (clickedCoregCount - coregCount) / (totalCoregCount - coregCount) * (1 - basePercent);
                        // add up the base "hybrid completion" and the scaled down "remaining completion" percentages
                        var percent = Math.round((basePercent + offsetPercent) * 100);
                        // update the progressbar percentage value to reflect the survey progress
                        set_progress($(".progressbar"), percent);
                        $(".progressbar span").text(percent + " %");
                        // CoReg 715 is a special case for an FAZ newspaper ad, all other CoRegs will be handled differently
                        /* EDIT: blitz_coreg_changes */
                        if (!isFazCoreg && !isFazCoreg2 && !isBlitzCoreg) {
                        /* EDIT: blitz_coreg_changes */
                            // the regular CoReg questions (shown after the three-CoReg progressbar stage) use a slide up animation
                            $(this).parent().parent().slideUp(900, function() {
                                // once the last CoReg has been clicked, auto-submit the form data
                                if (clickedCoregCount == totalCoregCount) {
                                    //$("form").submit();
                                    // trigger the actual form submission process
                                    $("input[type=submit]").trigger("click");
                                }
                            });
                        }
                    /* EDIT: blitz_coreg_changes */
                        // mark the 'Blitz' CoReg as being clicked (but only do this once)
                        if (isBlitzCoreg) {
                            blitzCoregClicked = true;
                        }
                    }
                    /* EDIT: blitz_coreg_changes */
                } else {
                    // the first n CoReg questions fade in and out
                    if (!isFazCoreg && !isFazCoreg2) {
                        /* EDIT: new_coreg_list */
                        /* EDIT: coreg_slider */
                        //$(this).parent().parent().slideUp(900, function() {
                        /* EDIT: coreg_slider */
                        //$(this).parent().parent().fadeOut(250, function() {
                        /* EDIT: new_coreg_list */
                        /* EDIT: coreg_slider */
                        hide_coreg_and_show_next();
                        /* EDIT: coreg_slider */
                    }
                }
                // if clicking this radio button represents the first stage of the FAZ CoReg, fade in the sub-answers
                if (isFazCoreg2) {
                    $(".mfw_coreg_823 .sub-question-answers").first().fadeIn(300);
                } else if (isFazCoreg2Stage2) {
                    // the regular CoReg questions (shown after the three-CoReg progressbar stage) use a slide up animation
                    coregParent.slideUp(900, function() {
                        // once the last CoReg has been clicked, auto-submit the form data
                        if (clickedCoregCount == totalCoregCount) {
                            //$("form").submit();
                            // trigger the actual form submission process
                            $("input[type=submit]").trigger("click");
                        }
                    });
                }
            }
        /* EDIT: fix_live_coregs */
        }
        /* EDIT: fix_live_coregs */
        /* EDIT: fix_tile_coreg_double_click */
        return false;
        /* EDIT: fix_tile_coreg_double_click */
    });
}

/**
 * Initialize the CoReg state
 * @param configData The sweepstake configuration (contains color information, etc.)
 */
function InitCoregs(configData) {
    // // traverse all CoRegs and modify Yes/No CoRegs
    // $(".coregContainer").each(function(index, value) {
    //     // fetch all answers which belong to this CoReg
    //     var answers = $(this).find(".coregAnswer");
    //     // track down all CoRegs with a Yes/No answer pair
    //     if (answers.length == 2) {
    //         // the list of label strings which are allowed for Yes/No CoRegs
    //         var validLabels = ["Yes", "No", "Ja", "Nein"];
    //         // assume that the labels in this CoReg are inalid
    //         var labelsAreValid = false;
    //         // store the CoReg's label strings already during the CoReg examination run
    //         var firstLabel, secondLabel;
    //         // traverse the available CoReg answers
    //         for (var i = 0; i < answers.length; i++) {
    //             // fetch the CoReg's answer label element
    //             var answerLabel = $(answers[i]).find(".coregAnswerLabel");
    //             // assume that this label string won't match
    //             var labelIsValid = false;
    //             // if an answer label was found...
    //             if (answerLabel.length) {
    //                 // ...check if it matches any of the validation labels
    //                 for (var j in validLabels) {
    //                     // if the label matches this validation label...
    //                     if (answerLabel.text() == validLabels[j]) {
    //                         // set the label to 'valid' and exit the loop
    //                         labelIsValid = true;
    //                         break;
    //                     }
    //                 }
    //             }
    //             // if this is the first CoReg answer, set the 'first' CoReg label
    //             if (i == 0) {
    //                 firstLabel = answerLabel.text();
    //             } else {
    //                 // ...else it must be the second, so we can set the 'second' CoReg label
    //                 secondLabel = answerLabel.text();
    //             }
    //             // if one of the labels is invalid, we can exit the traversal loop
    //             if (!labelIsValid) {
    //                 break;
    //             } else if (i == 1) {
    //                 // ...however, if this label is valid, and it is already the second one,
    //                 // both labels are valid
    //                 labelsAreValid = true;
    //             }
    //         }
    //         // if both labels are valid, this is a Yes/No CoReg, and we can rebuild the
    //         // CoReg accordingly
    //         if (labelsAreValid) {
    //             // fetch the answer elements for this CoReg
    //             var appCoregAnswers = $(this).find(".coregAnswers");
    //             // hide the original CoReg answers (including checkboxes, etc.)
    //             appCoregAnswers.hide();
    //             // build a container <div> for the Yes/No answers
    //             var yesNoAnswerDiv = $('<div class="yes-no-answer"></div>');
    //             // attach the 'Yes' and 'No' answers to the container <div>
    //             yesNoAnswerDiv.append('<div>' + firstLabel + '</div><div>' + secondLabel + '</div>');
    //             // attach the Yes/No container to the DOM, right after the hidden CoReg answers
    //             $(yesNoAnswerDiv).insertAfter(appCoregAnswers);
    //         }
    //     }
    // });
    // show only the first CoReg
    $(".coregContainer").first().show();
    // attach a 'click' event handler to the CoReg answers
    // $(".coregAnswer, .coregSubAnswer").click(function(event) {
    //     /* EDIT: fix_live_coregs */
    //     if (event.target.tagName.toLowerCase() != "input") {
    //         /* EDIT: faz_coreg_20181015 */
    //         if ($(this).parent().parent().data("value") == "937" &&
    //             $(event.currentTarget).find(".coregAnswerLabel").text().trim() == "Ja") {
    //             window.open("https://cloud.nl.faz.net/fas-13-wochen-testen/?utm_source=redlemon&utm_medium=affiliate&utm_campaign=FAS_PAY_AFF_CO-REG_MIN_salesforce_PRT_So_IN18212&utm_term=co-registrierung", "_blank");
    //         }
    //         /* EDIT: faz_coreg_20181015 */
    //         // make the checkboxes behave like radiobuttons in certain situations
    //         // (useful for the FAZ CoReg)
    //         $(this).siblings().find(".radio-img").removeClass("checked");
    //         // attempt to look up the FAZ CoReg parent, which is stored in a different hierarchy
    //         var coregParent = $(this).parent().parent().parent();
    //         /* EDIT: blitz_coreg_changes */
    //         // this might be the 'Blitz' CoReg, so use a different hirarchy for it
    //         if (coregParent.data("value") == undefined) {
    //             coregParent = $(this).parent().parent();
    //         }
    //         /* EDIT: blitz_coreg_changes */
    //         var isFazCoreg2 = false;
    //         var isFazCoreg2Stage2 = false;
    //         /* EDIT: blitz_coreg_changes */
    //         var isBlitzCoreg = false;
    //         /* EDIT: blitz_coreg_changes */
    //         // check if the CoReg ID matches the one of the FAZ CoReg
    //         if (coregParent.data("value") == "823") {
    //             isFazCoreg2 = true;
    //         /* EDIT: blitz_coreg_changes */
    //         } else if (coregParent.data("value") == "837") {
    //             isBlitzCoreg = true;
    //             /* EDIT: blitz_coreg_changes */
    //         } else {
    //             // try to find the parent .coregContainer element relative to an FAZ CoReg question element
    //             coregParent = $(this).parent().parent().parent().parent();
    //             if (coregParent.data("value") == "823") {
    //                 isFazCoreg2Stage2 = true;
    //             } else {
    //                 // ...if this isn't the FAZ CoReg, look up the CoReg parent in the hierarchy structure
    //                 coregParent = $(this).parent().parent().parent();
    //             }
    //         }
    //         // look up the radio image (which is actually a checkbox)
    //         var radioImage = $(this).find(".radio-img").first();
    //         // enabled checkboxes become disabled, disabled checkboxes become enabled
    //         radioImage.toggleClass("checked");
    //         // look up the hidden radio input (used for sending the actual form data)
    //         var radioInput = $(this).find("input.radio");
    //         // make sure that the internal state of the hidden radiobutton matches the radiobutton image
    //         // (if this is not the FAZ CoReg, that is...)
    //         /* EDIT: blitz_coreg_changes */
    //         //if (!isFazCoreg2 || isFazCoreg2Stage2) {
    //         if ((!isFazCoreg2 || isFazCoreg2Stage2) && !isBlitzCoreg) {
    //         /* EDIT: blitz_coreg_changes */
    //             /* EDIT: fix_live_coregs */
    //             /*if (radioImage.hasClass("checked")) {
    //                 radioInput.prop("checked", true);
    //             } else {
    //                 radioInput.prop("checked", false);
    //             }*/
    //             radioInput.trigger("click");
    //             /* EDIT: fix_live_coregs */
    //         /* EDIT: blitz_coreg_changes */
    //         } else if (!isBlitzCoreg) {
    //         /* EDIT: blitz_coreg_changes */
    //             // reveal the FAZ 'buy' button
    //             $("div.faz-buy-button").fadeIn(700);
    //         }
    //         // ...this is either a regular CoReg answer
    //         if ($(this).hasClass("app_coreg_answer")) {
    //             // look up the .coregContainer parent this regular CoReg answer belongs to
    //             var parentAppCoreg = radioImage.parent().parent().parent();
    //         } else {
    //             // ...or the answer to a sub-question.
    //             // Look up the .coregContainer parent this CoReg sub-question answer belongs to
    //             var parentAppCoreg = radioImage.parent().parent().parent().parent().parent().parent();
    //         }
    //         // if coregParent was set to the FAZ CoReg, set parentAppCoreg to the same value
    //         if (coregParent.data("value") == "823" ||
    //             /* EDIT: spiegel_coreg */
    //             coregParent.data("value") == "915") {
    //             /* EDIT: spiegel_coreg */
    //             parentAppCoreg = coregParent;
    //         }
    //         // transfer the radio button state from the first group of radiobuttons in the FAZ CoReg to the
    //         // internal radio buttons, when a button in the second radiobutton group gets selected
    //         if (isFazCoreg2Stage2) {
    //             /* EDIT: fix_live_coregs */
    //             //$(".mfw_coreg_823 .sub-question-answers .radio-img.checked + input.radio").prop("checked", true);
    //             $(".mfw_coreg_823 .sub-question-answers .radio-img.checked + input.radio").trigger("click");
    //             /* EDIT: fix_live_coregs */
    //         }
    //         // look up the sub-questions <div> only if this isn't the FAZ CoReg (which deals with sub-questions
    //         // differently)
    //         var subQuestions = null;
    //         if (!isFazCoreg2 && !isFazCoreg2Stage2) {
    //             subQuestions = $(this).find(".sub-questions");
    //         }
    //         // check if this CoReg answer should trigger the display of any sub-questions
    //         if (subQuestions && subQuestions.children().length) {
    //             // make sure that we don't trigger click events on the parent CoReg answer again
    //             // (this would cause sub-question answer click events to run this event handler function twice)
    //             parentAppCoreg.find(".coregAnswer").off();
    //             // hide all unrelated CoReg elements
    //             parentAppCoreg.find(".app_coreg_headline").hide();
    //             parentAppCoreg.find(".app_coreg_hinweistext").hide();
    //             parentAppCoreg.find(".app_coreg_agb").hide();
    //             // hide the original sibling answers
    //             $(this).find("> .radio-img, > .coregAnswerLabel").hide();
    //             $(this).siblings().hide();
    //             // make sure that coreg answer labels are not hidden after showing their parents
    //             subQuestions.find(".coregAnswerLabel").show();
    //             // show the sub-questions
    //             subQuestions.fadeIn(600);
    //         } else {
    //             // fade out the CoReg and fade in the next one, etc.
    //             FinalizeCoreg(parentAppCoreg, configData, $(this).hasClass("sub-question-answer"));
    //         }
    //     /* EDIT: fix_live_coregs */
    //     }
    //     /* EDIT: fix_live_coregs */
    // });
    // // attach a 'click' event handler to the first answer of the Yes/No CoRegs
    // $(".yes-no-answer div:first-child").click(function(event) {
    //     // look up the .coregContainer parent this CoReg answer belongs to
    //     var parentAppCoreg = $(this).parent().parent();
    //     // set the internal form radiobutton input to 'checked'
    //     /* EDIT: fix_live_coregs */
    //     //parentAppCoreg.find(".coregAnswer input").first().prop("checked", true);
    //     parentAppCoreg.find(".coregAnswer input").first().trigger("click");
    //     /* EDIT: fix_live_coregs */
    //     // fade out the CoReg and fade in the next one, etc.
    //     FinalizeCoreg(parentAppCoreg, configData);
    // });
    // // attach a 'click' event handler to the second answer of the Yes/No CoRegs
    // $(".yes-no-answer div:last-child").click(function(event) {
    //     // look up the .coregContainer parent this CoReg answer belongs to
    //     var parentAppCoreg = $(this).parent().parent();
    //     // set the internal form radiobutton input to 'checked'
    //     /* EDIT: fix_live_coregs */
    //     //parentAppCoreg.find(".coregAnswer input").last().prop("checked", true);
    //     parentAppCoreg.find(".coregAnswer input").last().trigger("click");
    //     /* EDIT: fix_live_coregs */
    //     // fade out the CoReg and fade in the next one, etc.
    //     FinalizeCoreg(parentAppCoreg, configData);
    // });
    // attach a 'click' event handler to the 'skip CoReg' button
    $(".skip-coreg-button").click(function(event) {
        // traverse all attached CoRegs...
        // $(".coregContainer").each(function(key, value) {
        //     // ...and find the currently visible CoReg
        //     if ($(value).is(":visible")) {
        //         /* EDIT: blitz_coreg_changes */
        //         if ($(value).data("value") == "837") {
        //             // when using the skip button, force finalizing special CoRegs,
        //             // because otherwise that wouldn't happen
        //             FinalizeCoreg($(value), configData, false, true);
        //         } else {
        //             // fade out the CoReg and fade in the next one, etc.
        //             FinalizeCoreg($(value), configData);
        //         }
        //         /* EDIT: blitz_coreg_changes */
        //         // quit the traversal loop
        //         return false;
        //     }
        // });
        // hide the current CoReg and show the next one (if any is available)
        //hide_coreg_and_show_next(true);
        // show the CoReg 'Störer' dialog
        ShowCoregStoerer();
    });
    /* EDIT: blitz_coreg_changes */
    // attach a 'click' handler to the 'Blitz' CoReg button
    $(".blitz-coreg-button").click(function(event) {
        // look up the radio button which was selected by the user (if any is available)
        var checkedBlitzRadio = $(".mfw_coreg_837 .radio-img.checked");
        // only proceed if a 'Blitz' radio button was actually selected
        if (checkedBlitzRadio.length) {
            // look up the hidden, internal 'Blitz' radio button
            var hiddenBlitzRadio = $(".mfw_coreg_837 .radio-img.checked + input[type=radio]");
            // transfer the visible button state to the internal one
            /* EDIT: fix_live_coregs */
            //hiddenBlitzRadio.prop("checked", true);
            hiddenBlitzRadio.trigger("click");
            /* EDIT: fix_live_coregs */
            // hide/slide up the 'Blitz' CoReg, and show the next CoReg (if any exists)
            //$(".mfw_coreg_837 .app_coreg").slideUp(900);
            FinalizeCoreg($(".mfw_coreg_837 .coregContainer"), configData, false, true);
        }
        // make sure that we don't accidentally trigger other actions (like the 'submit' process)
        event.preventDefault();
    });
    /* EDIT: blitz_coreg_changes */
}

function UltraFlexInputStyleString(configData) {
    var styleStr = "";
    if ("input" in configData) {
        if ("fontcolor" in configData.input) {
            styleStr += ".controls-area input, .controls-area select {color: " +
                        configData.input.fontcolor + " !important;}";
        }
        if ("bgcolor" in configData.input) {
            styleStr += ".controls-area input, .controls-area select {background-color: " +
                        configData.input.bgcolor + " !important;}";
        }
        if ("border" in configData.input) {
            if ("width" in configData.input.border) {
                var borderWidth = parseInt(configData.input.border.width);
                if (borderWidth > 0) {
                    var borderColor = configData.input.border.color;
                    borderStr = borderWidth + "px solid " + borderColor;
                    styleStr += ".controls-area input, .controls-area select {border: " +
                                borderStr + " !important;}";
                }
                styleStr += ".controls-area input, .controls-area select {border-radius: " +
                            configData.input.border.radius + "px !important;}";
            }
        }
        if ("hints" in configData.input &&
            "display" in configData.input.hints &&
            configData.input.hints.display == "true") {
            $(".input-hint.hint-email").text(configData.input.hints.email);
            $(".input-hint.hint-phone").text(configData.input.hints.phone);
            // set up input hint messages for email and phone input fields
            SetupInputHints();
        }
    }
    return styleStr;
}

function UltraFlexBgFrameStyleString(configData) {
    var styleStr = "";
    if ("input" in configData &&
        "bgframe" in configData.input &&
        "display" in configData.input.bgframe &&
        configData.input.bgframe.display == "true") {
        styleStr += ".controls-area {border-left-style: none;}";
        if ("bgcolor" in configData.input.bgframe) {
            if ("opacity" in configData.input.bgframe) {
                // mix the user-supplied opacity value into the background color
                var rgbBackgroundColor = HexColorToRgb(configData.input.bgframe.bgcolor);
                var bgframeBgColor = "rgba(" + rgbBackgroundColor.red + ", " + rgbBackgroundColor.green +
                                     ", " + rgbBackgroundColor.blue + ", " + configData.input.bgframe.opacity + ")";
                
            } else {
                var bgframeBgColor = configData.input.bgframe.bgcolor;
            }
            styleStr += ".controls-area {background-color: " +
                        bgframeBgColor + " !important;}";
        }
        if ("radius" in configData.input.bgframe) {
            styleStr += ".controls-area {border-radius: " +
                        configData.input.bgframe.radius + "px !important;}";
        }
        if ("dropshadow" in configData.input.bgframe &&
            configData.input.bgframe.dropshadow.display == "true") {
            styleStr += ".controls-area {box-shadow: 3px 3px 6px #0000008c;}";
        }
    } else {
        // when the background frame is hidden, make sure the "left-over" border
        // on the left is hidden, too
        styleStr += ".controls-area {border-left: none !important;}"; 
    }
    return styleStr;
}


function UltraFlexCoregStyleString(configData) {
    var styleStr = "";
    if ("coregs" in configData ) {
        if ("progress" in configData.coregs &&
            "show_icons" in configData.coregs.progress &&
            configData.coregs.progress.show_icons == "false") {
            styleStr += ".hybrid-area {display: none !important;}";
        }
        if ("incentive" in configData.coregs) {
            if ("show_incentive" in configData.coregs.incentive &&
                configData.coregs.incentive.show_incentive == "true") {
                styleStr += ".coreg-extra-banner-text {display: block !important;}";
                if ("text" in configData.coregs.incentive) {
                    $("div.extra-banner-text").text(configData.coregs.incentive.text);
                }
                if ("textcolor" in configData.coregs.incentive) {
                    styleStr += ".coreg-extra-banner-text {color: " +
                                configData.coregs.incentive.textcolor + " !important;}";
                }
                if ("bgcolor" in configData.coregs.incentive) {
                    styleStr += ".coreg-extra-banner-text {background-color: " +
                                configData.coregs.incentive.bgcolor + " !important;}";
                }
                if ("file" in configData.coregs.incentive &&
                    configData.coregs.incentive.file.length > 0) {
                    styleStr += ".extra-banner-container .extra-banner-img {";
                    styleStr += "background-image: url('https://www.rlcontrol.de/ftp/ultraflex/build/incentive/" +
                                configData.coregs.incentive.file + ".png') !important;";
                    styleStr += "display: block !important;}";
                }
            }
        }
    }
    return styleStr;
}

function UltraFlexBackgroundStyleString(configData) {
    var styleStr = "";
    if ("content" in configData && "background" in configData.content) {
        if ("color" in configData.content.background) {
            styleStr += "body {background-color: " + configData.content.background.color + " !important;}";
        }            
        if (OnRegistrationPage()) {
            if ("show_shadow" in configData.content.background &&
                configData.content.background.show_shadow == "false") {
                styleStr += ".deco-container {background-image: none !important;}";
                styleStr += ".outer-container {margin-top: 0; margin-bottom: 0;}";
            }
            if ("show_top_margin" in configData.content.background &&
                configData.content.background.show_top_margin == "false") {
                styleStr += ".deco-container {margin-top: 0;}";
            }
            if ("use_image" in configData.content.background &&
                configData.content.background.use_image == "true" &&
                "file" in configData.content.background &&
                configData.content.background.file.length > 0) {
                var bgImageFileStr = "url('https://www.rlcontrol.de/ftp/flexblocks/build/background/" +
                                        configData.content.background.file + ".jpg')";
                styleStr += ".outer-container {background-image: " + bgImageFileStr + " !important;}";
                /*if ("attachment" in configData.content.background) {
                    styleStr += ".outer-container {background-attachment: " + configData.content.background.attachment + " !important;}";
                }*/
                if ("size" in configData.content.background) {
                    styleStr += ".outer-container {background-size: " + configData.content.background.size + " !important;}";
                }
                if ("repeat" in configData.content.background) {
                    styleStr += ".outer-container {background-repeat: " + configData.content.background.repeat + " !important;}";
                }
            }
        }        
    }
    return styleStr;
}

function UltraFlexMobileBackgroundStyleString(configData) {
    var styleStr = "";
    if ("content" in configData && "background" in configData.content &&
        "mobile" in configData.content.background) {
        styleStr += "@media only screen and (max-width: 767px) {";
        if (OnRegistrationPage()) {
            if ("use_image" in configData.content.background.mobile &&
                configData.content.background.mobile.use_image == "true" &&
                "file" in configData.content.background.mobile &&
                configData.content.background.mobile.file.length > 0) {
                var bgImageFileStr = "url('https://rlmgws-data.s3.eu-central-1.amazonaws.com/ultraflex/build/background_mobile/" +
                                        configData.content.background.mobile.file + ".jpg')";
                styleStr += "body {background-image: " + bgImageFileStr + " !important;}";
                if ("size" in configData.content.background.mobile) {
                    styleStr += "body {background-size: " + configData.content.background.mobile.size + " !important;}";
                }
                if ("repeat" in configData.content.background.mobile) {
                    styleStr += "body {background-repeat: " + configData.content.background.mobile.repeat + " !important;}";
                }
                if ("fixed_pos" in configData.content.background.mobile &&
                    configData.content.background.mobile.fixed_pos == "true") {
                    styleStr += "body {background-attachment: fixed !important;}";
                }
            }
        }
        styleStr += "}";
    }
    return styleStr;
}

function UltraFlexFontStyleString(configData) {
    var styleStr = "";
    // headline 1
    if ("content" in configData &&
        "hl1" in configData.content) {
        if ("font" in configData.content.hl1) {
            $(".headline1").addClass("font-" + configData.content.hl1.font);
        }
        if ("color" in configData.content.hl1) {
            styleStr += ".headline1 {color: " + configData.content.hl1.color + " !important;}";
        }
        if ("size" in configData.content.hl1) {
            styleStr += ".headline1 {font-size: " + configData.content.hl1.size + "px !important;}";
        }
        if ("weight" in configData.content.hl1) {
            styleStr += ".headline1 {font-weight: " + configData.content.hl1.weight + " !important;}";
        }
    }
    // headline 2
    if ("content" in configData &&
        "hl2" in configData.content) {
        if ("font" in configData.content.hl2) {
            $(".headline").addClass("font-" + configData.content.hl2.font);
        }
        if ("color" in configData.content.hl2) {
            styleStr += ".headline {color: " + configData.content.hl2.color + " !important;}";
        }
        if ("size" in configData.content.hl2) {
            styleStr += ".headline {font-size: " + configData.content.hl2.size + "px !important;}";
        }
        if ("size_desktop" in configData.content.hl2) {
            styleStr += "@media only screen and (min-width: 768px) { .headline {font-size: " + configData.content.hl2.size_desktop + "px !important;}}";
        }
        if ("weight" in configData.content.hl2) {
            styleStr += ".headline {font-weight: " + configData.content.hl2.weight + " !important;}";
        }
        if ("show_bgcolor" in configData.content.hl2 && configData.content.hl2.show_bgcolor == "true" &&
            "bgcolor" in configData.content.hl2) {
            styleStr += `.controls-area .headline {background-color: ${configData.content.hl2.bgcolor} !important;
            border-bottom: 1px solid #ababab;}`;
        }
    }
    // UI labels (e.g. 'Geburtsdatum')
    if ("content" in configData &&
        "label" in configData.content) {
        if ("fontcolor" in configData.content.label) {
            styleStr += ".controls-area .ui-label {color: " + configData.content.label.fontcolor + " !important;}";
        }
    }
    return styleStr;
}

function UltraFlexPromotionStyleString(configData) {
    var styleStr = "";
    if ("content" in configData) {
        if ("promotion_position" in configData.content &&
            "x" in configData.content.promotion_position &&
            "y" in configData.content.promotion_position) {
            styleStr += ".desktop-promo-img {left: " + configData.content.promotion_position.x + "px !important; ";
            styleStr += "top: " + configData.content.promotion_position.y + "px !important;}";
        }
        if ("promotion_animation" in configData.content) {
            switch (configData.content.promotion_animation) {
                case "fly-in":
                    $(".desktop-promo-img").addClass("promotion-fly-in-anim");
                    break;
                case "pulsate":
                    $(".desktop-promo-img").addClass("promotion-pulsate-anim");
                    break;
                default:
                    break;
            }
        }
    }
    return styleStr;
}

function UltraFlexExtraStyleString(configData) {
    var styleStr = "";
    if ("content" in configData &&
        "progress" in configData.content &&
        "show_icons" in configData.content.progress &&
        configData.content.progress.show_icons == "true") {
        /* EDIT: ultraflex_prepage_attributes */
        styleStr += `@media only screen and (min-width: 768px) {
            .bottom-bar {
                display: block;
            }
        }
        @media only screen and (max-width: 767px) {
            .bottom-bar-mobile {
                display: block;
            }
            .bottom-bar-hint-mobile {
                display: block;
                /* background-color: ${configData.content.basecolor} !important; */
            }
        }`;
        /* EDIT: ultraflex_prepage_attributes */
    } else {
        styleStr += ".outer-container {padding-bottom: 90px;}";
    }
    return styleStr;
}

function UltraFlexBannerHeaderStyleString(configData) {
    var styleStr = "";
    if ("content" in configData &&
        "header" in configData.content &&
        "text" in configData.content.header &&
        configData.content.header.text.length > 0) {
        $("div.banner-header").text(configData.content.header.text);
        if ("bgcolor" in configData.content.header) {
            styleStr += "div.banner-header {background-color: " + configData.content.header.bgcolor + ";}";
        }
        if ("fontcolor" in configData.content.header) {
            styleStr += "div.banner-header {color: " + configData.content.header.fontcolor + ";}";
        }
        if ("weight" in configData.content.header) {
            styleStr += "div.banner-header {font-weight: " + configData.content.header.weight + ";}";
        }
        if ("size" in configData.content.header) {
            styleStr += "div.banner-header {font-size: " + configData.content.header.size + "px;}";
        }
        $("div.banner-header").show();
    }
    return styleStr;
}

function UltraFlexHeadline3StyleString(configData) {
    var styleStr = "";
    if ("content" in configData &&
        "hl3" in configData.content &&
        "text" in configData.content.hl3 &&
        configData.content.hl3.text.length > 0) {
        if ("font" in configData.content.hl3) {
            $(".headline3").addClass("font-" + configData.content.hl3.font);
        }
        if ("color" in configData.content.hl3) {
            styleStr += ".headline3 {color: " + configData.content.hl3.color + " !important;}";
        }
        if ("size" in configData.content.hl3) {
            styleStr += ".headline3 {font-size: " + configData.content.hl3.size + "px !important;}";
        }
        if ("size_desktop" in configData.content.hl3) {
            styleStr += "@media only screen and (min-width: 768px) { .headline3 {font-size: " + configData.content.hl3.size_desktop + "px !important;}}";
        }
        if ("weight" in configData.content.hl3) {
            styleStr += ".headline3 {font-weight: " + configData.content.hl3.weight + " !important;}";
        }
        $("div.headline3").html(configData.content.hl3.text);
        $("div.headline3").show();
        // check if free-positioning is enabled
        if ("free_pos" in configData.content.hl3 &&
            configData.content.hl3.free_pos == "true") {
            var posX = 0;
            var posY = 0;
            var textWidth = 600;
            if ("position" in configData.content.hl3) {
                if ("x" in configData.content.hl3.position) {
                    posX = configData.content.hl3.position.x;
                }
                if ("y" in configData.content.hl3.position) {
                    posY = configData.content.hl3.position.y;
                }                
            }
            if ("free_pos_width" in configData.content.hl3) {
                textWidth = configData.content.hl3.free_pos_width;
            }
            styleStr += `@media only screen and (min-width: 768px) {
                .centered-container .hl3-free-pos.headline3 {
                    display: block !important;
                    position: absolute;
                    z-index: 1000;
                    left: ${posX}px;
                    top: ${posY}px;
                    width: ${textWidth}px;
                }
                .progress-area .headline3 {
                    display: none !important;
                }
                .progress-area .headline3-dummy {
                    display: block;
                }
            }`;
        }
    }
    return styleStr;
}

function UltraFlexStyleString(configData) {
    var styleStr = "";
    styleStr += UltraFlexBackgroundStyleString(configData);
    styleStr += UltraFlexMobileBackgroundStyleString(configData);
    styleStr += UltraFlexPromotionStyleString(configData);
    styleStr += UltraFlexExtraStyleString(configData);
    styleStr += UltraFlexFontStyleString(configData);
    // only apply certain styles to the registration page,
    // because they might have undesired side effects on the CoReg page, etc.
    if (OnRegistrationPage()) {
        styleStr += UltraFlexHeadline3StyleString(configData);
        styleStr += UltraFlexInputStyleString(configData);
        styleStr += UltraFlexBgFrameStyleString(configData);
        /*if ("content" in configData &&
            "progress" in configData.content &&
            "show_icons" in configData.content.progress &&
            configData.content.progress.show_icons == "true") {
            // add progressbar to registration page 1
            styleStr += ".registration-page-1 .hybrid-area {display: block !important;}";
            styleStr += ".registration-page-1 .hybrid-area .progress1-regpage {display: block !important;}";
            $(".registration-page-1 .hybrid-area .progress1-regpage").addClass("visible");
            $(".registration-page-1 .hybrid-area .progress2").addClass("visible");
            // add progressbar to registration page 2
            styleStr += ".registration-page-2 .hybrid-area {display: block !important;}";
            styleStr += ".registration-page-2 .hybrid-area .progress1-regpage {display: block !important;}";
            $(".registration-page-2 .hybrid-area .progress1-regpage").addClass("visible");
            $(".registration-page-2 .hybrid-area .progress2").addClass("visible");
        }*/
        if ("content" in configData &&
            "progress" in configData.content &&
            "show_infotext" in configData.content.progress &&
            configData.content.progress.show_infotext == "false") {
            $("div.progress-text").hide();
        }
        styleStr += UltraFlexBannerHeaderStyleString(configData);        
    } else if (OnCoregPage()) {
        styleStr += UltraFlexCoregStyleString(configData);
    }
    return styleStr;
}

function UndoBgFrameStyling() {
    var customCssStyle = $("#dynamic-styles");
    var styleCssStr = ".controls-area {background-color: transparent !important;}" +
                      ".controls-area {box-shadow: none;}";
    customCssStyle.append(styleCssStr);
}

/**
 * Build a full image path (plus filename) from a shortened mobile promotion filename
 * @param mobileImageName The shortened name of the image file to be used
 * @param useGifFormat Whether to use the GIF image file format
 */
function BuildMobilePromoImagePath(mobileImageName, useGifFormat) {
    var fullImagePath = "https://rlmgws-data.s3.eu-central-1.amazonaws.com/ultraflex/build/promotion_mobile/" + mobileImageName;
    // decide whether to use the GIF format or default to PNG
    fullImagePath += useGifFormat ? ".gif" : ".png";
    return fullImagePath;
}

/**
 * Configure the sweepstake according to a config data structure
 * @param configData The sweepstake configuration data
 * @param currentUserStep The current user progress step (set to -1 for final step)
 */
function ConfigureSweepstake(configData, currentUserStep) {
    // set the default number of user steps (pre-page, registration, CoRegs)
    var totalStepCount = 2;
    // set the browser document/page title
    $("title").text(configData.content.pagetitle);
    // set the text contents for headline 1
    $(".headline1").html(configData.content.hl1.text);
    // check if the headline is making use of text alignment
    if ("align" in configData.content.hl1) {
        // available text alignment options
        var alignOptions = ["left", "center", "right"];
        // make sure the selected alignment option is valid
        if (alignOptions.includes(configData.content.hl1.align)) {
            // add the user-requested text alignment property class
            $(".headline1").addClass(configData.content.hl1.align);
        }
    }
    // set the text contents for headline 2
    $(".controls-area .headline2, .registration-page-1 .headline, .registration-page-2 .headline").html(configData.content.hl2.text);
    // check if a prepage processing message was provided
    if ("processing_text" in configData.prepage && configData.prepage.processing_text.length) {
        // overwrite the default prepage processing message
        prepageProcessingMessage = configData.prepage.processing_text;
    }
    /* EDIT: store_sweepstake_prize */
    // if it was provided by the RLM set, copy the sweepstake prize text to the Coyote form
    if ("tech" in configData && "prize" in configData.tech  &&
        configData.tech.prize.length) {
        $("input[name='adressData[infofeld17]']").val(configData.tech.prize);
    }
    /* EDIT: store_sweepstake_prize */
    // initialize the prepage quiz if the related data is available.
    // This is only relevant for the first registration page
    //if (!OnCoregPage() && configData.prepage.display == "true") {
    if (OnFirstRegPage() && configData.prepage.display == "true") {
        $.get(location.origin + "/ftp/ultraflex/services/resource.php?prepage=" + configData.prepage.file,
              function(prepageData) {
                  /* EDIT: fix_rlmset_storage */
                  // check if the prepage has already been finished by the user
                  prepageFinished = GetCookie("prepage-finished");
                  // make sure that prepageFinished is treated as an integer
                  if (prepageFinished !== null) {
                      prepageFinished = parseInt(prepageFinished);
                  }
                  // skip the prepage if it has already been finished by the user
                  // (this might be a page reload)
                  if (prepageData.success && !prepageFinished) {
                  /* EDIT: fix_rlmset_storage */
                      // show the prepage 'headline2' element
                      $(".controls-area .headline2").show();
                      // set headline 1 to the headline 1 text provided by the prepage
                      $(".headline1").html(DecodeBase64(prepageData.prepage.pp_core.hl1.text));
                      // set headline 2 to the headline 2 text provided by the prepage
                      $(".controls-area .headline2, .registration-page-2 .headline").html(DecodeBase64(prepageData.prepage.pp_core.hl2.text));
                      // increase the step count to 3 (in order to include the prepage)
                      totalStepCount = 3;
                      /*// if currentUserStep equals -1, move to the last step of the process
                      if (currentUserStep == -1) {
                          currentUserStep = totalStepCount;
                      }*/
                      // only show a prepage when the first registration page is active
                      if (OnFirstRegPage()) {
                      // display quiz prepage
                          if (prepageData.prepage.pp_tech.type == "Fragen") {
                              // initialize the quiz
                              InitPrepageQuiz(totalStepCount, configData, prepageData);
                          } else if (prepageData.prepage.pp_tech.type == "Auswahl") {
                              InitPrepageImageSelector(totalStepCount, configData, prepageData);
                          }
                      }
                  } else {
                      // simply show the first registration page instead of the prepage
                      $(".registration-page-1").show();
                      // only update the progress indicator if we are not on the CoReg page
                      if (!OnCoregPage()) {
                          // show the initial user progress
                          UpdateUserProgress(totalStepCount, currentUserStep, configData);
                      } else {
                          // show the initial CoReg progress bar
                          /* EDIT: progressbar_neu20210305 */
                          /*DrawCoregProgressBar($("#progress-indicator")[0].getContext("2d"),
                                               0, 0,
                                               $("#progress-indicator").width(),
                                               $("#progress-indicator").height(),
                                               configData);*/
                          /* EDIT: progressbar_neu20210305 */
                          // make sure that only the first CoReg is shown, etc.
                          InitCoregs(configData);
                      }
                  }
                  // show the user progress indicator only on the first pages, CoRegs
                  // get a different progress bar
                  var showTopProgressIndicator;
                  if (!OnCoregPage()) {
                      showTopProgressIndicator = true;
                  } else {
                      // hide the countdown clock (if visible)
                      // $(".left-area .counter").hide();
                      $(".counter").hide();
                      // hide the regular user progress indicator...
                      showTopProgressIndicator = false;
                      // ...and show the initial CoReg progress bar instead
                      /* EDIT: progressbar_neu20210305 */
                      /*DrawCoregProgressBar($("#progress-indicator")[0].getContext("2d"),
                                           0, 0,
                                           $("#progress-indicator").width(),
                                           $("#progress-indicator").height(),
                                           configData);*/
                      /* EDIT: progressbar_neu20210305 */
                      // make sure that only the first CoReg is shown, etc.
                      InitCoregs(configData);
                  }
                  // show the initial user progress
                  UpdateUserProgress(totalStepCount, currentUserStep, configData,
                                     showTopProgressIndicator);
              }).fail(function() {
                  // simply show the first registration page instead of the prepage
                  $(".registration-page-1").show();
                  // only update the progress indicator if we are not on the CoReg page
                  if (!OnCoregPage()) {
                      // show the initial user progress
                      UpdateUserProgress(totalStepCount, currentUserStep, configData);
                  } else {
                      // show the initial CoReg progress bar
                      /* EDIT: progressbar_neu20210305 */
                      /*DrawCoregProgressBar($("#progress-indicator")[0].getContext("2d"),
                                           0, 0,
                                           $("#progress-indicator").width(),
                                           $("#progress-indicator").height(),
                                           configData);*/
                      /* EDIT: progressbar_neu20210305 */
                      // make sure that the user progress shown in the bottom bar is updated
                      UpdateUserProgress(totalStepCount, -1, configData, false);
                      // make sure that only the first CoReg is shown, etc.
                      InitCoregs(configData);
                  }
              });
    } else {
        // simply show the first registration page instead of the prepage
        $(".registration-page-1").show();
        /*// if currentUserStep equals -1, move to the last step of the process
        if (currentUserStep == -1) {
            currentUserStep = totalStepCount;
        }*/
        // only update the progress indicator if we are not on the CoReg page
        if (!OnCoregPage()) {
            // show the initial user progress
            UpdateUserProgress(totalStepCount, currentUserStep, configData);
        } else {
            // show the initial CoReg progress bar
            /* EDIT: progressbar_neu20210305 */
            /*DrawCoregProgressBar($("#progress-indicator")[0].getContext("2d"),
                                 0, 0,
                                 $("#progress-indicator").width(),
                                 $("#progress-indicator").height(),
                                 configData);*/
            /* EDIT: progressbar_neu20210305 */
            // make sure that the user progress shown in the bottom bar is updated,
            // and take the prepage into count if available
            UpdateUserProgress(configData.prepage.display == "true" ? totalStepCount + 1 : totalStepCount,
                               -1, configData, false);
            // make sure that only the first CoReg is shown, etc.
            InitCoregs(configData);
        }
    }
    // only show the timer circle if requested, and initialize and run the countdown clock
    if (!OnCoregPage() && configData.content.counter.display == "true") {
        // var counter = $(".left-area .counter");
        var counter = $(".counter");
        // show the counter
        counter.show();
        // set up the counter customization.
        // Mix the user-supplied opacity value into the background color
        var rgbBackgroundColor = HexColorToRgb(configData.content.counter.bgcolor);
        var rgbaBackgroundColor = "rgba(" + rgbBackgroundColor.red + ", " + rgbBackgroundColor.green +
                                  ", " + rgbBackgroundColor.blue + ", " + configData.content.counter.opacity + ")";
        // set the counter text color
        if (configData.content.counter.textcolor) {
            counter.css("color", configData.content.counter.textcolor);
        }
        // set the combined background color
        counter.css("background-color", rgbaBackgroundColor);
        // set the counter position
        counter.css("left", configData.content.counter.position.x + "px");
        counter.css("bottom", configData.content.counter.position.y + "px");
        // set the counter label font size
        if (configData.content.counter.fontsize !== undefined) {
            counter.find("label").css("font-size", configData.content.counter.fontsize + "px");
        }
        // update the pre-clock text label
        counter.find("label.pre-clock").html(configData.content.counter.pre_clock_text);
        // update the post-clock text label
        counter.find("label.post-clock").html(configData.content.counter.post_clock_text);
        // start the countdown clock
        RunCountdownClock(configData.content.counter);
    } else {
        // ...simply hide the countdown clock
        // $(".left-area .counter").hide();
        $(".counter").hide();
    }
    // colorize various UI components to fit the user-provided color scheme by overwriting
    // their default CSS styles.
    // Colorize the user progress marker at the bottom of the screen
    var customStyle = '<style type="text/css" id="dynamic-styles">.bottom-bar-content .progress-step.active .step-count {background-color: ' +
                      configData.content.basecolor + " !important;}";
    // colorize the prepage quiz answer buttons
    customStyle += ".controls-area .prepage-quiz .answer {background-color: " +
                   configData.content.basecolor + " !important;" +
                   "border: 2px solid " + configData.content.shadowcolor + " !important;}";
    customStyle += ConfigureContinueButton(configData);
    // colorize the custom 'text-switch' controls (e.g. for setting the appellation field value)
    customStyle += ".controls-area .row .text-switch div.selected {background-color: " +
                   configData.content.basecolor + " !important;" +
                   "color: white !important;}";
    customStyle += ".controls-area .row .text-switch div {color: " +
                   configData.content.basecolor + " !important;}";
    // colorize the second button of the Yes/No CoRegs
    customStyle += ".yes-no-answer div:last-child {background-color: " +
                   configData.content.basecolor + ";}";
    /* EDIT: promo_consent_dialog */
    // set the header color of the promotion consent dialog
    customStyle += ".promo-consent-window .window-header {background-color: " +
                  configData.content.basecolor + " !important;}";
    // apply UltraFlex style extensions
    customStyle += UltraFlexStyleString(configData);
    /* EDIT: promo_consent_dialog */
    $("head").append(customStyle + "</style>");
    // the promo image filename stored can be in a cookie, so it can be passed to the CoReg page
    //var cookiePromoImage;
    var cookiePromoImage = GetCookie("promo-image");
    // check if a mobile promotion image is available
    var cookieMobilePromoImage = GetCookie("promo-mobile-image");
    // set up the promotion image if available (but only on pages after the first registration
    // page, because otherwise an image from a previous session might override the rlmset provided
    // promotion image)
    /* EDIT: fix_rlmset_storage */
    //if (!OnFirstRegPage() && (cookiePromoImage = GetCookie("promo-image"))) {
    // find out if the user is done with the prepage
    var prepageFinished = GetCookie("prepage-finished");
    // make sure that prepageFinished is treated as an integer
    if (prepageFinished !== null) {
        prepageFinished = parseInt(prepageFinished);
    }
    // check if the mobile promotion image is in GIF format
    if ('mobile_promotion_is_gif' in configData.content &&
        configData.content.mobile_promotion_is_gif == "true") {
        var mobilePromotionIsGif = true;
    } else {
        var mobilePromotionIsGif = false;
    }
    // only access the promo image if is available and we're either not on the first
    // registration page anymore, or if the prepage has been finished successfully
    if (cookiePromoImage && (!OnFirstRegPage() || prepageFinished)) {
    /* EDIT: fix_rlmset_storage */
        // if we are on the CoReg page, and the 'promo-image' cookie was set,
        // make sure that the image source URL points to the image file which was
        // passed between the web pages
        //$(".promo-img").attr("src", cookiePromoImage);
        /* EDIT: promo_video */
        SetPromotionImage(cookiePromoImage, configData.content.promotion_video,
                          cookieMobilePromoImage);
        /* EDIT: promo_video */
        // make the background color 'invisible'
        $(".promo-img, .desktop-promo-img").css("background-color", "transparent");
    /* EDIT: promo_video */
    } else if (configData.content.promotion || configData.content.promotion_video) {
        /* EDIT: promo_video */
        /* EDIT: promo_gif */
        // check if the promotion image is in GIF format
        if ('promotion_is_gif' in configData.content &&
            configData.content.promotion_is_gif == "true") {
            var imageFileExtension = ".gif";
        } else {
            // ...or if it is using the default PNG format
            var imageFileExtension = ".png";
        }        
        // store the original promotion image filename so we can retrieve it later
        originalPromoImage = location.origin + "/ftp/flexfancy/build/promotion/" + configData.content.promotion + imageFileExtension;
        /* EDIT: promo_gif */
        // make sure that the image source URL points to the correct image file
        //$(".promo-img").attr("src", originalPromoImage);
        /* EDIT: promo_video */
        originalMobilePromoImage = BuildMobilePromoImagePath(configData.content.promotion_mobile,
                                                             mobilePromotionIsGif);
        SetPromotionImage(originalPromoImage, configData.content.promotion_video,
                          originalMobilePromoImage);
        /* EDIT: promo_video */
        // make the background color 'invisible'
        $(".promo-img, .desktop-promo-img").css("background-color", "transparent");
        // keep track of the promotion image, so it can be used by the CoReg page
        // (must be passed via cookie)
        //document.cookie = "promo-image=" + originalPromoImage;
        SetCookie("promo-image", originalPromoImage);
        SetCookie("promo-mobile-image", originalMobilePromoImage);
    } else if (cookieMobilePromoImage !== null) {
        // in case no desktop promotion has been set,
        // check if only the mobile promotion is available (via a cookie)
        SetPromotionImage(null, null, cookieMobilePromoImage);
    } else if ("promotion_mobile" in configData.content &&
               configData.content.promotion_mobile.length) {
        // in case no desktop promotion has been set,
        // check if only the mobile promotion is available (via a config option)
        originalMobilePromoImage = BuildMobilePromoImagePath(configData.content.promotion_mobile,
                                                             mobilePromotionIsGif);
        SetPromotionImage(null, null, originalMobilePromoImage);
        // record the mobile promotion image using a cookie
        SetCookie("promo-mobile-image", originalMobilePromoImage);
    }
}

/**
 * Apply simple styling code for 'thank you' pages, etc.
 * @param configData The sweepstake configuration data
 */
function ConfigureSimplePage(configData) {
    // if the header element exists, set its style and content
    if ($("#header").length && "header" in configData.content) {
        $("#header").html(configData.content.header.text);
        $("#header").css('color', configData.content.header.color);
        $("#header").css('background-color', configData.content.header.bgcolor);
        $("#header").css('font-size', configData.content.header.size);
        $("#header").css('font-weight', configData.content.header.weight);
    } else {
        // if no header information is available, hide the header element
        $("#header").hide();
    }
}

/**
 * Determine whether the user is on the CoReg page
 * @return boolean Whether we are on the CoReg page
 */
function OnCoregPage() {
    // return ($("#rlmset-name").length ? true : false);
    return ($("#mfw_fieldset_ownCoregData").length ? true : false);
}

/**
 * Determine whether the user is on the registration page(s)
 * @return boolean Whether we are on the registration page
 */
function OnRegistrationPage() {
    return ($(".registration-page-1").length || $(".registration-page-2").length) ? true : false;
}

/**
 * Determine whether the user is on registration page 1
 * @return boolean Whether we are on registration page 1
 */
function OnRegistrationPage1() {
    return $(".registration-page-1").length ? true : false;
}

/**
 * Determine whether the user is on registration page 2
 * @return boolean Whether we are on registration page 2
 */
function OnRegistrationPage2() {
    return $(".registration-page-2").length ? true : false;
}

function InitSweepstake() {
    var defaultConfig = CreateDefaultConfig();
    /* EDIT: fix_rlmset_storage */
    // clear rlmset name
    var rlmsetName = null;
    // set the current user step
    var currentUserStep = 1;
    // check if any URL parameters were given
    if (location.search.length) {
        // parse the URL parameters...
        var urlParms = location.search.substr(1).split("&");
        // traverse the list of URL parameters
        for (var i in urlParms) {
            // split the current URL parameter into a key/value pair
            var parmKeyPair = urlParms[i].split("=");
            // check if we found the 'rlmset' parameter
            if (parmKeyPair[0] == "rlmset") {
                // fetch the rlmset base filename
                rlmsetName = parmKeyPair[1];
                // we have found what we were looking for, so exit the loop
                break;
            }
        }
    }
    // if the rlmset name couldn't be fetched from the URL, check if it was stored
    // in a hidden element or passed as a cookie of some sort
    if (rlmsetName === null) {
        // check if an rlmset name was transferred via a hidden element, and make use of it
        if ($("#rlmset-name").length && $("#rlmset-name").val().length) {
            rlmsetName = $("#rlmset-name").val();
        } else {
            // try to fetch rlmset name from a cookie
            var cookieValue = GetCookie("rlmset-name");
            if (cookieValue !== false) {
                // use the cookie value...
                rlmsetName = cookieValue;
            }
        }
    }
    // if the rlmset name still isn't set, assume a default value
    if (rlmsetName === null) {
        rlmsetName = "250_blank_de";
    }
    // perform some cookie registration code in the first part of the sweepstake
    //if (!OnCoregPage()) {
    //if (OnRegistrationPage()) {
    if (OnFirstRegPage()) {
        currentUserStep = 1;
        // store the rlmset name in the infofeld20 field, so its name can be
        // fetched from the CoReg page
        $(".mfw_adressData_infofeld20 input").val(rlmsetName);
        // also store the rlmset name in 'freifeld3', to be compliant with other sweepstakes
        $("input[name='adressData[freifeld3]']").val(rlmsetName);
        // also set a cookie to make sure that the rlmset name is transferred even after page reloads
        // (will not work if cookies are disabled, of course)
        //document.cookie = "rlmset-name=" + rlmsetName;
        SetCookie("rlmset-name", rlmsetName);
        // we have found what we were looking for, exit the loop
    } else {
        // // we are on the CoReg page, so set the current user step to -1 (the final step)
        // currentUserStep = -1;
        // try to fetch rlmset name from a cookie
        /*var cookieValue = GetCookie("rlmset-name");
        if (cookieValue !== false) {
            // use the cookie value...
            rlmsetName = cookieValue;
        } else if ($("#rlmset-name").val().length) {
            // or check if an rlmset name was transferred via a hidden element, and make use of it
            rlmsetName = $("#rlmset-name").val();
        }*/
        // we have move passed the first registration page, so set the current user step accordingly
        if (OnSecondRegPage()) {
            // this is the second registration page
            currentUserStep = 2;
            // set the global registration page counter to the second registration page
            agbNum = 2;
        } else {
            // this should be the CoReg page
            currentUserStep = 3;
            // make sure the prepage will show again if the user re-opens the sweepstake site
            SetCookie("prepage-finished", 0);
        }
    }
    /* EDIT: fix_rlmset_storage */
    // only query the rlmset service if we were given a valid rlmset name
    /* EDIT: rlmset_name_fix */
    if (rlmsetName && rlmsetName.length) {
    /* EDIT: rlmset_name_fix */
        // attempt to fetch the rlmset contents using the 'rlmset' service
        $.get(location.origin + "/ftp/ultraflex/services/resource.php?rlmset=" + rlmsetName, function(rlmsetData) {
            if (rlmsetData.success) {
                /* EDIT: progressbar_neu20210305 */
                // record rlmset configuration data globally
                globalConfigData = rlmsetData.rlmset;
                /* EDIT: progressbar_neu20210305 */
                // if this is not the 'thank you' page, perform the full sweepstake styling
                if (!OnThankYouPage()) {
                    // rlmset data was returned successfully, now load it in
                    ConfigureSweepstake(rlmsetData.rlmset, currentUserStep);
                } else {
                    // if we are on the 'thank you' page, just apply some simple styling
                    ConfigureSimplePage(rlmsetData.rlmset);
                }
            } else {
                // contacting the rlmset service worked, but the response was invalid
                ConfigureSweepstake(defaultConfig, currentUserStep);
            }
        }).fail(function() {
            // querying the rlmset service failed, so load up the default config
            ConfigureSweepstake(defaultConfig, currentUserStep);
        });
    } else {
        // ...no rlmset name was given, so load up the default config
        ConfigureSweepstake(defaultConfig, currentUserStep);
    }
}

/**
 * Apply custom tweaks to the FAZ CoReg
 */
function ApplyFazTweaks() {
    var fazCoregId = 823;
    var fazCoreg = $(".mfw_coreg_" + fazCoregId);
    if (fazCoreg.length) {
        // scale down some regular sized paragraphs
        fazCoreg.find(".app_coreg_hinweistext p:nth-of-type(2)").addClass("small-coreg-text");
        fazCoreg.find(".app_coreg_hinweistext p:nth-of-type(4)").addClass("small-coreg-text");
        // move the questions and sub-questions around so that they become two separate sets of questions
        fazCoreg.find(".app_coreg_a").css("margin-bottom", "10px");
        $("#faz-answers").append(fazCoreg.find(".app_coreg_a"));
        fazCoreg.find(".app_coreg_a .sub-question-answers").insertAfter(".mfw_coreg_823 .first-paragraph");
        fazCoreg.find(".sub-question-answers").last().hide();
    }
}

/* EDIT: blitz_coreg_changes */
/**
 * Apply some customizations to the 'Blitz' CoReg
 */
function RebuildBlitzCoreg() {
    // check if the 'Blitz' CoReg is actually assigned to this sweepstake
    if ($(".mfw_coreg_837").length) {
        // create a new <div> to store the CoReg description text
        var contentDiv = $('<div class="blitz-coreg-content"></div>');
        // copy the HTML content of the 'blitz-coreg-extra' span to the new CoReg footer <div>
        contentDiv.html($(".mfw_coreg_837 .blitz-coreg-extra").html());
        // append the new <div> to the CoReg body
        $(".mfw_coreg_837 .app_coreg_a").append(contentDiv);
        // add the 'buy now' button element after the CoReg footer
        $(".mfw_coreg_837 .app_coreg_a").append('<button class="blitz-coreg-button">Jetzt kostenpflichtig bestellen</button>');
    }
}
/* EDIT: blitz_coreg_changes */

/**
 * Figure out if we are running on a mobile device
 * @return boolean Whether this is a mobile device
 */
function IsMobileBrowser() {
    // perform a regex test to see if the user agent is a mobile one
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
        // yupp, it is a mobile device...
        return true;
    } else {
        // ...no, it is desktop machine (or something else)
        return false;
    }
}

/* EDIT: promo_consent_dialog */
/**
 * Find out if this is the first registration page
 * @return boolean Whether this is the first registration page
 */
function OnFirstRegPage() {
    //return $(".registration-page-1").is(":visible");
    return ($(".registration-page-1").length ? true : false);
}

/**
 * Find out if this is the second registration page
 * @return boolean Whether this is the second registration page
 */
function OnSecondRegPage() {
    //return $(".registration-page-2").is(":visible");
    return ($(".registration-page-2").length ? true : false);
}

/**
 * Show an arrow hint animation which points to the 'Continue' button
 */
function showArrowHint() {
    $(".arrow-hint-container").addClass("arrow-hint");
    // set up a timeout function to remove the arrow hint animation after a certain amount
    // of time
    /*setTimeout(function() {
        $(".arrow-hint-container").removeClass("arrow-hint");
    }, 3000);*/
}
/* EDIT: promo_consent_dialog */

/* EDIT: spiegel_coreg */
/**
 * Apply some tweaks to the 'Spiegel' CoReg
 */
function ModifySpiegelCoreg() {
    var spiegelCoregId = 915;
    var spiegelCoreg = $(".mfw_coreg_" + spiegelCoregId);
    if (spiegelCoreg.length) {
        //$("#spiegel-coreg-answers").append(spiegelCoreg.find(".app_coreg_a"));
        spiegelCoreg.find(".coregAnswers").insertAfter($("#spiegel-coreg-answers"));
    }
}
/* EDIT: spiegel_coreg */

/**
 * Apply additional Coyote layout fixes, etc.
 */
function ApplyAdjustments() {
    // look up the "country" selection list element
    var countrySelectElement = $("#country");
    // remove all the "select" options contained within...
    countrySelectElement.find("option").remove();
    // store the accumulated list of selection option elements as a string
    var optionHtmlStr = "";
    // ...and rebuild them to match the Coyote setup
    $(".mfw_adressData_land option").each(function() {
        // create a <select> option element based on the Coyote combobox item
        optionHtmlStr += '<option value="' + $(this).val() + '">' + $(this).text() + "</option>";
    });
    // append the newly generated option elements to the country combobox
    countrySelectElement.append(optionHtmlStr);
    // attach a 'change' event handler to the country selection combobox
    countrySelectElement.change(function(event) {
        // the CSS selector for selecting the ZIP code input element
        var inputSelectorStr = "input[name=zip_code]";
        // the jQuery ZIP input element
        var inputElement = $(inputSelectorStr);
        // validate the ZIP input element to find out whether to show or hide the error icon
        // (the boolean value needs to be inverted because successful validation should hide the error)
        var showError = !InputValidator.validate(inputElement, inputValidators[inputSelectorStr]);
        // show or hide the input element error state
        InputValidator.showError(inputElement, showError);
    });
    // move the "I don't want to receive any calls" checkbox to the top of the sponsor list
    var checkboxParent = $(".telSponsors > input[type=checkbox]").parent();
    // move the checkbox
    checkboxParent.prependTo($(".sponsorListe"));
    // replace the <small> tag with a <span>
    $(".telSponsors > small").replaceWith("<span>" + $(".telSponsors > small").text() + "</span>");
    // apply manual tweaks to the FAZ CoReg
    ApplyFazTweaks();
    /* EDIT: promo_consent_dialog */
    // attach event handlers to handle the consent / no consent buttons differently depending on
    // the current registration page
    $(".promo-consent-window .with-consent-button").click(function(event) {
        if (OnFirstRegPage()) {
            // hide the promotion consent window
            $(".promo-consent-window").hide();
            // accept the 'AGB1' checkbox
            /* EDIT: agb_dialog */
            //$("p.mfw_adressData_agb1 input.checkbox").prop("checked", true);
            /* EDIT: agb_dialog */
            // show the checked 'AGB1' checkbox state
            $("div.agb1-accepted").addClass("checked");
            // display an arrow which points to the 'Continue' button
            showArrowHint();
            // show the second stage of the registration process
            // ShowSecondRegPage();
        } else if (OnSecondRegPage()) {
            // hide the promotion consent window
            $(".promo-consent-window").hide();
            // accept the 'AGB2' checkbox
            /* EDIT: agb_dialog */
            //$("p.mfw_adressData_agb1 input.checkbox").prop("checked", true);
            /* EDIT: agb_dialog */
            // show the checked 'AGB2' checkbox state
            $("div.agb2-accepted").addClass("checked");
            // display an arrow which points to the 'Continue' button
            showArrowHint();
            // submit the form data
            //$("input[type=submit]").trigger("click");
        }
    });
    $(".promo-consent-window .without-consent-button").click(function(event) {
        if (OnFirstRegPage()) {
            // hide the promotion consent window
            $(".promo-consent-window").hide();
            // show the second stage of the registration process
            ShowSecondRegPage();
        } else if (OnSecondRegPage()) {
            // hide the promotion consent window
            $(".promo-consent-window").hide();
            // submit the form data
            $("input[type=submit]").trigger("click");
        }
    });
    /* EDIT: promo_consent_dialog */
    /* EDIT: blitz_coreg_changes */
    // initialize the custom setup for the 'Blitz' CoReg
    RebuildBlitzCoreg();
    /* EDIT: blitz_coreg_changes */
    // record the device type in 'freifeld10'
    if (IsMobileBrowser()) {
        $('[name="adressData[freifeld10]"]').val("mobil");
    } else {
        $('[name="adressData[freifeld10]"]').val("online");
    }

    /* EDIT: promo_consent_info_window */
    // setup the promo consent info window event handlers
    SetupPromoConsentInfoWindow();
    /* EDIT: promo_consent_info_window */

    /* EDIT: spiegel_coreg */
    ModifySpiegelCoreg();
    /* EDIT: spiegel_coreg */
}

/**
 * Show the CoReg 'Störer' dialog
 */
function ShowCoregStoerer() {
    $(".window-modal-bg").show();
    /* EDIT: rlm_stat_analytics */
    // fetch the coreg ID of the current CoReg element
    var coregId = GetCoregIdFromElement(currentCoregParent);
    /* EDIT: iframe_coreg */
    // check if the currently displayed CoReg is the iframe CoReg
    if (IsMobileBrowser() && coregId == "1132") {
        // because the iframe CoReg content might be rather "tall",
        // scroll to the dialog position to make sure it is visible
        //$(document).scrollTop($(".window-modal-bg").offset().top - 5);
        $(document).scrollTop(120);
    }
    /* EDIT: iframe_coreg */
    // track the 'stoerer_shown' event
    if (typeof RlmStat !== "undefined") {
        RlmStat.StoererShown(coregId);
    }
    /* EDIT: rlm_stat_analytics */
}

/**
 * Hide the CoReg 'Störer' dialog
 */
function HideCoregStoerer() {
    $(".window-modal-bg").hide();
}

/**
 * Create the HTML code for the 'Störer' dialog
 */
function SetupStoerer() {
    var stoererHtmlStr = `<div class="window-modal-bg">
                        	<div class="window">
                        		<div class="header">
                                    <div class="header-title">ACHTUNG!</div>
                                    <div class="close-button"></div>
                                </div>
                        		<div class="content">
                        			<div class="info-box">
                        				<div class="text1">Sie verpassen Ihre doppelte Gewinnchance!</div>
                        				<div class="warning-icon"></div>
                        			</div>
                        			<div class="text2">Jetzt mindestens 5&nbsp;Fragen beantworten!</div>
                        			<div class="buttons">
                        				<div class="skip-button">
                        					<div class="button-label">Nein, Chance verpassen!</div>
                        				</div>
                        				<div class="close-button">
                        					<div class="button-label">Ja, Chance sichern!</div>
                        				</div>
                        			</div>
                        		</div>
                        	</div>
                        </div>`;
    $(".right-area").append(stoererHtmlStr);
    $(".window-modal-bg .close-button").click(function(event) {
        HideCoregStoerer();
    });
    $(".window-modal-bg .skip-button").click(function(event) {
        HideCoregStoerer();
        hide_coreg_and_show_next(true);
    });
}

/**
 * Set up the new-style progressbar
 */
function SetupNewProgressbar() {
    // only show this style of progress bar on the CoReg page
    if (OnCoregPage() || OnRegistrationPage()) {
        /* EDIT: ultraflex_coreg_progressbar_neu */
        // create the container element
        var hybridArea = $('<div class="hybrid-area"></div>');
        // append the progressbar elements
        hybridArea.append('<div class="progress1"></div>');
        hybridArea.append('<div class="progress2"></div>');
        hybridArea.append('<div class="progressbar-new"></div>');
        // add the progress elements to the DOM
        $(".progress-area").append(hybridArea);
        // fade in the first part of the progress bar
        setTimeout(function() {
            $(".hybrid-area .progress1").addClass("wide");
        }, 600);
        // fade in the dotted 'future' progress indicator bar (2nd part of the progressbar)
        setTimeout(function() {
            $(".hybrid-area .progress2").addClass("visible");
        }, 2300);
        /* EDIT: ultraflex_coreg_progressbar_neu */
    }
}

/**
 * Connect hidden input elements to their visible UI counterparts.
 * This should be updated when input elements get added, removed or renamed
 */
function AssignInputCounterparts() {
    // map the internal (hidden) input elements to selectors which look up
    // the visible UI counterparts
    var inputConnections = {
        // registration page 1
        "p.mfw_adressData_vorname": "input[name=firstname]",
        "p.mfw_adressData_name": "input[name=lastname]",
        "p.mfw_adressData_email": "input[name=email]",
        // registration page 2
        "p.mfw_adressData_plz": "#zip_code",
        "p.mfw_adressData_ort": "#city",
        "p.mfw_adressData_strasse": "#street",
        "p.mfw_adressData_hausnr": "#street_no",
        "p.mfw_adressData_land": "#country",
        "select.mfw_daySelect": "select[name=bday_day]",
        "select.mfw_monthSelect": "select[name=bday_month]",
        "select.mfw_yearSelect": "select[name=bday_year]",
        "p.mfw_adressData_telefon1": "input[name=phone]"
    };
    // assign extra information to the hidden input fields,
    // which connects them to their visible UI counterparts
    for (var hiddenInputSelector in inputConnections) {
        // store the element connection selector in a custom attribute
        $(hiddenInputSelector).data("ui-element", inputConnections[hiddenInputSelector]);
        // store the prevously entered input value (if available)
        var inputValue;
        // for country selection, take the value directly from the <select> element
        if (hiddenInputSelector == "p.mfw_adressData_land") {
            inputValue = $("p.mfw_adressData_land select").val();
        } else if (hiddenInputSelector.indexOf("p.") !== -1) {
            // the input value of other <p> elements is stored in a nested <input> element
            inputValue = $(hiddenInputSelector + " input").val();
        } else {
            // other input values (such as <select> elements) are taken directly
            // from the input element
            inputValue = $(hiddenInputSelector).val();
        }
        // copy the internal input element value (if it has been entered previously),
        // into the visible UI input element
        if (typeof (inputValue) !== "undefined" && inputValue.trim().length) {
            $(inputConnections[hiddenInputSelector]).val(inputValue);
        }
    }
    // because the appellation input is a special switch control,
    // handle it separately
    if ($("p.mfw_adressData_anrede").length) {
        // fetch the (prevously selected) appellation value
        var appellationValue = $("p.mfw_adressData_anrede select").val();
        // depending on which appellation was chosen, select a different
        // button element
        if (appellationValue == Translate("Herr")) {
            $(".text-switch .left").addClass("selected");
            $(".text-switch .right").removeClass("selected");
        } else {
            $(".text-switch .right").addClass("selected");
            $(".text-switch .left").removeClass("selected");
        }
    }
}

/**
 * Check if the backend code has marked any user input as 'error',
 * and highlight it accordingly
 */
function HighlightErrors() {
    // traverse all hidden input elements which have been marked as 'error' internally,
    // and transfer the error state to the visual counterpart
    $(".mfwError").each(function(index, errorElement) {
        // fetch the UI element selector string
        var uiElementSelector = $(errorElement).data("ui-element");
        // show the visible error marker
        InputValidator.showError($(uiElementSelector), true);
    });
}

/* EDIT: image_coregs_20181031 */
/**
 * Add images to certain CoRegs
 */
function add_coreg_images() {
    // map CoReg IDs to image filenames
    var coregImageInfo = {"456"/*"967"*/: "1u1_ionos.png",
                          /*"931"*/"972": "berufsunfaehigkeit.png",
                          "791": "brille_a.png",
                          /*"915"*/ /*"974": "der_spiegel_a.png",*/
                          "42"/*"965"*/: "dinner_for_dogs.jpeg",
                          "937"/*"973"*/: "faz.png",
                          /* EDIT: gkv_image_removal */
                          //"200": "krankenkasse.png",
                          /* EDIT: gkv_image_removal */
                          // "474": "strom1.png",
                          "116"/*"889"*/: "strom1.png",
                          "924": "unfallversicherung.png",
                          /* EDIT: coreg_zazu_ohne_bild */
                          // "37": "zahnbehandlung1.png",
                          /* EDIT: coreg_zazu_ohne_bild */
                          "813": "zahnbehandlung2.png",
                          "943": "gfk_frage.png",
                          "46": "sterbeversicherung.png",
                          /* EDIT: amazon_coreg_image */
                          "995": "amazon_prime_logo.png",
                          /* EDIT: amazon_coreg_image */
                          /* EDIT: frank_coregs */
                          "1000": "handelsblatt.png",
                          "1001": "hoerzu.jpeg",
                          "1002": "tvdigital.jpeg",
                          /* EDIT: fisherprice_coreg */
                          "1054": "fisher_price.png",
                          /* EDIT: fisherprice_coreg */
                          /* EDIT: kia_coreg */
                          "1069": "kia_logo.png",
                          /* EDIT: kia_coreg */
                          /* EDIT: o2_coreg */
                          "1070": "o2_logo.jpg",
                          /* EDIT: o2_coreg */
                          /* EDIT: myself_coreg */
                          "1075": "myself.jpg",
                          /* EDIT: myself_coreg */
                          /* EDIT: spiegel_coreg20200205 */
                          "1086": "spiegel_20200205.jpg",
                          /* EDIT: spiegel_coreg20200205 */
                          /* EDIT: donna_coreg */
                          "1104": "donna.jpg",
                          /* EDIT: donna_coreg */
                          /* EDIT: geo_coreg */
                          "1115": "geo.jpg",
                          /* EDIT: geo_coreg */
                          /* EDIT: nicey_coreg_image */
                          "1123": "nicey.png"
                          /* EDIT: nicey_coreg_image */
                      };
                          /* EDIT: frank_coregs */
    // traverse CoReg image info array
    for (var coregId in coregImageInfo) {
        if ($(".mfw_coreg_" + coregId).length) {
            // create the wrapper <div> for the resolution-independent image alignment
            var coregImageWrapper = $('<div class="coreg-image-wrapper"></div>');
            // create the actual image <div>
            var coregImage = $('<div class="coreg-image"></div>');
            // add special size information to certain CoRegs
            switch (coregId) {
                case "943":
                    coregImage.addClass("coreg-image-gfk");
                    break;
                //case "915":
                /*case "974":
                    coregImage.addClass("coreg-image-spiegel");
                    break;*/
                case "791":
                    coregImage.addClass("coreg-image-brille");
                    break;
                /* EDIT: gkv_image_removal */
                /*case "200":
                    coregImage.addClass("coreg-image-krankenkasse");
                    break;*/
                /* EDIT: gkv_image_removal */
                /*case "474":
                    coregImage.addClass("coreg-image-strom1");
                    break;*/
                /* EDIT: coreg_zazu_ohne_bild */
                /*case "37":
                    coregImage.addClass("coreg-image-zahnbehandlung1");
                    break;*/
                /* EDIT: coreg_zazu_ohne_bild */
                case "924":
                    coregImage.addClass("coreg-image-unfall");
                    break;
                case "937"/*"973"*/:
                    coregImage.addClass("coreg-image-faz");
                    break;
                case "456"/*"967"*/:
                    coregImage.addClass("coreg-image-1u1");
                    break;
                /* EDIT: frank_coregs */
                case "1000":
                    coregImage.addClass("coreg-image-handelsblatt");
                    break;
                case "1001":
                    coregImage.addClass("coreg-image-hoerzu");
                    break;
                case "1002":
                    coregImage.addClass("coreg-image-tvdigital");
                    break;
                /* EDIT: frank_coregs */
                /* EDIT: fisherprice_coreg */
                case "1054":
                   coregImage.addClass("coreg-image-fisherprice");
                   break;
                /* EDIT: fisherprice_coreg */
                /* EDIT: kia_coreg */
                case "1069":
                    coregImage.addClass("coreg-image-kia");
                    break;
                /* EDIT: kia_coreg */
                /* EDIT: o2_coreg */
                case "1070":
                    coregImage.addClass("coreg-image-o2");
                    break;
                /* EDIT: o2_coreg */
                /* EDIT: myself_coreg */
                case "1075":
                    coregImage.addClass("coreg-image-myself");
                    break;
                /* EDIT: myself_coreg */
                /* EDIT: spiegel_coreg20200205 */
                case "1086":
                    coregImage.addClass("coreg-image-spiegel");
                    break;
                /* EDIT: spiegel_coreg20200205 */
                /* EDIT: donna_coreg */
                case "1104":
                    coregImage.addClass("coreg-image-donna");
                    break;
                /* EDIT: donna_coreg */
                /* EDIT: geo_coreg */
                case "1115":
                    coregImage.addClass("coreg-image-geo");
                    break;
                /* EDIT: geo_coreg */
                /* EDIT: nicey_coreg_image */
                case "1123":
                    coregImage.addClass("coreg-image-nicey");
                    break;
                /* EDIT: nicey_coreg_image */
                default:
                    break;
            }
            // assign the current CoReg image file to the CoReg
            //coregImage.css("background-image",
            //               'url("/ftp/flexblocks/images/coregs/mobile/' + coregImageInfo[coregId] + '")');
            coregImage.css("background-image",
                           'url("https://rlmgws-data.s3.eu-central-1.amazonaws.com/flexfancy/images/coregs/mobile/' + coregImageInfo[coregId] + '")');
            // append the CoReg image to the wrapper <div>
            coregImageWrapper.append(coregImage);
            // create the image <div> element
            /* EDIT: tile_coregs_dynamic */
            //$(".mfw_coreg_" + coregId + " .coreg-header").append(coregImageWrapper);
            $(".mfw_coreg_" + coregId + " .coregHeader").append(coregImageWrapper);
            /* EDIT: tile_coregs_dynamic */
        }
    }
    /*// set the 'Dinner for Dogs' CoReg ID
    var dinnerForDogsId = 42;
    // check if the 'Dinner for Dogs' CoReg ID exists and assign an image
    if ($(".mfw_coreg_" + dinnerForDogsId).length) {
        // create the wrapper <div> for resolution-independent image alignment
        var coregImageWrapper = $('<div class="coreg-image-wrapper"></div>');
        // create the actual image <div> and attach it to the wrapper
        var coregImage = coregImageWrapper.append('<div class="coreg-image"></div>');
        // create the image <div> element
        $(".mfw_coreg_" + dinnerForDogsId + " .coreg-header").append(coregImageWrapper);
    }*/
}
/* EDIT: image_coregs_20181031 */

/* EDIT: agb_coreg */
function apply_agb_coreg_changes() {
    if ($("[name='adressData[plz]']").length) {
        // build the AGB CoReg container
        var agbCoreg = $('<div class="agb-coreg-container"></div>');
        agbCoreg.append('<div class="agb-coreg-header">Wollen Sie auch eine Auszahlung von bis zu 850 Euro jährlich von ihrer gesetzlichen Krankenkasse bekommen?</div>');
        agbCoreg.append('<div class="agb-coreg-questions"></div>');
        // first positive answer
        var checkboxContainer = $('<div class="checkbox-container"></div>');
        checkboxContainer.append(`<div class="disclaimer-text">
            <div id="agb-coreg-01" class="optin-checkbox" data-answer-value="ja"></div>
            <label for="agb-coreg-01" class="checkbox-label">Ja, ich möchte das Geld haben.</label>
        </div>`);
        // append the checkbox element to the special AGB CoReg container
        agbCoreg.find(".agb-coreg-questions").append(checkboxContainer);
        // negative answer
        var checkboxContainer = $('<div class="checkbox-container"></div>');
        checkboxContainer.append(`<div class="disclaimer-text">
            <div id="agb-coreg-04" class="optin-checkbox" data-answer-value="nein"></div>
            <label for="agb-coreg-04" class="checkbox-label">Nein, kein Interesse.</label>
        </div>`);
        // append the checkbox element to the special AGB CoReg container
        agbCoreg.find(".agb-coreg-questions").append(checkboxContainer);
        // insert the AGB CoReg container into the DOM
        agbCoreg.insertAfter(".disclaimer-text");
        // set up a 'click' event handler for the checkbox answers
        $(".agb-coreg-container .checkbox-container").click(function(event) {
            // fetch the internal answer value from the checkbox input
            var checkboxValue = $(this).find(".optin-checkbox").data("answer-value");
            // uncheck all checkboxes before ticking the current one
            //$(".agb-coreg-container input").prop("checked", false);
            $(".agb-coreg-container .optin-checkbox").removeClass("checked");
            // make sure that this checkbox is ticked
            $(this).find(".optin-checkbox").addClass("checked");
            // store the checkbox value in 'infofeld15', so it can be accessed by the backend
            $(".mfw_adressData_infofeld15 input").val(checkboxValue);
        });
    }
}
/* EDIT: agb_coreg */

/* EDIT: selection_list_coreg */
/**
 * Add selection list support to a designated CoReg
 */
function apply_selection_list_coreg_changes() {
    // extra HTML code for multiple-choice answer elements
    var listHtmlStr = `
        <div class="coreg-list-container">
            <div class="coreg-toggle-button" data-value="land_und_leute">Land und Leute</div>
            <div class="coreg-toggle-button" data-value="wohnen_und_deko">Wohnen & Deko</div>
            <div class="coreg-toggle-button" data-value="tv_programm">TV Programm</div>
            <div class="coreg-toggle-button" data-value="alles_fuer_frauen">Alles was Frauen interessiert</div>
            <div class="coreg-toggle-button" data-value="lifestyle">Lifestyle</div>
        </div>
        <div class="ok-button">OK</div>
        <div class="cancel-button">Nein, kein Interesse</div>
    `;
    // insert the new HTML elements after the CoReg answer elements
    $(listHtmlStr).insertAfter(".mfw_coreg_1078 .coregAnswers");
    // when clicking an answer option, toggle its 'checked' state
    $(".coreg-list-container .coreg-toggle-button").click(function(event) {
        $(this).toggleClass("checked");
    });
    // attach a 'click' handler to the 'Ok' button
    $(".mfw_coreg_1078 .ok-button").click(function(event) {
        // the list of user-selected answer options
        var answerList = [];
        // traverse all answer option elements...
        $(".coreg-list-container .coreg-toggle-button").each(function(key, value) {
            // ...and check if the 'checked' class is set
            if ($(value).hasClass("checked")) {
                // take the label of the answer value from this HTML element,
                // and add it to the list of selected answer elements
                answerList.push($(value).data("value"));
            }
        });
        // build a comma-separated string of user-selected answer options
        var answerListStr = answerList.join(",");
        // store the answer option string inside a form element
        $("#coreg1078_answer1").val(answerListStr);
        // clear the negative answer input field
        //$(".mfw_coreg_1078 [data-type='negative']").val("");
        // send the CoReg answer to the server
        //$(".mfw_coreg_1078 button").click();
        $(".coregsend1078.button").trigger("click");
        // proceed to the next CoReg or exit page
        hide_coreg_and_show_next(true);
    });
    // attach a 'click' handler to the 'Cancel' button
    $(".mfw_coreg_1078 .cancel-button").click(function(event) {
        // proceed to the next CoReg or exit page
        hide_coreg_and_show_next(true);
        // send the CoReg answer to the server
        // (this will be a negative answer by default)
        //$(".mfw_coreg_1078 button").click();
        //$(".coregsend1078.button").trigger("click");
    });
}
/* EDIT: selection_list_coreg */

/* EDIT: iframe_coreg */
/**
 * Disable regular display for some CoRegs, and turn them into iframes instead
 */
function apply_iframe_coreg_changes() {
    if ($(".mfw_coreg_1132").length) {
        // fetch the CoReg container element
        var iframeCoreg = $(".mfw_coreg_1132").first();
        // attach the (hidden) iframe content to the iframe CoReg
        $(".sovendus-coreg-iframe").appendTo(iframeCoreg);
        // show the iframe content
        $(".sovendus-coreg-iframe").show();
        // attach an extra skip button to the iframe CoReg
        var skipButtonStr = `
        <div class="iframe-button-container">
            <div class="iframe-skip-button">Kein Interesse</div>
        </div>`;
        iframeCoreg.append(skipButtonStr);
        // make this button open the regular 'Stoerer' window
        $(".iframe-skip-button").click(function(event) {
            hide_coreg_and_show_next(true);
        });
    }
}
/* EDIT: iframe_coreg */

/* EDIT: nicey_coreg20200909 */
function apply_nicey_coreg_changes() {
    if ($(".mfw_coreg_1123").length) {
        var extraHtmlStr = '<div class="nicey-extra-text">Sie erhalten automatisch eine E-Mail von uns. Bitte überprüfen Sie auch Ihren Spam-Ordner.</div>';
        $(".mfw_coreg_1123 .coregContainer").append(extraHtmlStr);
    }
}
/* EDIT: nicey_coreg20200909 */

/* EDIT: rlm_stat_analytics */
function GetCoregIdFromElement(coregWrapper) {
    var classList = coregWrapper[0].classList;
    for (var i in classList) {
        if (classList[i].indexOf("mfw_coreg_") != -1) {
            var classElements = classList[i].split("_");
            return classElements[2];
        }
    }
    return -1;
}
/* EDIT: rlm_stat_analytics */

function SetupInputHints() {
    $("input[name=email], input[name=phone]").focus(function(event) {
        var parentRow = $(this).parent().parent().parent();
        $(this).next().slideDown(600);
    });

    $("input[name=email], input[name=phone]").blur(function(event) {
        var parentRow = $(this).parent().parent().parent();
        $(this).next().slideUp(600);
    });
}

/* EDIT: exitpop_red_lemon */
// the timeout delay for the automatic exit-pop reminder
var exitpopTimeoutDelay = 60000;
// the exit-pop timeout
var exitpopTimeout = null;

function ShowExitPop() {
    $(".rl-modal-dialog-container").show();
}

function HideExitPop() {
    $(".rl-modal-dialog-container").hide();
}

function UpdateExitPopTimeout() {
    // clear the exit-pop timeout (if it exists)
    if (exitpopTimeout !== null) {
        clearTimeout(exitpopTimeout);
    }
    // ...and create a new one
    exitpopTimeout = setTimeout(function() {
        ShowExitPop();
    }, exitpopTimeoutDelay);
}

function apply_exitpop_changes() {
    // only inser the exit-pop code, if the anchor element exists
    if ($("#rl-exit-pop").length > 0) {
        // append the exit-pop dialog html code
        $("#rl-exit-pop").append(`
        <div class="rl-modal-dialog-container">
            <div class="rl-modal-dialog">
                <div class="rl-modal-titlebar">
                    <div class="rl-title-text"></div>
                    <div class="rl-title-close-button"></div>
                </div>
                <div class="rl-modal-body">
                    <iframe src="https://rltools.de/exitpop/" class="exitpop-content"></iframe>
                </div>
            </div>
        </div>`);
        // show the exit-pop when the mouse pointer leaves the screen
        $(document).on('mouseleave', function(event) {
            // only show the modal dialog, if it exists and is actually visible
            if ($(".rl-modal-dialog-container").length > 0 &&
                !$(".rl-modal-dialog-container").is(":visible") &&
                event.clientY < 0) { // less than 60px is close enough to the top
                // show the exit-pop dialog
                ShowExitPop();	
            }
        });
        // attach the dialog close button event handler
        $(".rl-modal-dialog-container .rl-title-close-button").click(function() {
            // hide the modal dialog (and its background layer)
            HideExitPop();
        });
        // automatically show the exit-pop after a certain timespan
        UpdateExitPopTimeout();
        // make sure all click events delay the timeout
        $(document).click(function() {
            UpdateExitPopTimeout();
        });
        // make sure any keyboard input events delay the timeout
        $(document).on("input", function() {
            UpdateExitPopTimeout();
        });
    }
}
/* EDIT: exitpop_red_lemon */

/* EDIT: tell_a_friend */
function apply_tell_a_friend_changes() {
    // custom 'tell-a-friend' dialog HTML content
    var dialogHtmlCode = `
    <script src="https://kit.fontawesome.com/3641b28d8b.js" crossorigin="anonymous"></script>
    <div class="taf-dialog-container">
        <div class="taf-dialog">
            <div class="taf-titlebar">
                <div class="taf-close-button"></div>
            </div>
            <div class="taf-content">
                <h2>Verdopple jetzt deine Gewinnchance
                und lade deine Freunde ein:</h2>
                <div class="taf-button-container">
                    <a href="sms://?body=Hey%2C%20vielleicht%20gewinnen%20wir%20zusammen%3F%20Schau%20hier%20nach%3A%20https%3A%2F%2Fbit.ly%2F3q9bQe4" class="taf-button sms-button"><i class="fa fa-sms"></i></a>
                    <a href="https://api.whatsapp.com/send?text=Hey%2C%20vielleicht%20gewinnen%20wir%20zusammen%3F%20Schau%20hier%20nach%3A%20https%3A%2F%2Fbit.ly%2F3q9bQe4" class="taf-button whatsapp-button"><i class="fa fa-whatsapp"></i></a>
                    <a href="mailto:?subject=Einladung&body=Hey%2C%0A%0Avielleicht%20gewinnen%20wir%20zusammen%3F%20Schau%20hier%20nach%3A%20https%3A%2F%2Fbit.ly%2F3q9bQe4" class="taf-button email-button"><i class="fa fa-envelope"></i></a>
                </div>
            </div>
        </div>
    </div>`;
    // append the 'tell-a-friend' dialog to the DOM
    $("body").append(dialogHtmlCode);
    // hide the 'tell-a-friend' dialog
    $(".taf-close-button").click(function() {
        $(".taf-dialog-container").hide();
    });
}
/* EDIT: tell_a_friend */

/* EDIT: agb_dialog */
/**
 * Apply changes related to the 'Confirmation Layer' element
 */
function apply_agb_dialog_changes() {
    // precache the checkbox image, so that it doesn't pop in noticably
    (new Image).src = "https://rlmgws-data.s3.eu-central-1.amazonaws.com/flexfancy/images/gui/confirm_dialog/confirm_checkbox.png";
    // when clicked, mark confirmation options as selected
    $(".dialog-bg .confirm-option .confirm-checkbox").click(function() {
        $(this).toggleClass("checked");
    });
    // handle clicking the "settings" button
    $(".dialog-bg .agb-settings-button").click(function() {
        // either finish the "settings" screen...
        if ($(this).hasClass("accept-one-or-none")) {
            // check if the email/push checkbox has been checked
            if ($(".dialog-bg .confirm-option.email-push .confirm-checkbox").hasClass("checked")) {
                // set the hidden AGB1 checkbox to 'checked'
                $("p.mfw_adressData_agb1 input.checkbox").prop("checked", true);
            }
            // check if the phone/sms/mail/push checkbox has been checked
            if ($(".dialog-bg .confirm-option.phone-sms-mail-push .confirm-checkbox").hasClass("checked")) {
                // set the hidden AGB2 checkbox to 'checked'
                $("p.mfw_adressData_agb2 input.checkbox").prop("checked", true);
            }
            $(".dialog-bg").hide();
        } else {
            // ...or show the "settings" screen
            $(".dialog-bg .agb-info-text-scroll").hide();
            $(".dialog-bg .settings-dialog-content").show();
            $(".dialog-bg .agb-settings-button").addClass("accept-one-or-none");
            $(".dialog-bg .agb-settings-button").text("Einzelne oder keine Zustimmung geben und weiter");
            $(".dialog-bg .agb-ok-button").addClass("accept-all");
            $(".dialog-bg .agb-ok-button").text("Alle akzeptieren und weiter");
        }
    });
    // handle clicking the big "OK" button, so we can proceed
    // with the sweepstake
    $(".dialog-bg .agb-ok-button").click(function() {
        // set the hidden AGB1 checkbox to 'checked'
        $("p.mfw_adressData_agb1 input.checkbox").prop("checked", true);
        // set the hidden AGB2 checkbox to 'checked'
        $("p.mfw_adressData_agb2 input.checkbox").prop("checked", true);
        // hide the modal confirmation dialog
        $(".dialog-bg").hide();
    });
}
/* EDIT: agb_dialog */

/* EDIT: advertising_info */
function apply_advertising_info_changes() {
    // dialog HTML code
    var htmlStr = `
        <div class="advertising-info-window">
            <div class="advertising-info-titlebar">
                <div class="advertising-info-close-button"></div>
            </div>
            <div class="advertising-info-content">
                <p>You want to advertise one of our campaigns?</p>
                <p>Please contact us: <a href="mailto:marketing@zooloollc.com">marketing@zooloollc.com</a></p>
            </div>
        </div>
    `;
    // add the advertising info dialog to the site
    //$("body").append(htmlStr);
    $(".footer .inner").append(htmlStr);
    // when clicking the 'close' button, hide the dialog
    $(".advertising-info-window .advertising-info-close-button").click(function() {
        $(".advertising-info-window").slideUp();
    });
    // when clicking certain links, show the dialog
    $(".show-advertising-info").click(function() {
        $(".advertising-info-window").slideDown();
    });
}
/* EDIT: advertising_info */

$(function() {
    // Only run the sweepstake code if we are on the registration or Coreg pages
    if (OnRegistrationPage() || OnCoregPage()) {
        // set up text switch control elements
        InitTextSwitchControls();
        // initialize additional GUI code
        InitGui();
        // map visible input fields to the hidden Coyote input elements
        AssignInputProxies();
        // assign interactive input validation handling functions
        AssignInputValidators();
        // set up the 'Continue' button
        SetupContinueButton();
        // set up the sponsors list
        SetupSponsorsList();
        // set up the (customized) sweepstake from config data
        InitSweepstake();
        // apply additional Coyote layout fixes, etc.
        ApplyAdjustments();
        // set up the CoReg 'Störer' layer
        SetupStoerer();
        // set up the animated progressbar area
        SetupNewProgressbar();
        // apply the changes required by the Brandbüro CoRegs
        apply_frank_coreg_changes();

        /* EDIT: fisherprice_coreg */
        apply_fisherprice_coreg_changes();
        /* EDIT: fisherprice_coreg */

        /* EDIT: o2_coreg */
        /* EDIT: o2_coreg_new */
        apply_o2_coreg_changes();
        /* EDIT: o2_coreg_new */
        /* EDIT: o2_coreg */

        /* EDIT: selection_list_coreg */
        // add support for multiple choice CoRegs
        // (restricted to a specific CoReg at the moment)
        apply_selection_list_coreg_changes();
        /* EDIT: selection_list_coreg */

        /* EDIT: iframe_coreg */
        // turn certain CoRegs into iframes
        apply_iframe_coreg_changes();
        /* EDIT: iframe_coreg */

        /* EDIT: nicey_coreg20200909 */
        apply_nicey_coreg_changes();
        /* EDIT: nicey_coreg20200909 */

        /* EDIT: agb_coreg */
        /*// only show the AGB CoReg on campaign 804
        if ($("#submicrosite-id").val() == "804") {
            apply_agb_coreg_changes();
        }*/
        /* EDIT: agb_coreg */

        /* EDIT: agb_dialog */
        apply_agb_dialog_changes();
        /* EDIT: agb_dialog */

        /* EDIT: advertising_info */
        apply_advertising_info_changes();
        /* EDIT: advertising_info */

        /* EDIT: suedstern_coregs */
        apply_suedstern_changes();
        /* EDIT: suedstern_coregs */

        // fetch the total CoReg question count
        totalCoregCount = $(".coregContainer").length;
        // assign information to server-generated input elements, which will
        // connect server-generated (hidden) input elements to the visible
        // input elements
        AssignInputCounterparts();
        // check if any input fields have been marked as 'error' by the server
        HighlightErrors();
    } else {
        // only run the basic sweepstake styling code
        // applies to thank you page, etc.
        InitSweepstake();
    }
    /* EDIT: exitpop_red_lemon */
    apply_exitpop_changes();
    /* EDIT: exitpop_red_lemon */

    /* EDIT: tell_a_friend */
    /*if (OnThankYouPage()) {
        apply_tell_a_friend_changes();
    }*/
    /* EDIT: tell_a_friend */
});
