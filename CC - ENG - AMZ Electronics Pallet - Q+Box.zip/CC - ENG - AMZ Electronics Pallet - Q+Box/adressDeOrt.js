/** +++++++++++++++++++++++++++++++++++++++++++++++++++++++	**/
/** +	-- ANFANG --- Verhindere ein mehrfaches Laden 			**/
/** +++++++++++++++++++++++++++++++++++++++++++++++++++++++	**/
if (globalStatisticJavaSciptFunctionsLoaded != 1 ){

	/** +++++++++++++++++++++++++++++++++++++++++++++++++++++++	**/
	/** +																			**/
	/** +	 globale variablen												**/
	/** +																			**/
	/** +++++++++++++++++++++++++++++++++++++++++++++++++++++++	**/
	var globalStatisticJavaSciptFunctionsLoaded 	= 1;
	var globalAjaxUrl										= '';

	/** +++++++++++++++++++++++++++++++++++++++++++++++++++++++	**/
	/** +																			**/
	/** +	 DIVERSE SET-METHODEN											**/
	/** +																			**/
	/** +++++++++++++++++++++++++++++++++++++++++++++++++++++++	**/
	// Funktion, zum setzten der Ajax-Url
	function setAjaxUrl(ajaxUrl){
		globalAjaxUrl	= ajaxUrl;
	}

	/* EDIT: fix_missing_streetname */
	/**
	 * Re-attach 'street' input handler
	 */
	function CopyStreetValue(event) {
		$(".mfw_adressData_strasse input").val($("#street").val());
		// make sure that error markers will be cleared on user input
		AssignInputValidator(event);
	}
	/* EDIT: fix_missing_streetname */

	$(function(){
		// ### Wenn PLZ eingegeben wird

		$('#zip_code').on('input', function() {
			// fetch all input elements which are related to the address input process, so we can clear
			// their error states
			var clearElements = $("#city, #street, #street_no");
			// if the address input fields have been marked as errors before, clear the error classes now
	        clearElements.removeClass("input-error");
	        // hide the address input field error notification icons
	        clearElements.siblings(".error-img").css("display", "none");
		    if ($('#country').val() == 'de') {
		        // #### Prüfe die Länge der Eingabe
		        if ($(this).val().length == 5) {
		            var zip = $(this).val();
		            // generiere nun den Request!
		            $.ajax({
		                    type: "GET",
		                    url: globalAjaxUrl,
		                    cache: false,
		                    data: "ajaxRequestName=getAdressDataFromZip&zip=" + zip,
		                    success: function(erg) {
		                        // ### Vorbereiten der neuen Select auswahl
		                        var myStreet = '<select id="street" class="col-4">';
		                        myStreet = myStreet + '<option value="">- Bitte wählen -</option>';
		                        var myCity = '<select id="city" class="col-3">';
		                        myCity = myCity + '<option value="">- Bitte wählen -</option>';
		                        var cityCount = 0;
		                        var streetCount = 0;

		                        // #### JSON String parsen
		                        var obj = $.parseJSON(erg);

		                        // #### object für Stadt durchgehen und <option> einbauen
		                        $.each(obj.city, function(key, city) {
		                            if (typeof city != 'undefined') {
		                                cityCount++;
		                                myCity = myCity + '<option value="' + city + '">' + city + '</option>';
										// copy the first city name to the hidden Coyote input element
										if (!key) {
											$(".mfw_adressData_ort input").val(city);
										}
		                            }
		                        })

		                        // #### Select abschließen
		                        myCity = myCity + '</select>';

		                        // #### object für Straße durchgehen und <option> einbauen
		                        $.each(obj.address, function(key, address) {
		                            if (typeof address != 'undefined' && address != '') {
		                                streetCount++;
		                                myStreet = myStreet + '<option value="' + address + '">' + address + '</option>';
		                            }
		                        })
		                        myStreet = myStreet + '<option value="">- nicht in der Liste -</option></select>';

		                        // #### alte input/select gegen neue select Auswahl tauschen
		                        if (cityCount > 0) {
		                            var cityParent = $("#city").parent();
		                            $("#city").remove();

		                            if (cityCount == 1) {
		                                cityParent.append('<input id="city" class="col-3" value="' + obj.city[0] + '" readonly />');
		                                var streetParent = $("#street").parent();
		                                $("#street").remove();
		                                streetParent.prepend(myStreet);
		                            } else {
		                                cityParent.append(myCity);
		                            }
									// re-attach 'input' event handlers to the city and street input elements after rebuilding
									// those form fields
									/* EDIT: fix_internet_explorer */
									// re-attach 'city' input handler
									function CopyCityValue(event) {
										$(".mfw_adressData_ort input").val($("#city").val());
									}
									$("#city").on("input", CopyCityValue);
									// also attach a 'change' handler, because 'input' might not fire on IE/Edge
									$("#city").on("change", CopyCityValue);
									/* EDIT: fix_missing_streetname */
									// re-attach 'street' input handler
									/*function CopyStreetValue(event) {
										$(".mfw_adressData_strasse input").val($("#street").val());
										// make sure that error markers will be cleared on user input
										AssignInputValidator(event);
									}*/
									/* EDIT: fix_missing_streetname */
								    $("#street").on("input", CopyStreetValue);
									// also attach a 'change' handler, because 'input' might not fire on IE/Edge
									$("#street").on("change", CopyStreetValue);
									/* EDIT: fix_internet_explorer */
		                        }
		                    }
						});
	         }
	    } // Ende if Land == 'de'
	}); // Ende input function
		$('body').on('change', '#city', function() {
			if ($('#country').val() == 'de') {
				if ($('#zip_code').val().length == 5) {
					var zip 	= $('#zip_code').val();
					var city = $('#city').val();

					$.ajax({
					   type: "GET",
					   url: globalAjaxUrl,
					   cache: false,
					   data: "ajaxRequestName=getAdressDataFromZipCity&zip="+zip+"&city="+city,
					   success: function(erg){

					   	// ### Vorbereiten der neuen Select auswahl
					   	var myStreet 	= '<select id="street" class="col-4">';
					   		 myStreet 	= myStreet+'<option value="">- Bitte wählen -</option>';
					   	var myCity 		= '<select id="city" class="col-3">';
					   		 myCity	 	= myCity+'<option value="">- Bitte wählen -</option>';
					   	var cityCount 	= 0;
					   	var streetCount = 0;

					   	// #### JSON String parsen
						   var obj = $.parseJSON(erg);

						   // #### object für Stadt durchgehen und <option> einbauen
						   $.each(obj.city, function(key,city) {
						   	if (typeof city!='undefined') {
						   		cityCount++;
						   		myCity = myCity+'<option value="'+city+'">'+city+'</option>';
								/* EDIT: fix_internet_explorer */
								// copy the first city name to the hidden Coyote input element
								if (!key) {
									$(".mfw_adressData_ort input").val(city);
								}
								/* EDIT: fix_internet_explorer */
						   	}
					   	});

					   	// #### Select abschließen
				   		myCity = myCity+'</select>';

					   	// #### object für Straße durchgehen und <option> einbauen
					   	$.each(obj.address, function(key,address) {
					   		if (typeof address!='undefined' && address != '' ) {
					   			streetCount++;
						   		myStreet = myStreet+'<option value="'+address+'">'+address+'</option>';
						   	}
					   	});
						   myStreet = myStreet+'<option value="not in list">- nicht in der Liste -</option></select>';

					   	// #### alte input/select gegen neue select Auswahl tauschen
					   	if (cityCount > 0) {

								var cityParent = $("#city").parent();
								$("#city").remove();

								if (cityCount == 1) {
									cityParent.append('<input id="city" class="col-3" value="' + obj.city[0] + '" readonly />');
									/* EDIT: fix_internet_explorer */
									// copy the 'city' name to the internal input field
									$(".mfw_adressData_ort input").val(obj.city[0]);
									/* EDIT: fix_internet_explorer */
									var streetParent = $("#street").parent();
									$("#street").remove();
									streetParent.prepend(myStreet);
								} else {
									cityParent.append(myCity);
								}
								/* EDIT: fix_missing_streetname */
								$("#street").on("input", CopyStreetValue);
								// also attach a 'change' handler, because 'input' might not fire on IE/Edge
								$("#street").on("change", CopyStreetValue);
								/* EDIT: fix_missing_streetname */
					   	}
					}
				});
			}
		}

		$("#country").on("change", function() {
			if ($("#country").val() != "de") {
				var myStreet = '<input id="street" class="col-4" />';
				var myCity = '<input id="city" class="col-3" />';
				var streetParent = $("#street").parent();
				$("#street").remove();
				streetParent.prepend(myStreet);
				var cityParent = $("#city").parent();
				$("#city").remove();
				cityParent.append(myCity);
			} else if ($("zip_code").val().length == 5) {
				$("#zip_code").trigger("input");
			}
		});
	});

});
}
